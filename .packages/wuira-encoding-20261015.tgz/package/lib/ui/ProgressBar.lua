--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
local ____jsx = require("ui.primitives.jsx")
local UI = ____jsx.UI
function ____exports.ProgressBar(self, props, child)
    return UI:createElement("progress", props, props.child or child or ({}))
end
return ____exports

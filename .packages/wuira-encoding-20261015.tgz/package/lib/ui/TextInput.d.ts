interface NativeEditBox extends wuiraNativeFrame {
    SetAutoFocus(value: boolean): void;
    SetMultiLine(value: boolean): void;
    SetFont(path: string, size: number, flags: string): boolean;
    SetTextInsets(left: number, right: number, top: number, bottom: number): void;
    SetMaxBytes(bytes: number): void;
    SetText(text: string): void;
    GetText(): string;
    HighlightText(): void;
    SetFocus(): void;
    ClearFocus(): void;
}
/** Native text entry hosted by a mounted Cell. Dispose it in that Cell's onMount cleanup. */
export declare class TextInput {
    readonly Frame: NativeEditBox;
    private disposed;
    constructor(parent: wuiraNativeFrame, options?: {
        text?: string;
        maxBytes?: number;
        onEscape?: () => void;
    });
    get Value(): string;
    Focus(selectAll?: boolean): void;
    Dispose(): void;
}
export {};

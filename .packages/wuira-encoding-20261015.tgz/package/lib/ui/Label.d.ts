import type { CellProps } from "./Cell";
import type { Color } from "../types/Color";
export type LabelProps = CellProps & {
    text: string | (() => string);
    font?: string;
    fontSize?: number;
    color?: Color;
    align?: "LEFT" | "CENTER" | "RIGHT";
};
export declare function Label(props: Partial<CellProps> & Omit<LabelProps, keyof CellProps>): import("..").Element;

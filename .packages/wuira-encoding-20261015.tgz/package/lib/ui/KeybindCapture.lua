--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end

local __TS__Symbol, Symbol
do
    local symbolMetatable = {__tostring = function(self)
        return ("Symbol(" .. (self.description or "")) .. ")"
    end}
    function __TS__Symbol(description)
        return setmetatable({description = description}, symbolMetatable)
    end
    Symbol = {
        asyncDispose = __TS__Symbol("Symbol.asyncDispose"),
        dispose = __TS__Symbol("Symbol.dispose"),
        iterator = __TS__Symbol("Symbol.iterator"),
        hasInstance = __TS__Symbol("Symbol.hasInstance"),
        species = __TS__Symbol("Symbol.species"),
        toStringTag = __TS__Symbol("Symbol.toStringTag")
    }
end

local __TS__Iterator
do
    local function iteratorGeneratorStep(self)
        local co = self.____coroutine
        local status, value = coroutine.resume(co)
        if not status then
            error(value, 0)
        end
        if coroutine.status(co) == "dead" then
            return
        end
        return true, value
    end
    local function iteratorIteratorStep(self)
        local result = self:next()
        if result.done then
            return
        end
        return true, result.value
    end
    local function iteratorStringStep(self, index)
        index = index + 1
        if index > #self then
            return
        end
        return index, string.sub(self, index, index)
    end
    function __TS__Iterator(iterable)
        if type(iterable) == "string" then
            return iteratorStringStep, iterable, 0
        elseif iterable.____coroutine ~= nil then
            return iteratorGeneratorStep, iterable
        elseif iterable[Symbol.iterator] then
            local iterator = iterable[Symbol.iterator](iterable)
            return iteratorIteratorStep, iterator
        else
            return ipairs(iterable)
        end
    end
end

local function __TS__New(target, ...)
    local instance = setmetatable({}, target.prototype)
    instance:____constructor(...)
    return instance
end

local Set
do
    Set = __TS__Class()
    Set.name = "Set"
    function Set.prototype.____constructor(self, values)
        self[Symbol.toStringTag] = "Set"
        self.size = 0
        self.nextKey = {}
        self.previousKey = {}
        if values == nil then
            return
        end
        local iterable = values
        if iterable[Symbol.iterator] then
            local iterator = iterable[Symbol.iterator](iterable)
            while true do
                local result = iterator:next()
                if result.done then
                    break
                end
                self:add(result.value)
            end
        else
            local array = values
            for ____, value in ipairs(array) do
                self:add(value)
            end
        end
    end
    function Set.prototype.add(self, value)
        local isNewValue = not self:has(value)
        if isNewValue then
            self.size = self.size + 1
        end
        if self.firstKey == nil then
            self.firstKey = value
            self.lastKey = value
        elseif isNewValue then
            self.nextKey[self.lastKey] = value
            self.previousKey[value] = self.lastKey
            self.lastKey = value
        end
        return self
    end
    function Set.prototype.clear(self)
        self.nextKey = {}
        self.previousKey = {}
        self.firstKey = nil
        self.lastKey = nil
        self.size = 0
    end
    function Set.prototype.delete(self, value)
        local contains = self:has(value)
        if contains then
            self.size = self.size - 1
            local next = self.nextKey[value]
            local previous = self.previousKey[value]
            if next ~= nil and previous ~= nil then
                self.nextKey[previous] = next
                self.previousKey[next] = previous
            elseif next ~= nil then
                self.firstKey = next
                self.previousKey[next] = nil
            elseif previous ~= nil then
                self.lastKey = previous
                self.nextKey[previous] = nil
            else
                self.firstKey = nil
                self.lastKey = nil
            end
            self.nextKey[value] = nil
            self.previousKey[value] = nil
        end
        return contains
    end
    function Set.prototype.forEach(self, callback)
        for ____, key in __TS__Iterator(self:keys()) do
            callback(nil, key, key, self)
        end
    end
    function Set.prototype.has(self, value)
        return self.nextKey[value] ~= nil or self.lastKey == value
    end
    Set.prototype[Symbol.iterator] = function(self)
        return self:values()
    end
    function Set.prototype.entries(self)
        local function getFirstKey()
            return self.firstKey
        end
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = {key, key}}
            end
        }
    end
    function Set.prototype.keys(self)
        local function getFirstKey()
            return self.firstKey
        end
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = key}
            end
        }
    end
    function Set.prototype.values(self)
        local function getFirstKey()
            return self.firstKey
        end
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = key}
            end
        }
    end
    function Set.prototype.union(self, other)
        local result = __TS__New(Set, self)
        for ____, item in __TS__Iterator(other) do
            result:add(item)
        end
        return result
    end
    function Set.prototype.intersection(self, other)
        local result = __TS__New(Set)
        for ____, item in __TS__Iterator(self) do
            if other:has(item) then
                result:add(item)
            end
        end
        return result
    end
    function Set.prototype.difference(self, other)
        local result = __TS__New(Set, self)
        for ____, item in __TS__Iterator(other) do
            result:delete(item)
        end
        return result
    end
    function Set.prototype.symmetricDifference(self, other)
        local result = __TS__New(Set, self)
        for ____, item in __TS__Iterator(other) do
            if self:has(item) then
                result:delete(item)
            else
                result:add(item)
            end
        end
        return result
    end
    function Set.prototype.isSubsetOf(self, other)
        for ____, item in __TS__Iterator(self) do
            if not other:has(item) then
                return false
            end
        end
        return true
    end
    function Set.prototype.isSupersetOf(self, other)
        for ____, item in __TS__Iterator(other) do
            if not self:has(item) then
                return false
            end
        end
        return true
    end
    function Set.prototype.isDisjointFrom(self, other)
        for ____, item in __TS__Iterator(self) do
            if other:has(item) then
                return false
            end
        end
        return true
    end
    Set[Symbol.species] = Set
end

local function __TS__ArrayIncludes(self, searchElement, fromIndex)
    if fromIndex == nil then
        fromIndex = 0
    end
    local len = #self
    local k = fromIndex
    if fromIndex < 0 then
        k = len + fromIndex
    end
    if k < 0 then
        k = 0
    end
    for i = k + 1, len do
        if self[i] == searchElement then
            return true
        end
    end
    return false
end
-- End of Lua Library inline imports
local ____exports = {}
--- Hover-to-bind input capture. It reports keys; the addon owns persistence and actions.
____exports.KeybindCapture = __TS__Class()
local KeybindCapture = ____exports.KeybindCapture
KeybindCapture.name = "KeybindCapture"
function KeybindCapture.prototype.____constructor(self, onCancel)
    self.onCancel = onCancel
    self.targets = __TS__New(Set)
    self.active = false
    self.frame = CreateFrame("Frame", nil, UIParent)
    self.frame:SetFrameStrata("FULLSCREEN_DIALOG")
    self.frame:SetSize(1, 1)
    self.frame:SetPoint(
        "TOPLEFT",
        UIParent,
        "TOPLEFT",
        0,
        0
    )
    self.frame:EnableMouse(false)
    self.frame:EnableKeyboard(false)
    self.frame:Hide()
    self.frame:SetScript(
        "OnKeyDown",
        function(_frame, key) return self:OnKey(key) end
    )
    self.frame:RegisterEvent("PLAYER_REGEN_DISABLED")
    self.frame:SetScript(
        "OnEvent",
        function()
            self:SetActive(false)
            self:onCancel()
        end
    )
end
function KeybindCapture.prototype.AddTarget(self, frame, onBinding)
    if InCombatLockdown() then
        error("KeybindCapture: register targets outside combat")
    end
    local overlay = CreateFrame("Frame", nil, UIParent)
    overlay:SetFrameStrata("DIALOG")
    overlay:SetSize(
        frame:GetWidth(),
        frame:GetHeight()
    )
    local x, y = frame:GetCenter()
    local screenX, screenY = UIParent:GetCenter()
    if x == nil or y == nil or screenX == nil or screenY == nil then
        error("KeybindCapture: target has no screen position")
    end
    overlay:SetPoint(
        "CENTER",
        UIParent,
        "CENTER",
        x - screenX,
        y - screenY
    )
    overlay:EnableMouse(true)
    local color = overlay:CreateTexture(nil, "OVERLAY")
    color:SetAllPoints(overlay)
    color:SetColorTexture(0.4, 0.75, 1, 0.14)
    local target = {frame = frame, overlay = overlay, onBinding = onBinding}
    overlay:SetScript(
        "OnEnter",
        function()
            if not self.active then
                return
            end
            self.hovered = target
            color:SetColorTexture(0.4, 0.75, 1, 0.45)
        end
    )
    overlay:SetScript(
        "OnLeave",
        function()
            if self.hovered == target then
                self.hovered = nil
            end
            color:SetColorTexture(0.4, 0.75, 1, 0.14)
        end
    )
    self.targets:add(target)
    if self.active then
        overlay:Show()
    else
        overlay:Hide()
    end
    return function()
        if self.hovered == target then
            self.hovered = nil
        end
        self.targets:delete(target)
        overlay:SetScript("OnEnter", nil)
        overlay:SetScript("OnLeave", nil)
        overlay:EnableMouse(false)
        overlay:Hide()
    end
end
function KeybindCapture.prototype.SetActive(self, active)
    if active and InCombatLockdown() then
        error("KeybindCapture: enable outside combat")
    end
    self.active = active
    self.hovered = nil
    self.frame:EnableKeyboard(active)
    if active then
        self.frame:SetPropagateKeyboardInput(true)
        self.frame:Show()
    else
        self.frame:Hide()
    end
    for ____, target in __TS__Iterator(self.targets) do
        if active then
            local x, y = target.frame:GetCenter()
            local screenX, screenY = UIParent:GetCenter()
            if x ~= nil and y ~= nil and screenX ~= nil and screenY ~= nil then
                target.overlay:ClearAllPoints()
                target.overlay:SetPoint(
                    "CENTER",
                    UIParent,
                    "CENTER",
                    x - screenX,
                    y - screenY
                )
            end
            target.overlay:Show()
        else
            target.overlay:Hide()
        end
    end
end
function KeybindCapture.prototype.OnKey(self, key)
    if not self.active or InCombatLockdown() then
        return
    end
    self.frame:SetPropagateKeyboardInput(true)
    local chat = ChatEdit_GetActiveWindow and ChatEdit_GetActiveWindow()
    if chat and chat:IsShown() then
        return
    end
    if key == "ESCAPE" then
        self.frame:SetPropagateKeyboardInput(false)
        self:onCancel()
        return
    end
    if self.hovered == nil or __TS__ArrayIncludes({
        "LSHIFT",
        "RSHIFT",
        "LCTRL",
        "RCTRL",
        "LALT",
        "RALT",
        "ENTER",
        "PRINTSCREEN"
    }, key) then
        return
    end
    self.frame:SetPropagateKeyboardInput(false)
    local ____temp_4
    if key == "BACKSPACE" or key == "DELETE" then
        ____temp_4 = nil
    else
        ____temp_4 = (((IsControlKeyDown() and "CTRL-" or "") .. (IsAltKeyDown() and "ALT-" or "")) .. (IsShiftKeyDown() and "SHIFT-" or "")) .. key
    end
    local binding = ____temp_4
    self.hovered:onBinding(binding)
    self.frame:SetPropagateKeyboardInput(false)
end
function KeybindCapture.prototype.Dispose(self)
    self:SetActive(false)
    self.frame:UnregisterAllEvents()
    self.frame:SetScript("OnEvent", nil)
    self.frame:SetScript("OnKeyDown", nil)
    for ____, target in __TS__Iterator(self.targets) do
        target.overlay:SetScript("OnEnter", nil)
        target.overlay:SetScript("OnLeave", nil)
        target.overlay:EnableMouse(false)
    end
    self.targets:clear()
end
return ____exports

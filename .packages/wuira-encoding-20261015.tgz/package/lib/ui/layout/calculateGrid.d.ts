import type { GridLayoutProps } from "../GridLayout";
/** Row-major placement into uniform slots; children keep their own sizes. */
export declare function calculateGrid(props: GridLayoutProps, children: readonly {
    width: number;
    height: number;
}[]): {
    x: number;
    y: number;
}[];

--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__NumberIsFinite(value)
    return type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge
end

local function __TS__ArrayIncludes(self, searchElement, fromIndex)
    if fromIndex == nil then
        fromIndex = 0
    end
    local len = #self
    local k = fromIndex
    if fromIndex < 0 then
        k = len + fromIndex
    end
    if k < 0 then
        k = 0
    end
    for i = k + 1, len do
        if self[i] == searchElement then
            return true
        end
    end
    return false
end

local __TS__Unpack = table.unpack or unpack

local function __TS__CountVarargs(...)
    return select("#", ...)
end

local function __TS__SparseArrayNew(...)
    local sparseArray = {...}
    sparseArray.sparseLength = __TS__CountVarargs(...)
    return sparseArray
end

local function __TS__SparseArrayPush(sparseArray, ...)
    local args = {...}
    local argsLen = __TS__CountVarargs(...)
    local listLen = sparseArray.sparseLength
    for i = 1, argsLen do
        sparseArray[listLen + i] = args[i]
    end
    sparseArray.sparseLength = listLen + argsLen
end

local function __TS__SparseArraySpread(sparseArray)
    local _unpack = unpack or table.unpack
    return _unpack(sparseArray, 1, sparseArray.sparseLength)
end

local function __TS__ArrayMap(self, callbackfn, thisArg)
    local result = {}
    for i = 1, #self do
        result[i] = callbackfn(thisArg, self[i], i - 1, self)
    end
    return result
end

local function __TS__ObjectAssign(target, ...)
    local sources = {...}
    for i = 1, #sources do
        local source = sources[i]
        if type(source) == "table" then
            for key in pairs(source) do
                target[key] = source[key]
            end
        end
    end
    return target
end
-- End of Lua Library inline imports
local ____exports = {}
local ____Spacing = require("types.Spacing")
local resolveSpacing = ____Spacing.resolveSpacing
local ____calculateFlow = require("ui.layout.calculateFlow")
local calculateFlow = ____calculateFlow.calculateFlow
local ____calculateGrid = require("ui.layout.calculateGrid")
local calculateGrid = ____calculateGrid.calculateGrid
local function resolveSize(self, value, available, margin)
    if value == "inherit" then
        if available == nil then
            error("Cannot inherit a size from an unconstrained content-sized parent")
        end
        return math.max(0, available - margin)
    end
    if not __TS__NumberIsFinite(value) or value < 0 then
        error("Cell sizes must be finite and non-negative")
    end
    return value
end
--- Resolve available space top-down and content bounds bottom-up.
function ____exports.measureLayout(self, element, available, ancestors)
    if available == nil then
        available = {}
    end
    if ancestors == nil then
        ancestors = {}
    end
    if __TS__ArrayIncludes(ancestors, element) then
        error("Layout children contain a cycle")
    end
    if not __TS__ArrayIncludes({
        "cell",
        "flow",
        "grid",
        "progress",
        "label",
        "icon",
        "button",
        "secureButton"
    }, element.kind) then
        error("Unsupported UI element: " .. element.kind)
    end
    local cell = element
    local props = cell.props
    local margin = resolveSpacing(nil, props.margin)
    local padding = resolveSpacing(nil, props.padding)
    local width = resolveSize(nil, props.width, available.width, margin.left + margin.right)
    local height = resolveSize(nil, props.height, available.height, margin.top + margin.bottom)
    local isLayout = element.kind == "flow" or element.kind == "grid"
    local layout = isLayout and element or nil
    local contentSizing = (layout and layout.props.sizing) == "content"
    local ____temp_2
    if contentSizing and props.width == 0 then
        ____temp_2 = nil
    else
        ____temp_2 = math.max(0, width - padding.left - padding.right)
    end
    local contentWidth = ____temp_2
    local ____temp_3
    if contentSizing and props.height == 0 then
        ____temp_3 = nil
    else
        ____temp_3 = math.max(0, height - padding.top - padding.bottom)
    end
    local contentHeight = ____temp_3
    local sourceChildren = layout ~= nil and layout.children or (cell.child == nil and ({}) or ({cell.child}))
    local childWidth = contentWidth
    local childHeight = contentHeight
    if (layout and layout.kind) == "grid" then
        local grid = layout.props
        if not __TS__NumberIsFinite(grid.columns) or grid.columns < 1 or math.floor(grid.columns) ~= grid.columns then
            error("GridLayout columns must be a positive integer")
        end
        local rows = math.max(
            1,
            math.ceil(#sourceChildren / grid.columns)
        )
        local ____grid_cellWidth_7 = grid.cellWidth
        if ____grid_cellWidth_7 == nil then
            local ____temp_6
            if contentWidth == nil then
                ____temp_6 = nil
            else
                ____temp_6 = math.max(0, (contentWidth - (grid.columnGap or grid.gap or 0) * (grid.columns - 1)) / grid.columns)
            end
            ____grid_cellWidth_7 = ____temp_6
        end
        childWidth = ____grid_cellWidth_7
        local ____grid_cellHeight_9 = grid.cellHeight
        if ____grid_cellHeight_9 == nil then
            local ____temp_8
            if contentHeight == nil then
                ____temp_8 = nil
            else
                ____temp_8 = math.max(0, (contentHeight - (grid.rowGap or grid.gap or 0) * (rows - 1)) / rows)
            end
            ____grid_cellHeight_9 = ____temp_8
        end
        childHeight = ____grid_cellHeight_9
    end
    local ____array_10 = __TS__SparseArrayNew(__TS__Unpack(ancestors))
    __TS__SparseArrayPush(____array_10, element)
    local path = {__TS__SparseArraySpread(____array_10)}
    local children = __TS__ArrayMap(
        sourceChildren,
        function(____, child) return ____exports.measureLayout(nil, child, {width = childWidth, height = childHeight}, path) end
    )
    local placements
    if layout ~= nil then
        local sizes = __TS__ArrayMap(
            children,
            function(____, child) return {width = child.width + child.margin.left + child.margin.right, height = child.height + child.margin.top + child.margin.bottom} end
        )
        local positions = layout.kind == "flow" and calculateFlow(
            nil,
            __TS__ObjectAssign({}, layout.props, {width = contentWidth or 0, height = contentHeight or 0}),
            sizes
        ) or calculateGrid(nil, layout.props, sizes)
        placements = __TS__ArrayMap(
            positions,
            function(____, point) return {x = point.x + padding.left, y = point.y + padding.top} end
        )
        if contentSizing then
            width = padding.left + padding.right
            height = padding.top + padding.bottom
            do
                local i = 0
                while i < #children do
                    width = math.max(width, positions[i + 1].x + sizes[i + 1].width + padding.left + padding.right)
                    height = math.max(height, positions[i + 1].y + sizes[i + 1].height + padding.top + padding.bottom)
                    i = i + 1
                end
            end
        end
    elseif #children > 0 then
        local position = children[1].cell.props
        if position.mode == "relative" and position.relativeTo == nil and (position.anchor == nil or position.anchor == "TOPLEFT") and (position.relativeAnchor == nil or position.relativeAnchor == "TOPLEFT") then
            placements = {{x = padding.left + position.offset.x, y = padding.top + position.offset.y}}
        end
    end
    return {
        cell = cell,
        width = width,
        height = height,
        margin = margin,
        children = children,
        placements = placements
    }
end
return ____exports

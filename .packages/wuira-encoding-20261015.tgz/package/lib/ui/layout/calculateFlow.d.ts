import type { FlowLayoutProps } from "../FlowLayout";
/** Pure layout calculation in top-left UI coordinates. */
export declare function calculateFlow(props: FlowLayoutProps & {
    width: number;
    height: number;
}, children: readonly {
    width: number;
    height: number;
}[]): {
    x: number;
    y: number;
}[];

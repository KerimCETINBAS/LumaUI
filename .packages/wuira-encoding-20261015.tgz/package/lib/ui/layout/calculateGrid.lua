--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__NumberIsFinite(value)
    return type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge
end

local function __TS__ArrayMap(self, callbackfn, thisArg)
    local result = {}
    for i = 1, #self do
        result[i] = callbackfn(thisArg, self[i], i - 1, self)
    end
    return result
end
-- End of Lua Library inline imports
local ____exports = {}
--- Row-major placement into uniform slots; children keep their own sizes.
function ____exports.calculateGrid(self, props, children)
    if not __TS__NumberIsFinite(props.columns) or props.columns < 1 or math.floor(props.columns) ~= props.columns then
        error("GridLayout columns must be a positive integer")
    end
    local rowGap = props.rowGap or props.gap or 0
    local columnGap = props.columnGap or props.gap or 0
    if rowGap < 0 or columnGap < 0 then
        error("GridLayout gaps must be non-negative")
    end
    local width = props.cellWidth or 0
    local height = props.cellHeight or 0
    for ____, child in ipairs(children) do
        if props.cellWidth == nil then
            width = math.max(width, child.width)
        end
        if props.cellHeight == nil then
            height = math.max(height, child.height)
        end
    end
    if width < 0 or height < 0 then
        error("GridLayout cell sizes must be non-negative")
    end
    return __TS__ArrayMap(
        children,
        function(____, _, index) return {
            x = index % props.columns * (width + columnGap),
            y = math.floor(index / props.columns) * (height + rowGap)
        } end
    )
end
return ____exports

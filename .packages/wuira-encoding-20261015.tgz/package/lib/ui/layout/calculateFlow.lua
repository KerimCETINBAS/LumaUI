--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__NumberIsFinite(value)
    return type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge
end
-- End of Lua Library inline imports
local ____exports = {}
--- Pure layout calculation in top-left UI coordinates.
function ____exports.calculateFlow(self, props, children)
    local horizontal = props.direction == "horizontal"
    local requestedLimit = horizontal and props.width or props.height
    local limit = props.sizing == "content" and requestedLimit == 0 and math.huge or requestedLimit
    local gap = props.gap or 0
    local lineGap = props.lineGap or gap
    if gap < 0 or lineGap < 0 then
        error("FlowLayout gaps must be non-negative")
    end
    local result = {}
    local cursor = 0
    local cross = 0
    local lineSize = 0
    local count = 0
    local lineStart = 0
    local function alignLine()
        local free = __TS__NumberIsFinite(limit) and math.max(0, limit - cursor) or 0
        local offset = props.justify == "center" and free / 2 or (props.justify == "end" and free or 0)
        do
            local index = lineStart
            while index < #result do
                if horizontal then
                    local ____result_index_0, ____x_1 = result[index + 1], "x"
                    ____result_index_0[____x_1] = ____result_index_0[____x_1] + offset
                else
                    local ____result_index_2, ____y_3 = result[index + 1], "y"
                    ____result_index_2[____y_3] = ____result_index_2[____y_3] + offset
                end
                index = index + 1
            end
        end
        lineStart = #result
    end
    for ____, child in ipairs(children) do
        local size = horizontal and child.width or child.height
        local crossSize = horizontal and child.height or child.width
        local next = count == 0 and 0 or cursor + gap
        if props.grow and count > 0 and next + size > limit then
            alignLine(nil)
            cross = cross + (lineSize + lineGap)
            cursor = 0
            lineSize = 0
            count = 0
        end
        local position = count == 0 and 0 or cursor + gap
        result[#result + 1] = horizontal and ({x = position, y = cross}) or ({x = cross, y = position})
        cursor = position + size
        lineSize = math.max(lineSize, crossSize)
        count = count + 1
    end
    alignLine(nil)
    return result
end
return ____exports

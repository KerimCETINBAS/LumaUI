import type { ICell } from "../Cell";
import type { Element } from "../primitives/jsx";
import { Insets } from "../../types/Spacing";
export interface MeasuredCell {
    cell: ICell;
    width: number;
    height: number;
    margin: Insets;
    children: MeasuredCell[];
    placements?: ({
        x: number;
        y: number;
    } | undefined)[];
}
/** Resolve available space top-down and content bounds bottom-up. */
export declare function measureLayout(element: Element, available?: {
    width?: number;
    height?: number;
}, ancestors?: Element[]): MeasuredCell;

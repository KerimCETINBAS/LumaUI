import type { CellProps } from "./Cell";
import type { TextureSource } from "../datasources/TextureSource";
export type IconProps = CellProps & {
    texture?: string | number;
    textureSource?: TextureSource;
    texCoords?: readonly [number, number, number, number];
};
export declare function Icon(props: Partial<IconProps>): import("..").Element;

import type { Element } from "./primitives/jsx";
import type { Anchor } from "../types/Position";
export declare function unmount(frame: wuiraNativeFrame): void;
/** Creates the tree before resolving anchors. Positive y moves down. */
export declare function mount(element: Element, parent?: wuiraNativeFrame, rootAnchor?: Anchor): wuiraNativeFrame;

--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end

local __TS__Symbol, Symbol
do
    local symbolMetatable = {__tostring = function(self)
        return ("Symbol(" .. (self.description or "")) .. ")"
    end}
    function __TS__Symbol(description)
        return setmetatable({description = description}, symbolMetatable)
    end
    Symbol = {
        asyncDispose = __TS__Symbol("Symbol.asyncDispose"),
        dispose = __TS__Symbol("Symbol.dispose"),
        iterator = __TS__Symbol("Symbol.iterator"),
        hasInstance = __TS__Symbol("Symbol.hasInstance"),
        species = __TS__Symbol("Symbol.species"),
        toStringTag = __TS__Symbol("Symbol.toStringTag")
    }
end

local __TS__Iterator
do
    local function iteratorGeneratorStep(self)
        local co = self.____coroutine
        local status, value = coroutine.resume(co)
        if not status then
            error(value, 0)
        end
        if coroutine.status(co) == "dead" then
            return
        end
        return true, value
    end
    local function iteratorIteratorStep(self)
        local result = self:next()
        if result.done then
            return
        end
        return true, result.value
    end
    local function iteratorStringStep(self, index)
        index = index + 1
        if index > #self then
            return
        end
        return index, string.sub(self, index, index)
    end
    function __TS__Iterator(iterable)
        if type(iterable) == "string" then
            return iteratorStringStep, iterable, 0
        elseif iterable.____coroutine ~= nil then
            return iteratorGeneratorStep, iterable
        elseif iterable[Symbol.iterator] then
            local iterator = iterable[Symbol.iterator](iterable)
            return iteratorIteratorStep, iterator
        else
            return ipairs(iterable)
        end
    end
end

local Map
do
    Map = __TS__Class()
    Map.name = "Map"
    function Map.prototype.____constructor(self, entries)
        self[Symbol.toStringTag] = "Map"
        self.items = {}
        self.size = 0
        self.nextKey = {}
        self.previousKey = {}
        if entries == nil then
            return
        end
        local iterable = entries
        if iterable[Symbol.iterator] then
            local iterator = iterable[Symbol.iterator](iterable)
            while true do
                local result = iterator:next()
                if result.done then
                    break
                end
                local value = result.value
                self:set(value[1], value[2])
            end
        else
            local array = entries
            for ____, kvp in ipairs(array) do
                self:set(kvp[1], kvp[2])
            end
        end
    end
    function Map.prototype.clear(self)
        self.items = {}
        self.nextKey = {}
        self.previousKey = {}
        self.firstKey = nil
        self.lastKey = nil
        self.size = 0
    end
    function Map.prototype.delete(self, key)
        local contains = self:has(key)
        if contains then
            self.size = self.size - 1
            local next = self.nextKey[key]
            local previous = self.previousKey[key]
            if next ~= nil and previous ~= nil then
                self.nextKey[previous] = next
                self.previousKey[next] = previous
            elseif next ~= nil then
                self.firstKey = next
                self.previousKey[next] = nil
            elseif previous ~= nil then
                self.lastKey = previous
                self.nextKey[previous] = nil
            else
                self.firstKey = nil
                self.lastKey = nil
            end
            self.nextKey[key] = nil
            self.previousKey[key] = nil
        end
        self.items[key] = nil
        return contains
    end
    function Map.prototype.forEach(self, callback)
        for ____, key in __TS__Iterator(self:keys()) do
            callback(nil, self.items[key], key, self)
        end
    end
    function Map.prototype.get(self, key)
        return self.items[key]
    end
    function Map.prototype.has(self, key)
        return self.nextKey[key] ~= nil or self.lastKey == key
    end
    function Map.prototype.set(self, key, value)
        local isNewValue = not self:has(key)
        if isNewValue then
            self.size = self.size + 1
        end
        self.items[key] = value
        if self.firstKey == nil then
            self.firstKey = key
            self.lastKey = key
        elseif isNewValue then
            self.nextKey[self.lastKey] = key
            self.previousKey[key] = self.lastKey
            self.lastKey = key
        end
        return self
    end
    Map.prototype[Symbol.iterator] = function(self)
        return self:entries()
    end
    function Map.prototype.entries(self)
        local function getFirstKey()
            return self.firstKey
        end
        local items = self.items
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = {key, items[key]}}
            end
        }
    end
    function Map.prototype.keys(self)
        local function getFirstKey()
            return self.firstKey
        end
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = key}
            end
        }
    end
    function Map.prototype.values(self)
        local function getFirstKey()
            return self.firstKey
        end
        local items = self.items
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = items[key]}
            end
        }
    end
    Map[Symbol.species] = Map
end

local function __TS__New(target, ...)
    local instance = setmetatable({}, target.prototype)
    instance:____constructor(...)
    return instance
end

local Set
do
    Set = __TS__Class()
    Set.name = "Set"
    function Set.prototype.____constructor(self, values)
        self[Symbol.toStringTag] = "Set"
        self.size = 0
        self.nextKey = {}
        self.previousKey = {}
        if values == nil then
            return
        end
        local iterable = values
        if iterable[Symbol.iterator] then
            local iterator = iterable[Symbol.iterator](iterable)
            while true do
                local result = iterator:next()
                if result.done then
                    break
                end
                self:add(result.value)
            end
        else
            local array = values
            for ____, value in ipairs(array) do
                self:add(value)
            end
        end
    end
    function Set.prototype.add(self, value)
        local isNewValue = not self:has(value)
        if isNewValue then
            self.size = self.size + 1
        end
        if self.firstKey == nil then
            self.firstKey = value
            self.lastKey = value
        elseif isNewValue then
            self.nextKey[self.lastKey] = value
            self.previousKey[value] = self.lastKey
            self.lastKey = value
        end
        return self
    end
    function Set.prototype.clear(self)
        self.nextKey = {}
        self.previousKey = {}
        self.firstKey = nil
        self.lastKey = nil
        self.size = 0
    end
    function Set.prototype.delete(self, value)
        local contains = self:has(value)
        if contains then
            self.size = self.size - 1
            local next = self.nextKey[value]
            local previous = self.previousKey[value]
            if next ~= nil and previous ~= nil then
                self.nextKey[previous] = next
                self.previousKey[next] = previous
            elseif next ~= nil then
                self.firstKey = next
                self.previousKey[next] = nil
            elseif previous ~= nil then
                self.lastKey = previous
                self.nextKey[previous] = nil
            else
                self.firstKey = nil
                self.lastKey = nil
            end
            self.nextKey[value] = nil
            self.previousKey[value] = nil
        end
        return contains
    end
    function Set.prototype.forEach(self, callback)
        for ____, key in __TS__Iterator(self:keys()) do
            callback(nil, key, key, self)
        end
    end
    function Set.prototype.has(self, value)
        return self.nextKey[value] ~= nil or self.lastKey == value
    end
    Set.prototype[Symbol.iterator] = function(self)
        return self:values()
    end
    function Set.prototype.entries(self)
        local function getFirstKey()
            return self.firstKey
        end
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = {key, key}}
            end
        }
    end
    function Set.prototype.keys(self)
        local function getFirstKey()
            return self.firstKey
        end
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = key}
            end
        }
    end
    function Set.prototype.values(self)
        local function getFirstKey()
            return self.firstKey
        end
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = key}
            end
        }
    end
    function Set.prototype.union(self, other)
        local result = __TS__New(Set, self)
        for ____, item in __TS__Iterator(other) do
            result:add(item)
        end
        return result
    end
    function Set.prototype.intersection(self, other)
        local result = __TS__New(Set)
        for ____, item in __TS__Iterator(self) do
            if other:has(item) then
                result:add(item)
            end
        end
        return result
    end
    function Set.prototype.difference(self, other)
        local result = __TS__New(Set, self)
        for ____, item in __TS__Iterator(other) do
            result:delete(item)
        end
        return result
    end
    function Set.prototype.symmetricDifference(self, other)
        local result = __TS__New(Set, self)
        for ____, item in __TS__Iterator(other) do
            if self:has(item) then
                result:delete(item)
            else
                result:add(item)
            end
        end
        return result
    end
    function Set.prototype.isSubsetOf(self, other)
        for ____, item in __TS__Iterator(self) do
            if not other:has(item) then
                return false
            end
        end
        return true
    end
    function Set.prototype.isSupersetOf(self, other)
        for ____, item in __TS__Iterator(other) do
            if not self:has(item) then
                return false
            end
        end
        return true
    end
    function Set.prototype.isDisjointFrom(self, other)
        for ____, item in __TS__Iterator(self) do
            if other:has(item) then
                return false
            end
        end
        return true
    end
    Set[Symbol.species] = Set
end

local function __TS__ArrayMap(self, callbackfn, thisArg)
    local result = {}
    for i = 1, #self do
        result[i] = callbackfn(thisArg, self[i], i - 1, self)
    end
    return result
end

local function __TS__NumberIsFinite(value)
    return type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge
end

local function __TS__InstanceOf(obj, classTbl)
    if type(classTbl) ~= "table" then
        error("Right-hand side of 'instanceof' is not an object", 0)
    end
    if classTbl[Symbol.hasInstance] ~= nil then
        return not not classTbl[Symbol.hasInstance](classTbl, obj)
    end
    if type(obj) == "table" then
        local luaClass = obj.constructor
        while luaClass ~= nil do
            if luaClass == classTbl then
                return true
            end
            luaClass = luaClass.____super
        end
    end
    return false
end

local function __TS__ObjectAssign(target, ...)
    local sources = {...}
    for i = 1, #sources do
        local source = sources[i]
        if type(source) == "table" then
            for key in pairs(source) do
                target[key] = source[key]
            end
        end
    end
    return target
end
-- End of Lua Library inline imports
local ____exports = {}
local protect, mountedFrames, mountedTrees
local ____measureLayout = require("ui.layout.measureLayout")
local measureLayout = ____measureLayout.measureLayout
local ____Background = require("ui.decorations.Background")
local Background = ____Background.Background
local ____Border = require("ui.decorations.Border")
local Border = ____Border.Border
local ____statusBarTextures = require("ui.decorations.statusBarTextures")
local resolveStatusBarTexture = ____statusBarTextures.resolveStatusBarTexture
local ____Resources = require("datasources.Resources")
local HP = ____Resources.HP
local ____SecureButton = require("platform.SecureButton")
local createSecureButton = ____SecureButton.createSecureButton
local configureSecureButton = ____SecureButton.configureSecureButton
local validateSecureButton = ____SecureButton.validateSecureButton
function protect(self, root, tree)
    local ____temp_2 = not tree.protected
    if ____temp_2 then
        local ____this_1
        ____this_1 = root
        local ____opt_0 = ____this_1.IsProtected
        ____temp_2 = (____opt_0 and ____opt_0(____this_1)) ~= true
    end
    if ____temp_2 then
        return false
    end
    tree.protected = true
    if tree.listener == nil then
        local listener = CreateFrame("Frame", nil, UIParent)
        tree.listener = listener
        local ____tree_frames_3 = tree.frames
        ____tree_frames_3[#____tree_frames_3 + 1] = listener
        listener:RegisterEvent("PLAYER_REGEN_ENABLED")
        listener:SetScript(
            "OnEvent",
            function()
                if tree.pendingUnmount then
                    ____exports.unmount(nil, root)
                else
                    for ____, refresh in ipairs(tree.visibility) do
                        refresh(nil)
                    end
                end
            end
        )
    end
    return true
end
function ____exports.unmount(self, frame)
    local tree = mountedTrees:get(frame)
    if tree == nil then
        return
    end
    if protect(nil, frame, tree) and InCombatLockdown() then
        tree.pendingUnmount = true
        return
    end
    for ____, dispose in ipairs(tree.bindings) do
        dispose(nil)
    end
    for ____, decoration in ipairs(tree.decorations) do
        decoration:dispose()
    end
    for ____, child in ipairs(tree.frames) do
        child:UnregisterAllEvents()
        child:SetScript("OnEvent", nil)
        child:SetScript("OnUpdate", nil)
        child:Hide()
    end
    for ____, cell in ipairs(tree.cells) do
        mountedFrames:delete(cell.props)
    end
    mountedTrees:delete(frame)
end
mountedFrames = __TS__New(Map)
mountedTrees = __TS__New(Map)
--- Creates the tree before resolving anchors. Positive y moves down.
function ____exports.mount(self, element, parent, rootAnchor)
    if parent == nil then
        parent = UIParent
    end
    local frames = __TS__New(Map)
    local pending = {}
    local rootProps = element.props
    local measured = measureLayout(
        nil,
        element,
        {
            width = rootProps.width == "inherit" and parent:GetWidth() or nil,
            height = rootProps.height == "inherit" and parent:GetHeight() or nil
        }
    )
    local ____temp_7 = parent ~= UIParent
    if ____temp_7 then
        local ____this_5
        ____this_5 = parent
        local ____opt_4 = ____this_5.IsProtected
        local ____temp_6 = ____opt_4 and ____opt_4(____this_5)
        if ____temp_6 == nil then
            ____temp_6 = false
        end
        ____temp_7 = ____temp_6
    end
    local protectedTree = ____temp_7
    local seen = __TS__New(Set)
    local function validate(self, item)
        if seen:has(item.cell.props) or mountedFrames:has(item.cell.props) then
            error("A Cell can only be mounted once at a time")
        end
        seen:add(item.cell.props)
        if item.cell.kind == "secureButton" then
            protectedTree = true
            validateSecureButton(nil, item.cell.props)
        end
        for ____, child in ipairs(item.children) do
            validate(nil, child)
        end
    end
    validate(nil, measured)
    if protectedTree and InCombatLockdown() then
        error("SecureButton: mount protected UI outside combat")
    end
    local function create(self, measured, parent, placement)
        local ____measured_8 = measured
        local cell = ____measured_8.cell
        local width = ____measured_8.width
        local height = ____measured_8.height
        if frames:has(cell.props) or mountedFrames:has(cell.props) then
            error("A Cell can only be mounted once at a time")
        end
        local frame = cell.kind == "progress" and CreateFrame("StatusBar", nil, parent) or (cell.kind == "secureButton" and createSecureButton(nil, parent, cell.props) or (cell.kind == "button" and CreateFrame("Button", nil, parent) or CreateFrame("Frame", nil, parent)))
        frame:Hide()
        local ____frame_EnableMouse_11 = frame.EnableMouse
        local ____temp_10 = cell.kind == "secureButton" or cell.kind == "button"
        if not ____temp_10 then
            local ____cell_props_clickThrough_9 = cell.props.clickThrough
            if ____cell_props_clickThrough_9 == nil then
                ____cell_props_clickThrough_9 = true
            end
            ____temp_10 = not ____cell_props_clickThrough_9
        end
        ____frame_EnableMouse_11(frame, ____temp_10)
        frames:set(cell.props, frame)
        pending[#pending + 1] = {
            cell = cell,
            width = width,
            height = height,
            margin = measured.margin,
            frame = frame,
            parent = parent,
            placement = placement
        }
        frame:SetSize(width, height)
        do
            local index = 0
            while index < #measured.children do
                local ____create_15 = create
                local ____measured_children_index_14 = measured.children[index + 1]
                local ____opt_12 = measured.placements
                ____create_15(nil, ____measured_children_index_14, frame, ____opt_12 and ____opt_12[index + 1])
                index = index + 1
            end
        end
        return frame
    end
    local root = create(nil, measured, parent)
    local anchors = __TS__New(Map)
    for ____, item in ipairs(pending) do
        local position = item.cell.props
        if item.placement ~= nil then
            anchors:set(item.frame, item.parent)
        elseif position.mode == "absolute" then
            anchors:set(item.frame, UIParent)
        else
            local target = position.relativeTo == nil and item.parent or frames:get(position.relativeTo.props)
            if target == nil then
                error("relativeTo must reference a Cell in the same mounted tree")
            end
            if target == item.frame then
                error("A Cell cannot anchor to itself")
            end
            anchors:set(item.frame, target)
        end
    end
    for ____, item in ipairs(pending) do
        local target = anchors:get(item.frame)
        while target ~= nil do
            if target == item.frame then
                error("Cell positioning contains an anchor cycle")
            end
            target = anchors:get(target)
        end
    end
    local tree = {
        frames = __TS__ArrayMap(
            pending,
            function(____, item) return item.frame end
        ),
        cells = __TS__ArrayMap(
            pending,
            function(____, item) return item.cell end
        ),
        decorations = {},
        bindings = {},
        protected = protectedTree,
        pendingUnmount = false,
        visibility = {}
    }
    mountedTrees:set(root, tree)
    do
        local function ____catch(failure)
            ____exports.unmount(nil, root)
            error(failure, 0)
        end
        local ____try, ____hasReturned = pcall(function()
            local updates = {}
            protect(nil, root, tree)
            for ____, item in ipairs(pending) do
                local sourceActive = true
                local lastVisible
                local visible = item.cell.props.visible
                local condition = item.cell.props.condition
                local function refreshVisibility()
                    if protect(nil, root, tree) and InCombatLockdown() then
                        return
                    end
                    local ____sourceActive_18 = sourceActive
                    if ____sourceActive_18 then
                        local ____temp_17
                        if type(condition) == "function" then
                            ____temp_17 = condition(nil)
                        else
                            local ____condition_16 = condition
                            if ____condition_16 == nil then
                                ____condition_16 = true
                            end
                            ____temp_17 = ____condition_16
                        end
                        ____sourceActive_18 = ____temp_17
                    end
                    local allowed = ____sourceActive_18
                    local ____temp_22 = not issecretvalue(allowed) and allowed
                    if ____temp_22 then
                        local ____temp_21 = visible and visible(nil)
                        if ____temp_21 == nil then
                            ____temp_21 = true
                        end
                        ____temp_22 = ____temp_21
                    end
                    local value = ____temp_22
                    if value == lastVisible then
                        return
                    end
                    lastVisible = value
                    if value then
                        item.frame:Show()
                    else
                        item.frame:Hide()
                    end
                end
                local ____tree_visibility_23 = tree.visibility
                ____tree_visibility_23[#____tree_visibility_23 + 1] = refreshVisibility
                local function onActiveChange(____, active)
                    sourceActive = active
                    refreshVisibility(nil)
                end
                local position = item.cell.props
                if position.alpha ~= nil then
                    local alpha = position.alpha
                    local previous
                    local function refreshAlpha()
                        local value = type(alpha) == "function" and alpha(nil) or alpha
                        if issecretvalue(value) then
                            return
                        end
                        if not __TS__NumberIsFinite(value) or value < 0 or value > 1 then
                            error("Cell alpha must be between 0 and 1")
                        end
                        if value ~= previous then
                            item.frame:SetAlpha(value)
                        end
                        previous = value
                    end
                    refreshAlpha(nil)
                    if type(alpha) == "function" then
                        updates[#updates + 1] = refreshAlpha
                    end
                end
                local target = anchors:get(item.frame)
                local ____opt_24 = item.placement
                local x = ____opt_24 and ____opt_24.x or (position.mode == "absolute" and position.x or position.offset.x)
                local ____opt_26 = item.placement
                local y = ____opt_26 and ____opt_26.y or (position.mode == "absolute" and position.y or position.offset.y)
                local ____temp_28
                if item.frame == root then
                    ____temp_28 = rootAnchor
                else
                    ____temp_28 = nil
                end
                local overrideAnchor = ____temp_28
                local anchor = overrideAnchor or (item.placement ~= nil and "TOPLEFT" or (position.anchor or "TOPLEFT"))
                local relativeAnchor = overrideAnchor or (item.placement ~= nil and "TOPLEFT" or (position.relativeAnchor or anchor))
                item.frame:SetPoint(
                    anchor,
                    target,
                    relativeAnchor,
                    x + item.margin.left,
                    -(y + item.margin.top)
                )
                if item.cell.kind == "secureButton" then
                    local props = item.cell.props
                    local ____tree_bindings_29 = tree.bindings
                    ____tree_bindings_29[#____tree_bindings_29 + 1] = configureSecureButton(nil, item.frame, props)
                    if props.cooldown ~= nil then
                        local cooldown = CreateFrame("Cooldown", nil, item.frame, "CooldownFrameTemplate")
                        local ____tree_frames_30 = tree.frames
                        ____tree_frames_30[#____tree_frames_30 + 1] = cooldown
                        cooldown:EnableMouse(false)
                        cooldown:SetAllPoints(item.frame)
                        cooldown:SetFrameLevel(item.frame:GetFrameLevel() + 2)
                        cooldown:SetDrawSwipe(true)
                        cooldown:SetDrawEdge(false)
                        local ____cooldown_SetDrawBling_32 = cooldown.SetDrawBling
                        local ____props_finishGlow_31 = props.finishGlow
                        if ____props_finishGlow_31 == nil then
                            ____props_finishGlow_31 = false
                        end
                        ____cooldown_SetDrawBling_32(cooldown, ____props_finishGlow_31)
                        cooldown:SetHideCountdownNumbers(false)
                        cooldown:SetSwipeColor(0, 0, 0, 0.7)
                        cooldown:GetCountdownFontString():SetFont("Fonts\\FRIZQT__.TTF", 13, "OUTLINE")
                        local ____tree_bindings_33 = tree.bindings
                        ____tree_bindings_33[#____tree_bindings_33 + 1] = props.cooldown:BindCooldown(cooldown)
                    end
                    if props.binding ~= nil and props.showHotkey ~= false then
                        local overlay = CreateFrame("Frame", nil, item.frame)
                        local ____tree_frames_34 = tree.frames
                        ____tree_frames_34[#____tree_frames_34 + 1] = overlay
                        overlay:EnableMouse(false)
                        overlay:SetAllPoints(item.frame)
                        overlay:SetFrameLevel(item.frame:GetFrameLevel() + 3)
                        local hotkey = overlay:CreateFontString(nil, "OVERLAY")
                        hotkey:SetAllPoints(overlay)
                        hotkey:SetFont("Fonts\\FRIZQT__.TTF", 11, "OUTLINE")
                        hotkey:SetJustifyH("RIGHT")
                        hotkey:SetJustifyV("TOP")
                        hotkey:SetTextColor(1, 1, 1, 1)
                        hotkey:SetText(props.binding)
                    end
                end
                if item.cell.kind == "button" then
                    local onClick = item.cell.props.onClick
                    local ____self_36 = item.frame
                    local ____self_36_SetScript_37 = ____self_36.SetScript
                    local ____temp_35
                    if onClick == nil then
                        ____temp_35 = nil
                    else
                        ____temp_35 = function() return onClick(nil) end
                    end
                    ____self_36_SetScript_37(____self_36, "OnClick", ____temp_35)
                    local ____tree_bindings_38 = tree.bindings
                    ____tree_bindings_38[#____tree_bindings_38 + 1] = function() return item.frame:SetScript("OnClick", nil) end
                end
                if item.cell.kind == "label" then
                    local props = item.cell.props
                    local label = item.frame:CreateFontString(nil, "OVERLAY")
                    label:SetAllPoints(item.frame)
                    label:SetFont(props.font or "Fonts\\FRIZQT__.TTF", props.fontSize or 12, "OUTLINE")
                    label:SetJustifyH(props.align or "LEFT")
                    label:SetJustifyV("MIDDLE")
                    local color = props.color
                    label:SetTextColor(color and color.r or 1, color and color.g or 1, color and color.b or 1, color and color.a or 1)
                    local text = props.text
                    if type(text) == "function" then
                        local previous
                        updates[#updates + 1] = function()
                            local value = text(nil)
                            if issecretvalue(value) or value ~= previous then
                                label:SetText(value)
                            end
                            if not issecretvalue(value) then
                                previous = value
                            end
                        end
                    else
                        label:SetText(text)
                    end
                end
                if item.cell.kind == "icon" then
                    local props = item.cell.props
                    local texture = item.frame:CreateTexture(nil, "OVERLAY")
                    texture:SetAllPoints(item.frame)
                    local uv = props.texCoords or ({0, 1, 0, 1})
                    texture:SetTexCoord(uv[1], uv[2], uv[3], uv[4])
                    texture:SetTexture(props.texture)
                    local ____opt_47 = props.textureSource
                    if ____opt_47 ~= nil then
                        ____opt_47:BindTo(item.frame, texture, onActiveChange)
                    end
                end
                if item.cell.kind == "progress" then
                    local props = item.cell.props
                    local bar = item.frame
                    local ____opt_49 = props.foreground
                    local color = ____opt_49 and ____opt_49.color or props.color
                    local ____bar_SetStatusBarTexture_54 = bar.SetStatusBarTexture
                    local ____resolveStatusBarTexture_53 = resolveStatusBarTexture
                    local ____opt_51 = props.foreground
                    ____bar_SetStatusBarTexture_54(
                        bar,
                        ____resolveStatusBarTexture_53(nil, ____opt_51 and ____opt_51.texture or props.texture or "solid")
                    )
                    bar:SetStatusBarColor(color and color.r or 1, color and color.g or 1, color and color.b or 1, color and color.a or 1)
                    if props.foreground ~= nil then
                        local fill = bar:GetStatusBarTexture()
                        local ____fill_SetHorizTile_64 = fill.SetHorizTile
                        local ____props_foreground_tileX_63 = props.foreground.tileX
                        if ____props_foreground_tileX_63 == nil then
                            ____props_foreground_tileX_63 = false
                        end
                        ____fill_SetHorizTile_64(fill, ____props_foreground_tileX_63)
                        local ____fill_SetVertTile_66 = fill.SetVertTile
                        local ____props_foreground_tileY_65 = props.foreground.tileY
                        if ____props_foreground_tileY_65 == nil then
                            ____props_foreground_tileY_65 = false
                        end
                        ____fill_SetVertTile_66(fill, ____props_foreground_tileY_65)
                        fill:SetBlendMode(props.foreground.blendMode or "BLEND")
                        local uv = props.foreground.texCoords or ({0, 1, 0, 1})
                        fill:SetTexCoord(uv[1], uv[2], uv[3], uv[4])
                    end
                    bar:SetOrientation(props.orientation == "vertical" and "VERTICAL" or "HORIZONTAL")
                    local ____bar_SetReverseFill_68 = bar.SetReverseFill
                    local ____props_reverse_67 = props.reverse
                    if ____props_reverse_67 == nil then
                        ____props_reverse_67 = false
                    end
                    ____bar_SetReverseFill_68(bar, ____props_reverse_67)
                    bar:SetMinMaxValues(props.min or 0, props.max or 100)
                    local source = item.cell.source or props.source
                    if source ~= nil then
                        local healPredictionBar
                        local absorbPredictionBar
                        if __TS__InstanceOf(source, HP) then
                            local function overlay(____, style, heal)
                                bar:SetClipsChildren(true)
                                local layer = CreateFrame("StatusBar", nil, bar)
                                local ____tree_frames_69 = tree.frames
                                ____tree_frames_69[#____tree_frames_69 + 1] = layer
                                layer:EnableMouse(false)
                                layer:SetFrameLevel(bar:GetFrameLevel())
                                layer:SetSize(item.width, item.height)
                                layer:SetStatusBarTexture(resolveStatusBarTexture(nil, style.texture or "solid"))
                                local tint = style.color
                                layer:SetStatusBarColor(tint.r, tint.g, tint.b, tint.a or 0.5)
                                local texture = layer:GetStatusBarTexture()
                                texture:SetBlendMode(style.blendMode or "BLEND")
                                local ____texture_SetHorizTile_71 = texture.SetHorizTile
                                local ____style_tileX_70 = style.tileX
                                if ____style_tileX_70 == nil then
                                    ____style_tileX_70 = false
                                end
                                ____texture_SetHorizTile_71(texture, ____style_tileX_70)
                                local ____texture_SetVertTile_73 = texture.SetVertTile
                                local ____style_tileY_72 = style.tileY
                                if ____style_tileY_72 == nil then
                                    ____style_tileY_72 = false
                                end
                                ____texture_SetVertTile_73(texture, ____style_tileY_72)
                                local uv = style.texCoords or ({0, 1, 0, 1})
                                texture:SetTexCoord(uv[1], uv[2], uv[3], uv[4])
                                local vertical = props.orientation == "vertical"
                                local ____props_reverse_74 = props.reverse
                                if ____props_reverse_74 == nil then
                                    ____props_reverse_74 = false
                                end
                                local reverse = ____props_reverse_74
                                layer:SetOrientation(vertical and "VERTICAL" or "HORIZONTAL")
                                local ____layer_SetReverseFill_76 = layer.SetReverseFill
                                local ____heal_75
                                if heal then
                                    ____heal_75 = reverse
                                else
                                    ____heal_75 = not reverse
                                end
                                ____layer_SetReverseFill_76(layer, ____heal_75)
                                if heal then
                                    local point = vertical and (reverse and "TOPLEFT" or "BOTTOMLEFT") or (reverse and "TOPRIGHT" or "TOPLEFT")
                                    local relative = vertical and (reverse and "BOTTOMLEFT" or "TOPLEFT") or (reverse and "TOPLEFT" or "TOPRIGHT")
                                    layer:SetPoint(
                                        point,
                                        bar:GetStatusBarTexture(),
                                        relative,
                                        0,
                                        0
                                    )
                                else
                                    layer:SetAllPoints(bar)
                                end
                                return layer
                            end
                            local ____opt_77 = source.HealPrediction
                            if (____opt_77 and ____opt_77.IsAvailable) == true and props.healPrediction ~= false then
                                local ____props_healPrediction_81 = props.healPrediction
                                local ____opt_79 = props.healPrediction
                                healPredictionBar = overlay(
                                    nil,
                                    __TS__ObjectAssign({}, ____props_healPrediction_81, {color = ____opt_79 and ____opt_79.color or ({r = 0.4, g = 1, b = 0.5, a = 0.5})}),
                                    true
                                )
                            end
                            local ____opt_82 = source.AbsorbPrediction
                            if (____opt_82 and ____opt_82.IsAvailable) == true and props.absorbPrediction ~= false then
                                local ____props_absorbPrediction_86 = props.absorbPrediction
                                local ____opt_84 = props.absorbPrediction
                                absorbPredictionBar = overlay(
                                    nil,
                                    __TS__ObjectAssign({}, ____props_absorbPrediction_86, {color = ____opt_84 and ____opt_84.color or ({r = 0.8, g = 0.9, b = 1, a = 0.55})}),
                                    false
                                )
                            end
                        end
                        local dispose = source:BindTo(bar, {
                            min = props.min,
                            max = props.max,
                            current = props.current or props.value,
                            onActiveChange = onActiveChange,
                            healPredictionBar = healPredictionBar,
                            absorbPredictionBar = absorbPredictionBar
                        })
                        if dispose ~= nil then
                            local ____tree_bindings_87 = tree.bindings
                            ____tree_bindings_87[#____tree_bindings_87 + 1] = dispose
                        end
                    else
                        bar:SetValue(props.current or props.value or 0)
                    end
                end
                local decorations = item.cell.props.decorations
                local function attach(self, decoration)
                    if decoration ~= nil then
                        decoration:mount(item.frame, item.width, item.height)
                        local ____tree_decorations_88 = tree.decorations
                        ____tree_decorations_88[#____tree_decorations_88 + 1] = decoration
                    end
                end
                local progress = item.cell.kind == "progress" and item.cell.props or nil
                local ____attach_96 = attach
                local ____temp_95
                if (progress and progress.background) == false then
                    ____temp_95 = nil
                else
                    ____temp_95 = (progress and progress.background) ~= nil and __TS__New(Background, progress.background) or decorations and decorations.background
                end
                ____attach_96(nil, ____temp_95)
                local ____attach_104 = attach
                local ____temp_103
                if (progress and progress.backdrop) == false then
                    ____temp_103 = nil
                else
                    ____temp_103 = (progress and progress.backdrop) ~= nil and __TS__New(Border, progress.backdrop) or decorations and decorations.border
                end
                ____attach_104(nil, ____temp_103)
                attach(nil, decorations and decorations.glow)
                mountedFrames:set(item.cell.props, item.frame)
                refreshVisibility(nil)
                local ____this_108
                ____this_108 = item.cell.props
                local ____opt_107 = ____this_108.onMount
                local cleanup = ____opt_107 and ____opt_107(____this_108, item.frame)
                if cleanup ~= nil then
                    local ____tree_bindings_109 = tree.bindings
                    ____tree_bindings_109[#____tree_bindings_109 + 1] = cleanup
                end
                if visible ~= nil or type(condition) == "function" then
                    updates[#updates + 1] = refreshVisibility
                end
            end
            if #updates > 0 then
                local driver = CreateFrame("Frame", nil, parent)
                local ____tree_frames_110 = tree.frames
                ____tree_frames_110[#____tree_frames_110 + 1] = driver
                local elapsed = 0
                driver:SetScript(
                    "OnUpdate",
                    function(_frame, delta)
                        elapsed = elapsed + delta
                        if elapsed < 0.05 then
                            return
                        end
                        elapsed = 0
                        for ____, update in ipairs(updates) do
                            update(nil)
                        end
                    end
                )
                for ____, update in ipairs(updates) do
                    update(nil)
                end
                driver:Show()
            end
        end)
        if not ____try then
            ____catch(____hasReturned)
        end
    end
    return root
end
return ____exports

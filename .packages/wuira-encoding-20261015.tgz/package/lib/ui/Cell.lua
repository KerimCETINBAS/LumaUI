--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
local ____jsx = require("ui.primitives.jsx")
local UI = ____jsx.UI
--- Common visual descriptor accepted by the mounting API.
function ____exports.Cell(self, props, child)
    return UI:createElement("cell", props, props.child or child or ({}))
end
return ____exports

import type { TextureOptions } from "../../types/Texture";
import { Decoration } from "./Decoration";
import type { BackgroundTexture } from "./backgroundTextures";
export interface BackgroundProps extends TextureOptions<BackgroundTexture> {
}
export declare class Background extends Decoration {
    readonly props: BackgroundProps;
    constructor(props: BackgroundProps);
    protected draw(frame: wuiraNativeFrame): void;
}

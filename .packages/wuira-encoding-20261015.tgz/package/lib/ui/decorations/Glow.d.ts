import type { Color } from "../../types/Color";
import { Decoration } from "./Decoration";
export interface GlowProps {
    /** A glow sprite with transparent center; not an arbitrary filled image. */
    texture: string;
    color: Color;
    spread?: number;
}
/** Static additive glow; no per-frame update or animation. */
export declare class Glow extends Decoration {
    readonly props: GlowProps;
    constructor(props: GlowProps);
    protected draw(frame: wuiraNativeFrame, width: number, height: number): void;
}

export declare const statusBarTextures: {
    readonly solid: {
        readonly label: "Solid";
        readonly path: "Interface\\Buttons\\WHITE8X8";
    };
    readonly blizzard: {
        readonly label: "Blizzard Status Bar";
        readonly path: "Interface\\TargetingFrame\\UI-StatusBar";
    };
};
/** Accepts catalog names or a native/custom texture path. */
export declare function resolveStatusBarTexture(texture: string): string;

--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
____exports.backgroundTextures = {
    solid = {label = "Solid", path = "Interface\\Buttons\\WHITE8X8"},
    tooltip = {label = "Blizzard Tooltip", path = "Interface\\Tooltips\\UI-Tooltip-Background"},
    dialog = {label = "Blizzard Dialog", path = "Interface\\DialogFrame\\UI-DialogBox-Background"},
    dialogDark = {label = "Blizzard Dialog Dark", path = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark"},
    dialogGold = {label = "Blizzard Dialog Gold", path = "Interface\\DialogFrame\\UI-DialogBox-Gold-Background"}
}
return ____exports

export declare const backgroundTextures: {
    readonly solid: {
        readonly label: "Solid";
        readonly path: "Interface\\Buttons\\WHITE8X8";
    };
    readonly tooltip: {
        readonly label: "Blizzard Tooltip";
        readonly path: "Interface\\Tooltips\\UI-Tooltip-Background";
    };
    readonly dialog: {
        readonly label: "Blizzard Dialog";
        readonly path: "Interface\\DialogFrame\\UI-DialogBox-Background";
    };
    readonly dialogDark: {
        readonly label: "Blizzard Dialog Dark";
        readonly path: "Interface\\DialogFrame\\UI-DialogBox-Background-Dark";
    };
    readonly dialogGold: {
        readonly label: "Blizzard Dialog Gold";
        readonly path: "Interface\\DialogFrame\\UI-DialogBox-Gold-Background";
    };
};
export type BackgroundTexture = keyof typeof backgroundTextures | {
    path: string;
};

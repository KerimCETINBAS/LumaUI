--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end

local function __TS__ClassExtends(target, base)
    target.____super = base
    local staticMetatable = setmetatable({__index = base}, base)
    setmetatable(target, staticMetatable)
    local baseMetatable = getmetatable(base)
    if baseMetatable then
        if type(baseMetatable.__index) == "function" then
            staticMetatable.__index = baseMetatable.__index
        end
        if type(baseMetatable.__newindex) == "function" then
            staticMetatable.__newindex = baseMetatable.__newindex
        end
    end
    setmetatable(target.prototype, base.prototype)
    if type(base.prototype.__index) == "function" then
        target.prototype.__index = base.prototype.__index
    end
    if type(base.prototype.__newindex) == "function" then
        target.prototype.__newindex = base.prototype.__newindex
    end
    if type(base.prototype.__tostring) == "function" then
        target.prototype.__tostring = base.prototype.__tostring
    end
end
-- End of Lua Library inline imports
local ____exports = {}
local ____Decoration = require("ui.decorations.Decoration")
local Decoration = ____Decoration.Decoration
local ____backgroundTextures = require("ui.decorations.backgroundTextures")
local backgroundTextures = ____backgroundTextures.backgroundTextures
____exports.Background = __TS__Class()
local Background = ____exports.Background
Background.name = "Background"
__TS__ClassExtends(Background, Decoration)
function Background.prototype.____constructor(self, props)
    Decoration.prototype.____constructor(self)
    self.props = props
end
function Background.prototype.draw(self, frame)
    local texture = self:texture(frame, "BACKGROUND")
    local color = self.props.color or ({r = 1, g = 1, b = 1})
    texture:SetAllPoints(frame)
    if self.props.texture ~= nil then
        local selected = self.props.texture
        local path = type(selected) == "string" and backgroundTextures[selected].path or selected.path
        texture:SetTexture(path)
        texture:SetVertexColor(color.r, color.g, color.b, color.a or 1)
    else
        texture:SetColorTexture(color.r, color.g, color.b, color.a or 1)
    end
    local ____texture_SetHorizTile_1 = texture.SetHorizTile
    local ____self_props_tileX_0 = self.props.tileX
    if ____self_props_tileX_0 == nil then
        ____self_props_tileX_0 = false
    end
    ____texture_SetHorizTile_1(texture, ____self_props_tileX_0)
    local ____texture_SetVertTile_3 = texture.SetVertTile
    local ____self_props_tileY_2 = self.props.tileY
    if ____self_props_tileY_2 == nil then
        ____self_props_tileY_2 = false
    end
    ____texture_SetVertTile_3(texture, ____self_props_tileY_2)
    texture:SetBlendMode(self.props.blendMode or "BLEND")
    local uv = self.props.texCoords or ({0, 1, 0, 1})
    texture:SetTexCoord(uv[1], uv[2], uv[3], uv[4])
end
return ____exports

--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
____exports.statusBarTextures = {solid = {label = "Solid", path = "Interface\\Buttons\\WHITE8X8"}, blizzard = {label = "Blizzard Status Bar", path = "Interface\\TargetingFrame\\UI-StatusBar"}}
--- Accepts catalog names or a native/custom texture path.
function ____exports.resolveStatusBarTexture(self, texture)
    local preset = ____exports.statusBarTextures[texture]
    return preset == nil and texture or preset.path
end
return ____exports

--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end

local function __TS__ClassExtends(target, base)
    target.____super = base
    local staticMetatable = setmetatable({__index = base}, base)
    setmetatable(target, staticMetatable)
    local baseMetatable = getmetatable(base)
    if baseMetatable then
        if type(baseMetatable.__index) == "function" then
            staticMetatable.__index = baseMetatable.__index
        end
        if type(baseMetatable.__newindex) == "function" then
            staticMetatable.__newindex = baseMetatable.__newindex
        end
    end
    setmetatable(target.prototype, base.prototype)
    if type(base.prototype.__index) == "function" then
        target.prototype.__index = base.prototype.__index
    end
    if type(base.prototype.__newindex) == "function" then
        target.prototype.__newindex = base.prototype.__newindex
    end
    if type(base.prototype.__tostring) == "function" then
        target.prototype.__tostring = base.prototype.__tostring
    end
end
-- End of Lua Library inline imports
local ____exports = {}
local ____Decoration = require("ui.decorations.Decoration")
local Decoration = ____Decoration.Decoration
--- Static additive glow; no per-frame update or animation.
____exports.Glow = __TS__Class()
local Glow = ____exports.Glow
Glow.name = "Glow"
__TS__ClassExtends(Glow, Decoration)
function Glow.prototype.____constructor(self, props)
    Decoration.prototype.____constructor(self)
    self.props = props
end
function Glow.prototype.draw(self, frame, width, height)
    local texture = self:texture(frame, "OVERLAY")
    local spread = math.max(0, self.props.spread or 8)
    local color = self.props.color
    texture:SetPoint(
        "TOPLEFT",
        frame,
        "TOPLEFT",
        -spread,
        spread
    )
    texture:SetSize(width + 2 * spread, height + 2 * spread)
    texture:SetTexture(self.props.texture)
    texture:SetVertexColor(color.r, color.g, color.b, color.a or 1)
    texture:SetBlendMode("ADD")
end
return ____exports

/** Owns reusable native regions. One instance belongs to one mounted Cell. */
export declare abstract class Decoration {
    private active;
    private textures;
    private frames;
    private textureIndex;
    private frameIndex;
    mount(frame: wuiraNativeFrame, width: number, height: number): void;
    dispose(): void;
    protected texture(parent: wuiraNativeFrame, layer: wuiraDrawLayer): wuiraNativeTexture;
    protected backdrop(parent: wuiraNativeFrame): wuiraNativeFrame;
    protected abstract draw(frame: wuiraNativeFrame, width: number, height: number): void;
}

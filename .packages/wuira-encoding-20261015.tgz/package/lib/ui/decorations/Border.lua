--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end

local function __TS__ClassExtends(target, base)
    target.____super = base
    local staticMetatable = setmetatable({__index = base}, base)
    setmetatable(target, staticMetatable)
    local baseMetatable = getmetatable(base)
    if baseMetatable then
        if type(baseMetatable.__index) == "function" then
            staticMetatable.__index = baseMetatable.__index
        end
        if type(baseMetatable.__newindex) == "function" then
            staticMetatable.__newindex = baseMetatable.__newindex
        end
    end
    setmetatable(target.prototype, base.prototype)
    if type(base.prototype.__index) == "function" then
        target.prototype.__index = base.prototype.__index
    end
    if type(base.prototype.__newindex) == "function" then
        target.prototype.__newindex = base.prototype.__newindex
    end
    if type(base.prototype.__tostring) == "function" then
        target.prototype.__tostring = base.prototype.__tostring
    end
end
-- End of Lua Library inline imports
local ____exports = {}
local ____Decoration = require("ui.decorations.Decoration")
local Decoration = ____Decoration.Decoration
local ____borderTextures = require("ui.decorations.borderTextures")
local borderTextures = ____borderTextures.borderTextures
____exports.Border = __TS__Class()
local Border = ____exports.Border
Border.name = "Border"
__TS__ClassExtends(Border, Decoration)
function Border.prototype.____constructor(self, props)
    Decoration.prototype.____constructor(self)
    self.props = props
end
function Border.prototype.draw(self, frame, width, height)
    local selected = self.props.texture or "solid"
    local style = type(selected) == "string" and borderTextures[selected] or selected
    local color = self.props.color
    local thickness = self.props.thickness or style.edgeSize
    if thickness <= 0 then
        return
    end
    if style.path ~= "" then
        if (self.props.radius or 0) > 0 then
            error("Native border textures define their own corners; radius requires solid")
        end
        local border = self:backdrop(frame)
        border:SetBackdrop({edgeFile = style.path, edgeSize = thickness})
        border:SetBackdropBorderColor(color.r, color.g, color.b, color.a or 1)
        return
    end
    local t = math.min(thickness, width / 2, height / 2)
    local radius = math.min(
        math.max(0, self.props.radius or 0),
        width / 2,
        height / 2
    )
    if radius > 0 then
        self:rounded(
            frame,
            width,
            height,
            t,
            radius
        )
        return
    end
    self:strip(
        frame,
        0,
        0,
        width,
        t
    )
    self:strip(
        frame,
        0,
        height - t,
        width,
        t
    )
    self:strip(
        frame,
        0,
        t,
        t,
        height - 2 * t
    )
    self:strip(
        frame,
        width - t,
        t,
        t,
        height - 2 * t
    )
end
function Border.prototype.rounded(self, frame, width, height, t, radius)
    local extent = math.max(radius, t)
    local rows = math.min(
        32,
        math.ceil(extent)
    )
    local step = extent / rows
    local innerRadius = math.max(0, radius - t)
    do
        local row = 0
        while row < rows do
            local y = (row + 0.5) * step
            local distance = math.max(0, radius - y)
            local outer = y < radius and radius - math.sqrt(math.max(0, radius * radius - distance * distance)) or 0
            local inner = y < t and width / 2 or (y < radius and t + innerRadius - math.sqrt(math.max(0, innerRadius * innerRadius - distance * distance)) or t)
            local span = math.max(0, inner - outer)
            self:strip(
                frame,
                outer,
                row * step,
                span,
                step
            )
            self:strip(
                frame,
                width - inner,
                row * step,
                span,
                step
            )
            self:strip(
                frame,
                outer,
                height - (row + 1) * step,
                span,
                step
            )
            self:strip(
                frame,
                width - inner,
                height - (row + 1) * step,
                span,
                step
            )
            row = row + 1
        end
    end
    self:strip(
        frame,
        0,
        extent,
        t,
        height - 2 * extent
    )
    self:strip(
        frame,
        width - t,
        extent,
        t,
        height - 2 * extent
    )
end
function Border.prototype.strip(self, frame, x, y, width, height)
    if width <= 0 or height <= 0 then
        return
    end
    local texture = self:texture(frame, "OVERLAY")
    local color = self.props.color
    texture:SetSize(width, height)
    texture:SetPoint(
        "TOPLEFT",
        frame,
        "TOPLEFT",
        x,
        -y
    )
    texture:SetColorTexture(color.r, color.g, color.b, color.a or 1)
end
return ____exports

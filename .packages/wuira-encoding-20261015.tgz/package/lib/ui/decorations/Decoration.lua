--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end
-- End of Lua Library inline imports
local ____exports = {}
--- Owns reusable native regions. One instance belongs to one mounted Cell.
____exports.Decoration = __TS__Class()
local Decoration = ____exports.Decoration
Decoration.name = "Decoration"
function Decoration.prototype.____constructor(self)
    self.active = false
    self.textures = {}
    self.frames = {}
    self.textureIndex = 0
    self.frameIndex = 0
end
function Decoration.prototype.mount(self, frame, width, height)
    if self.active then
        error("Decoration is already mounted; create a separate instance per Cell")
    end
    self.active = true
    self.textureIndex = 0
    self.frameIndex = 0
    do
        local function ____catch(failure)
            self:dispose()
            error(failure, 0)
        end
        local ____try, ____hasReturned = pcall(function()
            self:draw(frame, width, height)
        end)
        if not ____try then
            ____catch(____hasReturned)
        end
    end
end
function Decoration.prototype.dispose(self)
    for ____, texture in ipairs(self.textures) do
        texture:Hide()
    end
    for ____, frame in ipairs(self.frames) do
        frame:Hide()
    end
    self.active = false
end
function Decoration.prototype.texture(self, parent, layer)
    local texture = self.textures[self.textureIndex + 1]
    if texture == nil then
        texture = parent:CreateTexture(nil, layer)
        local ____self_textures_0 = self.textures
        ____self_textures_0[#____self_textures_0 + 1] = texture
    else
        texture:SetParent(parent)
        texture:ClearAllPoints()
    end
    self.textureIndex = self.textureIndex + 1
    texture:Show()
    return texture
end
function Decoration.prototype.backdrop(self, parent)
    local frame = self.frames[self.frameIndex + 1]
    if frame == nil then
        frame = CreateFrame("Frame", nil, parent, "BackdropTemplate")
        local ____self_frames_1 = self.frames
        ____self_frames_1[#____self_frames_1 + 1] = frame
    else
        frame:SetParent(parent)
        frame:ClearAllPoints()
    end
    self.frameIndex = self.frameIndex + 1
    frame:EnableMouse(false)
    frame:SetAllPoints(parent)
    frame:Show()
    return frame
end
return ____exports

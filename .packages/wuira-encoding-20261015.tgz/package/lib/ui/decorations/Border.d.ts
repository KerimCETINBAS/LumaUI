import type { Color } from "../../types/Color";
import { Decoration } from "./Decoration";
import { BorderTexture } from "./borderTextures";
export interface BorderProps {
    thickness?: number;
    color: Color;
    texture?: BorderTexture;
    /** Rounded solid borders only. Native textures supply their own corner shape. */
    radius?: number;
}
export declare class Border extends Decoration {
    readonly props: BorderProps;
    constructor(props: BorderProps);
    protected draw(frame: wuiraNativeFrame, width: number, height: number): void;
    /** Bounded scanline approximation, without masks or external image assets. */
    private rounded;
    private strip;
}

export declare const borderTextures: {
    readonly solid: {
        readonly label: "Solid";
        readonly path: "";
        readonly edgeSize: 1;
    };
    readonly tooltip: {
        readonly label: "Blizzard Tooltip";
        readonly path: "Interface\\Tooltips\\UI-Tooltip-Border";
        readonly edgeSize: 16;
    };
    readonly dialog: {
        readonly label: "Blizzard Dialog";
        readonly path: "Interface\\DialogFrame\\UI-DialogBox-Border";
        readonly edgeSize: 32;
    };
    readonly dialogGold: {
        readonly label: "Blizzard Dialog Gold";
        readonly path: "Interface\\DialogFrame\\UI-DialogBox-Gold-Border";
        readonly edgeSize: 32;
    };
    readonly achievementWood: {
        readonly label: "Blizzard Achievement Wood";
        readonly path: "Interface\\AchievementFrame\\UI-Achievement-WoodBorder";
        readonly edgeSize: 16;
    };
    readonly chatBubble: {
        readonly label: "Blizzard Chat Bubble";
        readonly path: "Interface\\Tooltips\\ChatBubble-Backdrop";
        readonly edgeSize: 16;
    };
    readonly party: {
        readonly label: "Blizzard Party";
        readonly path: "Interface\\CHARACTERFRAME\\UI-Party-Border";
        readonly edgeSize: 16;
    };
};
export type BorderTexture = keyof typeof borderTextures | {
    path: string;
    edgeSize: number;
};

--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end
-- End of Lua Library inline imports
local ____exports = {}
--- A screen-space drag proxy. Protected targets are positioned only outside combat.
____exports.FrameMover = __TS__Class()
local FrameMover = ____exports.FrameMover
FrameMover.name = "FrameMover"
function FrameMover.prototype.____constructor(self, target, options)
    self.target = target
    self.options = options
    self.dragging = false
    self.disposed = false
    if InCombatLockdown() then
        error("FrameMover: create outside combat")
    end
    local frame = CreateFrame("Frame", nil, UIParent)
    self.Frame = frame
    frame:SetFrameStrata("DIALOG")
    frame:SetSize(
        target:GetWidth(),
        target:GetHeight()
    )
    frame:EnableMouse(true)
    frame:SetMovable(true)
    frame:SetClampedToScreen(true)
    frame:RegisterForDrag("LeftButton")
    local x, y = target:GetCenter()
    local screenX, screenY = UIParent:GetCenter()
    if x == nil or y == nil or screenX == nil or screenY == nil then
        error("FrameMover: target has no screen position")
    end
    frame:SetPoint(
        "CENTER",
        UIParent,
        "CENTER",
        x - screenX,
        y - screenY
    )
    local texture = frame:CreateTexture(nil, "BACKGROUND")
    texture:SetAllPoints(frame)
    texture:SetColorTexture(0.15, 0.5, 0.8, 0.45)
    local label = frame:CreateFontString(nil, "OVERLAY")
    label:SetAllPoints(frame)
    label:SetFont("Fonts\\FRIZQT__.TTF", 12, "OUTLINE")
    label:SetText(options.label)
    frame:SetScript(
        "OnDragStart",
        function()
            if self.disposed or InCombatLockdown() then
                return
            end
            self.dragging = true
            frame:StartMoving()
            frame:SetScript(
                "OnUpdate",
                function() return self:Update() end
            )
        end
    )
    frame:SetScript(
        "OnDragStop",
        function() return self:Stop(true) end
    )
    frame:RegisterEvent("PLAYER_REGEN_DISABLED")
    frame:SetScript(
        "OnEvent",
        function() return self:Dispose() end
    )
    frame:Show()
end
function FrameMover.prototype.Update(self)
    if not self.dragging or InCombatLockdown() then
        return
    end
    local x, y = self.Frame:GetCenter()
    local screenX, screenY = UIParent:GetCenter()
    if x == nil or y == nil or screenX == nil or screenY == nil then
        return
    end
    self.last = {x = x - screenX, y = screenY - y}
    self.target:ClearAllPoints()
    self.target:SetPoint(
        "CENTER",
        UIParent,
        "CENTER",
        self.last.x,
        -self.last.y
    )
end
function FrameMover.prototype.Stop(self, commit)
    if not self.dragging then
        return
    end
    self:Update()
    self.dragging = false
    self.Frame:StopMovingOrSizing()
    self.Frame:SetScript("OnUpdate", nil)
    if commit and self.last ~= nil then
        self.options:onMove(self.last)
    end
end
function FrameMover.prototype.Dispose(self)
    if self.disposed then
        return
    end
    self.disposed = true
    self:Stop(true)
    self.Frame:UnregisterAllEvents()
    self.Frame:SetScript("OnEvent", nil)
    self.Frame:SetScript("OnDragStart", nil)
    self.Frame:SetScript("OnDragStop", nil)
    self.Frame:EnableMouse(false)
    self.Frame:RegisterForDrag()
    self.Frame:Hide()
end
return ____exports

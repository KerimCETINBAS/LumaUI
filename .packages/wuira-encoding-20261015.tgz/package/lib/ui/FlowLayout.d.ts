import type { LayoutProps, ILayout } from "./Layout";
import type { Element, Children } from "./primitives/jsx";
export interface FlowOptions {
    direction: "horizontal" | "vertical";
    /** Wrap to another row (horizontal) or column (vertical) when full. */
    grow?: boolean;
    /** Space between rows/columns; defaults to gap. */
    lineGap?: number;
    /** Align each row/column along the flow direction. Defaults to start. */
    justify?: "start" | "center" | "end";
}
export type FlowLayoutProps = LayoutProps & FlowOptions;
export interface IFlowLayout extends ILayout {
    kind: "flow";
    props: FlowLayoutProps;
    children: Element[];
}
export declare function FlowLayout(props: Partial<FlowLayoutProps> & {
    child?: Children;
}): Element;

--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
local ____jsx = require("ui.primitives.jsx")
local UI = ____jsx.UI
--- A normal UI button for settings and editor controls.
function ____exports.Button(self, props, child)
    return UI:createElement("button", props, props.child or child or ({}))
end
return ____exports

export interface FramePosition {
    x: number;
    y: number;
}
export interface FrameMoverOptions {
    label: string;
    onMove: (position: FramePosition) => void;
}
/** A screen-space drag proxy. Protected targets are positioned only outside combat. */
export declare class FrameMover {
    private readonly target;
    private readonly options;
    readonly Frame: wuiraNativeFrame;
    private dragging;
    private last?;
    private disposed;
    constructor(target: wuiraNativeFrame, options: FrameMoverOptions);
    private Update;
    private Stop;
    Dispose(): void;
}

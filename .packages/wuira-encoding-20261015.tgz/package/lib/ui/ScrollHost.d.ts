interface NativeScrollFrame extends wuiraNativeFrame {
    SetScrollChild(child: wuiraNativeFrame): void;
    UpdateScrollChildRect(): void;
    GetVerticalScrollRange(): number;
    GetVerticalScroll(): number;
    SetVerticalScroll(offset: number): void;
}
/** Native clipping and mouse-wheel scrolling for content mounted inside a Cell. */
export declare class ScrollHost {
    private readonly onScroll?;
    readonly Frame: NativeScrollFrame;
    private disposed;
    constructor(parent: wuiraNativeFrame, onScroll?: ((offset: number) => void) | undefined);
    SetContent(content: wuiraNativeFrame, offset?: number): void;
    ScrollBy(amount: number): void;
    ScrollTo(offset: number): void;
    Dispose(): void;
}
export {};

import type { Cell } from "./Cell";
export interface WindowOptions {
    width: number;
    height: number;
}
/** A draggable, standalone UI host. Closing releases its mounted content. */
export declare class Window {
    readonly Frame: wuiraNativeFrame;
    private content?;
    private pendingClose;
    private disposed;
    private moving;
    constructor(options: WindowOptions);
    get IsOpen(): boolean;
    Open(view: Cell | (() => Cell | void)): void;
    /** Use as a header's onMount callback, returning the cleanup to the mounted tree. */
    BindDragHandle(handle: wuiraNativeFrame): () => void;
    Close(): void;
    Dispose(): void;
    private StopMoving;
}

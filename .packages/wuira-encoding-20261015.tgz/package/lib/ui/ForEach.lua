--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__ArrayMap(self, callbackfn, thisArg)
    local result = {}
    for i = 1, #self do
        result[i] = callbackfn(thisArg, self[i], i - 1, self)
    end
    return result
end
-- End of Lua Library inline imports
local ____exports = {}
--- Expands a snapshot into siblings. It creates no native frame or subscription.
function ____exports.ForEach(self, ____bindingPattern0)
    local child
    local items
    items = ____bindingPattern0.items
    child = ____bindingPattern0.child
    if type(child) ~= "function" then
        error("ForEach requires a render function as its child")
    end
    return {
        kind = "group",
        props = {},
        children = __TS__ArrayMap(
            items,
            function(____, item, index) return child(nil, item, index) end
        )
    }
end
return ____exports

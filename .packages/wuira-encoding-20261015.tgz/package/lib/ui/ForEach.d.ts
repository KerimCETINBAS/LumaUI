import type { Element } from "./primitives/jsx";
export interface ForEachProps<T> {
    items: readonly T[];
    child: (item: T, index: number) => Element;
}
/** Expands a snapshot into siblings. It creates no native frame or subscription. */
export declare function ForEach<T>({ items, child }: ForEachProps<T>): Element;

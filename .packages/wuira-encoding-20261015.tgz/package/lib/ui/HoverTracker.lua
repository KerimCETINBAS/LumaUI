--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end

local function __TS__NumberIsFinite(value)
    return type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge
end
-- End of Lua Library inline imports
local ____exports = {}
--- Generic secure hover visibility. Callers own presentation, content and positioning.
____exports.HoverTracker = __TS__Class()
local HoverTracker = ____exports.HoverTracker
HoverTracker.name = "HoverTracker"
function HoverTracker.prototype.____constructor(self, options)
    if options == nil then
        options = {}
    end
    self.regionCount = 0
    self.disposing = false
    self.disposed = false
    if InCombatLockdown() then
        error("HoverTracker: create the tracker outside combat")
    end
    local delay = options.hideDelay or 0.25
    if not __TS__NumberIsFinite(delay) or delay < 0 then
        error("HoverTracker: hideDelay must be non-negative")
    end
    self.Trigger = CreateFrame("Frame", nil, UIParent, "SecureHandlerEnterLeaveTemplate")
    self.Popup = CreateFrame("Frame", nil, UIParent, "SecureHandlerShowHideTemplate")
    self.Trigger:EnableMouse(true)
    self.Popup:EnableMouse(false)
    self.Popup:SetFrameRef("trigger", self.Trigger)
    self.Popup:SetAttribute("hide-delay", delay)
    self.Popup:SetAttribute("region-count", 0)
    self.Popup:SetAttribute("_onshow", "\n            self:RegisterAutoHide(self:GetAttribute(\"hide-delay\"))\n            self:AddToAutoHide(self:GetFrameRef(\"trigger\"))\n            for index = 1, self:GetAttribute(\"region-count\") do\n                self:AddToAutoHide(self:GetFrameRef(\"region\" .. index))\n            end\n        ")
    self.Trigger:SetFrameRef("popup", self.Popup)
    self.Trigger:SetAttribute("_onenter", "self:GetFrameRef(\"popup\"):Show()")
    self.Popup:Hide()
    for ____, region in ipairs(options.regions or ({})) do
        self:AddRegion(region)
    end
    self.listener = CreateFrame("Frame", nil, UIParent)
    self.listener:RegisterEvent("PLAYER_REGEN_ENABLED")
    self.listener:SetScript(
        "OnEvent",
        function()
            if self.disposing then
                self:Dispose()
            end
        end
    )
end
function HoverTracker.prototype.AddRegion(self, frame)
    if self.disposing or self.disposed then
        error("HoverTracker is disposed")
    end
    if InCombatLockdown() then
        error("HoverTracker: configure regions outside combat")
    end
    self.regionCount = self.regionCount + 1
    self.Popup:SetFrameRef(
        "region" .. tostring(self.regionCount),
        frame
    )
    self.Popup:SetAttribute("region-count", self.regionCount)
    return self
end
function HoverTracker.prototype.Dispose(self)
    if self.disposed then
        return
    end
    self.disposing = true
    if InCombatLockdown() then
        return
    end
    self.Trigger:SetAttribute("_onenter", "")
    self.Trigger:Hide()
    self.Popup:Hide()
    self.listener:UnregisterAllEvents()
    self.listener:SetScript("OnEvent", nil)
    self.disposed = true
end
return ____exports

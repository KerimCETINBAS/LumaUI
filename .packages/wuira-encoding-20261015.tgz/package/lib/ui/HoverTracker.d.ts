export interface HoverFrame extends wuiraNativeFrame {
    SetFrameRef(name: string, frame: wuiraNativeFrame): void;
    SetAttribute(name: string, value: string | number): void;
}
export interface HoverTrackerOptions {
    hideDelay?: number;
    regions?: readonly wuiraNativeFrame[];
}
/** Generic secure hover visibility. Callers own presentation, content and positioning. */
export declare class HoverTracker {
    readonly Trigger: HoverFrame;
    readonly Popup: HoverFrame;
    private readonly listener;
    private regionCount;
    private disposing;
    private disposed;
    constructor(options?: HoverTrackerOptions);
    AddRegion(frame: wuiraNativeFrame): this;
    Dispose(): void;
}

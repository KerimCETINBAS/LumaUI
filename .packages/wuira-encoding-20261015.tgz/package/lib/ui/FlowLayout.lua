--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
local ____jsx = require("ui.primitives.jsx")
local UI = ____jsx.UI
function ____exports.FlowLayout(self, props)
    return UI:createElement("flow", props, props.child or ({}))
end
return ____exports

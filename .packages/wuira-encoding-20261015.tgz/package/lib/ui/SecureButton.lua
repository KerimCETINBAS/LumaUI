--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
local ____jsx = require("ui.primitives.jsx")
local UI = ____jsx.UI
--- A Cell rendered as a native SecureActionButtonTemplate, with one presentation child.
function ____exports.SecureButton(self, props, child)
    return UI:createElement("secureButton", props, props.child or child or ({}))
end
return ____exports

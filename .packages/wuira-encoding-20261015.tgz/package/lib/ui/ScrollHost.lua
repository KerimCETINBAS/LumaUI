--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end
-- End of Lua Library inline imports
local ____exports = {}
--- Native clipping and mouse-wheel scrolling for content mounted inside a Cell.
____exports.ScrollHost = __TS__Class()
local ScrollHost = ____exports.ScrollHost
ScrollHost.name = "ScrollHost"
function ScrollHost.prototype.____constructor(self, parent, onScroll)
    self.onScroll = onScroll
    self.disposed = false
    self.Frame = CreateFrame("ScrollFrame", nil, parent)
    self.Frame:SetSize(
        parent:GetWidth(),
        parent:GetHeight()
    )
    self.Frame:SetAllPoints(parent)
    self.Frame:EnableMouse(true)
    self.Frame:SetScript(
        "OnMouseWheel",
        function(_frame, delta) return self:ScrollBy(-delta * 32) end
    )
    self.Frame:Show()
end
function ScrollHost.prototype.SetContent(self, content, offset)
    if offset == nil then
        offset = 0
    end
    self.Frame:SetScrollChild(content)
    self.Frame:UpdateScrollChildRect()
    self:ScrollTo(offset)
end
function ScrollHost.prototype.ScrollBy(self, amount)
    self:ScrollTo(self.Frame:GetVerticalScroll() + amount)
end
function ScrollHost.prototype.ScrollTo(self, offset)
    if self.disposed then
        return
    end
    local value = math.max(
        0,
        math.min(
            self.Frame:GetVerticalScrollRange(),
            offset
        )
    )
    self.Frame:SetVerticalScroll(value)
    local ____opt_0 = self.onScroll
    if ____opt_0 ~= nil then
        ____opt_0(self, value)
    end
end
function ScrollHost.prototype.Dispose(self)
    if self.disposed then
        return
    end
    self.disposed = true
    self.Frame:SetScript("OnMouseWheel", nil)
    self.Frame:Hide()
end
return ____exports

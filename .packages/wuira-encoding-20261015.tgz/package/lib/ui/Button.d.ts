import type { Cell, CellProps } from "./Cell";
import type { Element } from "./primitives/jsx";
export type ButtonProps = CellProps & {
    onClick?: () => void;
    clickThrough?: false;
};
/** A normal UI button for settings and editor controls. */
export declare function Button(props: Partial<ButtonProps> & {
    child?: Element;
}, child?: Element): Cell;

--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
local ____jsx = require("ui.primitives.jsx")
local UI = ____jsx.UI
function ____exports.Label(self, props)
    return UI:createElement("label", props)
end
return ____exports

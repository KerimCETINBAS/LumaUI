interface Target {
    frame: wuiraNativeFrame;
    overlay: wuiraNativeFrame;
    onBinding: (key: string | undefined) => void;
}
/** Hover-to-bind input capture. It reports keys; the addon owns persistence and actions. */
export declare class KeybindCapture {
    private readonly onCancel;
    private readonly frame;
    private readonly targets;
    private hovered?;
    private active;
    constructor(onCancel: () => void);
    /** Independent overlays block clicks without rewriting the secure button. */
    AddTarget(frame: wuiraNativeFrame, onBinding: Target["onBinding"]): () => void;
    SetActive(active: boolean): void;
    private OnKey;
    Dispose(): void;
}
export {};

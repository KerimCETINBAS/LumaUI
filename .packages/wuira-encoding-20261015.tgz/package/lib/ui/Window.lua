--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end

local function __TS__NumberIsFinite(value)
    return type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge
end

local function __TS__CloneDescriptor(____bindingPattern0)
    local value
    local writable
    local set
    local get
    local configurable
    local enumerable
    enumerable = ____bindingPattern0.enumerable
    configurable = ____bindingPattern0.configurable
    get = ____bindingPattern0.get
    set = ____bindingPattern0.set
    writable = ____bindingPattern0.writable
    value = ____bindingPattern0.value
    local descriptor = {enumerable = enumerable == true, configurable = configurable == true}
    local hasGetterOrSetter = get ~= nil or set ~= nil
    local hasValueOrWritableAttribute = writable ~= nil or value ~= nil
    if hasGetterOrSetter and hasValueOrWritableAttribute then
        error("Invalid property descriptor. Cannot both specify accessors and a value or writable attribute.", 0)
    end
    if get or set then
        descriptor.get = get
        descriptor.set = set
    else
        descriptor.value = value
        descriptor.writable = writable == true
    end
    return descriptor
end

local __TS__DescriptorGet
do
    local getmetatable = _G.getmetatable
    local ____rawget = _G.rawget
    function __TS__DescriptorGet(self, metatable, key)
        while metatable do
            local rawResult = ____rawget(metatable, key)
            if rawResult ~= nil then
                return rawResult
            end
            local descriptors = ____rawget(metatable, "_descriptors")
            if descriptors then
                local descriptor = descriptors[key]
                if descriptor ~= nil then
                    if descriptor.get then
                        return descriptor.get(self)
                    end
                    return descriptor.value
                end
            end
            metatable = getmetatable(metatable)
        end
    end
end

local __TS__DescriptorSet
do
    local getmetatable = _G.getmetatable
    local ____rawget = _G.rawget
    local rawset = _G.rawset
    function __TS__DescriptorSet(self, metatable, key, value)
        while metatable do
            local descriptors = ____rawget(metatable, "_descriptors")
            if descriptors then
                local descriptor = descriptors[key]
                if descriptor ~= nil then
                    if descriptor.set then
                        descriptor.set(self, value)
                    else
                        if descriptor.writable == false then
                            error(
                                ((("Cannot assign to read only property '" .. key) .. "' of object '") .. tostring(self)) .. "'",
                                0
                            )
                        end
                        descriptor.value = value
                    end
                    return
                end
            end
            metatable = getmetatable(metatable)
        end
        rawset(self, key, value)
    end
end

local __TS__SetDescriptor
do
    local getmetatable = _G.getmetatable
    local function descriptorIndex(self, key)
        return __TS__DescriptorGet(
            self,
            getmetatable(self),
            key
        )
    end
    local function descriptorNewIndex(self, key, value)
        return __TS__DescriptorSet(
            self,
            getmetatable(self),
            key,
            value
        )
    end
    function __TS__SetDescriptor(target, key, desc, isPrototype)
        if isPrototype == nil then
            isPrototype = false
        end
        local ____isPrototype_0
        if isPrototype then
            ____isPrototype_0 = target
        else
            ____isPrototype_0 = getmetatable(target)
        end
        local metatable = ____isPrototype_0
        if not metatable then
            metatable = {}
            setmetatable(target, metatable)
        end
        if not isPrototype and not rawget(metatable, "_isOwnDescriptorMetatable") then
            local instanceMetatable = {}
            instanceMetatable._isOwnDescriptorMetatable = true
            setmetatable(instanceMetatable, metatable)
            setmetatable(target, instanceMetatable)
            metatable = instanceMetatable
        end
        local value = rawget(target, key)
        if value ~= nil then
            rawset(target, key, nil)
        end
        if not rawget(metatable, "_descriptors") then
            metatable._descriptors = {}
        end
        metatable._descriptors[key] = __TS__CloneDescriptor(desc)
        metatable.__index = descriptorIndex
        metatable.__newindex = descriptorNewIndex
    end
end
-- End of Lua Library inline imports
local ____exports = {}
local ____wuira = require("wuira")
local wuira = ____wuira.wuira
--- A draggable, standalone UI host. Closing releases its mounted content.
____exports.Window = __TS__Class()
local Window = ____exports.Window
Window.name = "Window"
function Window.prototype.____constructor(self, options)
    self.pendingClose = false
    self.disposed = false
    self.moving = false
    if not __TS__NumberIsFinite(options.width) or not __TS__NumberIsFinite(options.height) or options.width <= 0 or options.height <= 0 then
        error("Window requires positive finite dimensions")
    end
    local frame = CreateFrame("Frame", nil, UIParent)
    self.Frame = frame
    frame:SetSize(options.width, options.height)
    frame:SetPoint(
        "CENTER",
        UIParent,
        "CENTER",
        0,
        0
    )
    frame:SetFrameStrata("DIALOG")
    frame:SetMovable(true)
    frame:SetClampedToScreen(true)
    frame:EnableMouse(true)
    frame:EnableKeyboard(false)
    frame:Hide()
    frame:SetScript(
        "OnKeyDown",
        function(_frame, key)
            local ____opt_0 = frame.IsProtected
            if ____opt_0 and ____opt_0(frame) and InCombatLockdown() then
                if key == "ESCAPE" then
                    self:Close()
                end
                return
            end
            frame:SetPropagateKeyboardInput(key ~= "ESCAPE")
            if key == "ESCAPE" then
                self:Close()
            end
        end
    )
    frame:RegisterEvent("PLAYER_REGEN_ENABLED")
    frame:SetScript(
        "OnEvent",
        function()
            if self.pendingClose then
                self:Close()
            end
        end
    )
end
function Window.prototype.Open(self, view)
    if self.disposed then
        error("Window is disposed")
    end
    local ____this_3
    ____this_3 = self.Frame
    local ____opt_2 = ____this_3.IsProtected
    if ____opt_2 and ____opt_2(____this_3) and InCombatLockdown() then
        error("Window: update protected content outside combat")
    end
    self.pendingClose = false
    local next = wuira:Mount(view, nil, self.Frame)
    local previous = self.content
    self.content = next
    if previous ~= nil then
        wuira:Unmount(previous)
    end
    self.Frame:SetPropagateKeyboardInput(true)
    self.Frame:EnableKeyboard(true)
    self.Frame:Show()
end
function Window.prototype.BindDragHandle(self, handle)
    handle:EnableMouse(true)
    handle:RegisterForDrag("LeftButton")
    handle:SetScript(
        "OnDragStart",
        function()
            if not InCombatLockdown() then
                self.Frame:StartMoving()
                self.moving = true
            end
        end
    )
    handle:SetScript(
        "OnDragStop",
        function() return self:StopMoving() end
    )
    return function()
        self:StopMoving()
        handle:RegisterForDrag()
        handle:SetScript("OnDragStart", nil)
        handle:SetScript("OnDragStop", nil)
    end
end
function Window.prototype.Close(self)
    local ____this_5
    ____this_5 = self.Frame
    local ____opt_4 = ____this_5.IsProtected
    if ____opt_4 and ____opt_4(____this_5) and InCombatLockdown() then
        self.pendingClose = true
        return
    end
    self.pendingClose = false
    self:StopMoving()
    self.Frame:EnableKeyboard(false)
    self.Frame:Hide()
    if self.content ~= nil then
        wuira:Unmount(self.content)
    end
    self.content = nil
end
function Window.prototype.Dispose(self)
    if self.disposed then
        return
    end
    local ____this_7
    ____this_7 = self.Frame
    local ____opt_6 = ____this_7.IsProtected
    if ____opt_6 and ____opt_6(____this_7) and InCombatLockdown() then
        error("Window: dispose protected content outside combat")
    end
    self:Close()
    self.Frame:UnregisterAllEvents()
    self.Frame:SetScript("OnEvent", nil)
    self.Frame:SetScript("OnKeyDown", nil)
    self.disposed = true
end
function Window.prototype.StopMoving(self)
    if not self.moving then
        return
    end
    self.Frame:StopMovingOrSizing()
    self.moving = false
end
__TS__SetDescriptor(
    Window.prototype,
    "IsOpen",
    {get = function(self)
        return self.Frame:IsShown()
    end},
    true
)
return ____exports

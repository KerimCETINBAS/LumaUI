import type { CellProps } from "../Cell";
import type { FlowLayoutProps } from "../FlowLayout";
import type { GridLayoutProps } from "../GridLayout";
import type { ProgressBarProps } from "../ProgressBar";
import type { ProgressSource } from "../../datasources/ProgressSource";
import type { TimerSource } from "../../datasources/TimerSource";
import type { LabelProps } from "../Label";
import type { IconProps } from "../Icon";
import type { SecureButtonProps } from "../SecureButton";
import type { ButtonProps } from "../Button";
/** Declarative UI description; native frames are created by mount. */
export interface Element {
    kind: string;
    props: object;
    child?: Element;
    children?: Element[];
    source?: ProgressSource | TimerSource;
}
export type Component<P extends object> = (props: P, child?: Element) => Element;
export type Children = Element | readonly Children[];
type RenderChild = (item: never, index: number) => Element;
export declare namespace UI {
    function Fragment(): Element;
    function createElement<P extends object>(component: Component<P> | "cell" | "flow" | "grid" | "progress" | "label" | "icon" | "button" | "secureButton", props: P | undefined, ...children: (Children | RenderChild)[]): Element;
    namespace JSX {
        type Element = import("./jsx").Element;
        interface ElementChildrenAttribute {
            child: {};
        }
        interface IntrinsicElements {
            cell: Partial<CellProps> & {
                child?: Element;
            };
            flow: Partial<FlowLayoutProps> & {
                child?: Children;
            };
            grid: Partial<GridLayoutProps> & {
                child?: Children;
            };
            progress: Partial<ProgressBarProps> & {
                child?: Element;
            };
            label: Partial<LabelProps>;
            icon: Partial<IconProps>;
            secureButton: Partial<SecureButtonProps> & {
                child?: Element;
            };
            button: Partial<ButtonProps> & {
                child?: Element;
            };
        }
    }
}
export {};

--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end

local function __TS__ClassExtends(target, base)
    target.____super = base
    local staticMetatable = setmetatable({__index = base}, base)
    setmetatable(target, staticMetatable)
    local baseMetatable = getmetatable(base)
    if baseMetatable then
        if type(baseMetatable.__index) == "function" then
            staticMetatable.__index = baseMetatable.__index
        end
        if type(baseMetatable.__newindex) == "function" then
            staticMetatable.__newindex = baseMetatable.__newindex
        end
    end
    setmetatable(target.prototype, base.prototype)
    if type(base.prototype.__index) == "function" then
        target.prototype.__index = base.prototype.__index
    end
    if type(base.prototype.__newindex) == "function" then
        target.prototype.__newindex = base.prototype.__newindex
    end
    if type(base.prototype.__tostring) == "function" then
        target.prototype.__tostring = base.prototype.__tostring
    end
end
-- End of Lua Library inline imports
local ____exports = {}
local ____NativeSkin = require("skins.NativeSkin")
local NativeSkin = ____NativeSkin.NativeSkin
local ____MicroMenu = require("platform.MicroMenu")
local skinMicroMenu = ____MicroMenu.skinMicroMenu
____exports.MicroBar = __TS__Class()
local MicroBar = ____exports.MicroBar
MicroBar.name = "MicroBar"
__TS__ClassExtends(MicroBar, NativeSkin)
function MicroBar.prototype.____constructor(self)
    NativeSkin.prototype.____constructor(self, "MicroMenu")
end
function MicroBar.prototype.Style(self, options)
    local ____opt_0 = self.stopStyling
    if ____opt_0 ~= nil then
        ____opt_0(self)
    end
    self.stopStyling = skinMicroMenu(nil, options)
    return self
end
function MicroBar.prototype.Dispose(self)
    if not InCombatLockdown() then
        local ____opt_2 = self.stopStyling
        if ____opt_2 ~= nil then
            ____opt_2(self)
        end
        self.stopStyling = nil
    end
    NativeSkin.prototype.Dispose(self)
end
return ____exports

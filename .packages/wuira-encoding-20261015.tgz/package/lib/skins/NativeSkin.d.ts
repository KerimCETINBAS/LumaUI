import type { Cell } from "../ui/Cell";
import type { Anchor } from "../types/Position";
/** A presentation adapter around a game-owned frame, not a replacement widget. */
export declare abstract class NativeSkin {
    private readonly name;
    private renderer?;
    private renderPending;
    private rendering;
    private listener?;
    private disposed;
    private disposing;
    private hovered;
    private readonly views;
    private readonly hoverListeners;
    private readonly hooked;
    protected constructor(name: string);
    get Frame(): wuiraNativeFrame | undefined;
    /** Runs once the native frame exists. The callback receives this adapter, including mount(). */
    render(renderer: (this: void, bar: this) => this | void): this;
    mount(view: Cell | (() => Cell | void) | void, anchor?: Anchor): wuiraNativeFrame | undefined;
    /** Observe pointer presence over the frame and its descendants without replacing native scripts. */
    OnHover(callback: (this: void, hovered: boolean) => void): () => void;
    private watch;
    private apply;
    Dispose(): void;
}

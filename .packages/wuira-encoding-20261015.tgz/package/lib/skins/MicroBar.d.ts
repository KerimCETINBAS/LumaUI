import { NativeSkin } from "./NativeSkin";
import type { MicroMenuSkinOptions } from "../platform/MicroMenu";
export declare class MicroBar extends NativeSkin {
    private stopStyling?;
    constructor();
    Style(options: MicroMenuSkinOptions): this;
    Dispose(): void;
}

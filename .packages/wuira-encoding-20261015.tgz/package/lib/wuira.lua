--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end
-- End of Lua Library inline imports
local ____exports = {}
local ____mount = require("ui.mount")
local mount = ____mount.mount
local unmount = ____mount.unmount
local ____SlashCommands = require("platform.SlashCommands")
local registerCommand = ____SlashCommands.registerCommand
--- Public entry point for mounting JSX UI trees.
____exports.wuira = __TS__Class()
local wuira = ____exports.wuira
wuira.name = "wuira"
function wuira.prototype.____constructor(self)
end
function wuira.registerCommand(self, command, callback)
    return registerCommand(nil, command, callback)
end
function wuira.Mount(self, frame, anchor, parent)
    local ____temp_0
    if type(frame) == "function" then
        ____temp_0 = frame(nil)
    else
        ____temp_0 = frame
    end
    local view = ____temp_0
    if view == nil or view.kind == "empty" then
        return nil
    end
    return mount(nil, view, parent, anchor)
end
function wuira.Unmount(self, frame)
    unmount(nil, frame)
end
return ____exports

declare global {
    const console: {
        log(this: void, ...values: unknown[]): void;
        info(this: void, ...values: unknown[]): void;
        warn(this: void, ...values: unknown[]): void;
        error(this: void, ...values: unknown[]): void;
    };
}
export {};

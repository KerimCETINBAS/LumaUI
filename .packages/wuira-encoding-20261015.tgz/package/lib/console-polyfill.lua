--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__ArrayMap(self, callbackfn, thisArg)
    local result = {}
    for i = 1, #self do
        result[i] = callbackfn(thisArg, self[i], i - 1, self)
    end
    return result
end
-- End of Lua Library inline imports
local ____exports = {}
local function write(self, color, values)
    print((color .. table.concat(
        __TS__ArrayMap(
            values,
            function(____, value) return tostring(value) end
        ),
        " "
    )) .. "|r")
end
_G.console = {
    log = function(...)
        local values = {...}
        write(nil, "|cffffffff", values)
    end,
    info = function(...)
        local values = {...}
        write(nil, "|cff60d9c5", values)
    end,
    warn = function(...)
        local values = {...}
        write(nil, "|cffffcc00", values)
    end,
    error = function(...)
        local values = {...}
        write(nil, "|cffff5555", values)
    end
}
return ____exports

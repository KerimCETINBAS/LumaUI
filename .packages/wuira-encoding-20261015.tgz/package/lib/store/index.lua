--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end

local __TS__Symbol, Symbol
do
    local symbolMetatable = {__tostring = function(self)
        return ("Symbol(" .. (self.description or "")) .. ")"
    end}
    function __TS__Symbol(description)
        return setmetatable({description = description}, symbolMetatable)
    end
    Symbol = {
        asyncDispose = __TS__Symbol("Symbol.asyncDispose"),
        dispose = __TS__Symbol("Symbol.dispose"),
        iterator = __TS__Symbol("Symbol.iterator"),
        hasInstance = __TS__Symbol("Symbol.hasInstance"),
        species = __TS__Symbol("Symbol.species"),
        toStringTag = __TS__Symbol("Symbol.toStringTag")
    }
end

local __TS__Iterator
do
    local function iteratorGeneratorStep(self)
        local co = self.____coroutine
        local status, value = coroutine.resume(co)
        if not status then
            error(value, 0)
        end
        if coroutine.status(co) == "dead" then
            return
        end
        return true, value
    end
    local function iteratorIteratorStep(self)
        local result = self:next()
        if result.done then
            return
        end
        return true, result.value
    end
    local function iteratorStringStep(self, index)
        index = index + 1
        if index > #self then
            return
        end
        return index, string.sub(self, index, index)
    end
    function __TS__Iterator(iterable)
        if type(iterable) == "string" then
            return iteratorStringStep, iterable, 0
        elseif iterable.____coroutine ~= nil then
            return iteratorGeneratorStep, iterable
        elseif iterable[Symbol.iterator] then
            local iterator = iterable[Symbol.iterator](iterable)
            return iteratorIteratorStep, iterator
        else
            return ipairs(iterable)
        end
    end
end

local function __TS__New(target, ...)
    local instance = setmetatable({}, target.prototype)
    instance:____constructor(...)
    return instance
end

local Set
do
    Set = __TS__Class()
    Set.name = "Set"
    function Set.prototype.____constructor(self, values)
        self[Symbol.toStringTag] = "Set"
        self.size = 0
        self.nextKey = {}
        self.previousKey = {}
        if values == nil then
            return
        end
        local iterable = values
        if iterable[Symbol.iterator] then
            local iterator = iterable[Symbol.iterator](iterable)
            while true do
                local result = iterator:next()
                if result.done then
                    break
                end
                self:add(result.value)
            end
        else
            local array = values
            for ____, value in ipairs(array) do
                self:add(value)
            end
        end
    end
    function Set.prototype.add(self, value)
        local isNewValue = not self:has(value)
        if isNewValue then
            self.size = self.size + 1
        end
        if self.firstKey == nil then
            self.firstKey = value
            self.lastKey = value
        elseif isNewValue then
            self.nextKey[self.lastKey] = value
            self.previousKey[value] = self.lastKey
            self.lastKey = value
        end
        return self
    end
    function Set.prototype.clear(self)
        self.nextKey = {}
        self.previousKey = {}
        self.firstKey = nil
        self.lastKey = nil
        self.size = 0
    end
    function Set.prototype.delete(self, value)
        local contains = self:has(value)
        if contains then
            self.size = self.size - 1
            local next = self.nextKey[value]
            local previous = self.previousKey[value]
            if next ~= nil and previous ~= nil then
                self.nextKey[previous] = next
                self.previousKey[next] = previous
            elseif next ~= nil then
                self.firstKey = next
                self.previousKey[next] = nil
            elseif previous ~= nil then
                self.lastKey = previous
                self.nextKey[previous] = nil
            else
                self.firstKey = nil
                self.lastKey = nil
            end
            self.nextKey[value] = nil
            self.previousKey[value] = nil
        end
        return contains
    end
    function Set.prototype.forEach(self, callback)
        for ____, key in __TS__Iterator(self:keys()) do
            callback(nil, key, key, self)
        end
    end
    function Set.prototype.has(self, value)
        return self.nextKey[value] ~= nil or self.lastKey == value
    end
    Set.prototype[Symbol.iterator] = function(self)
        return self:values()
    end
    function Set.prototype.entries(self)
        local function getFirstKey()
            return self.firstKey
        end
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = {key, key}}
            end
        }
    end
    function Set.prototype.keys(self)
        local function getFirstKey()
            return self.firstKey
        end
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = key}
            end
        }
    end
    function Set.prototype.values(self)
        local function getFirstKey()
            return self.firstKey
        end
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = key}
            end
        }
    end
    function Set.prototype.union(self, other)
        local result = __TS__New(Set, self)
        for ____, item in __TS__Iterator(other) do
            result:add(item)
        end
        return result
    end
    function Set.prototype.intersection(self, other)
        local result = __TS__New(Set)
        for ____, item in __TS__Iterator(self) do
            if other:has(item) then
                result:add(item)
            end
        end
        return result
    end
    function Set.prototype.difference(self, other)
        local result = __TS__New(Set, self)
        for ____, item in __TS__Iterator(other) do
            result:delete(item)
        end
        return result
    end
    function Set.prototype.symmetricDifference(self, other)
        local result = __TS__New(Set, self)
        for ____, item in __TS__Iterator(other) do
            if self:has(item) then
                result:delete(item)
            else
                result:add(item)
            end
        end
        return result
    end
    function Set.prototype.isSubsetOf(self, other)
        for ____, item in __TS__Iterator(self) do
            if not other:has(item) then
                return false
            end
        end
        return true
    end
    function Set.prototype.isSupersetOf(self, other)
        for ____, item in __TS__Iterator(other) do
            if not self:has(item) then
                return false
            end
        end
        return true
    end
    function Set.prototype.isDisjointFrom(self, other)
        for ____, item in __TS__Iterator(self) do
            if other:has(item) then
                return false
            end
        end
        return true
    end
    Set[Symbol.species] = Set
end

local function __TS__NumberIsFinite(value)
    return type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge
end

local function __TS__ObjectEntries(obj)
    local result = {}
    local len = 0
    for key in pairs(obj) do
        len = len + 1
        result[len] = {key, obj[key]}
    end
    return result
end

local function __TS__TypeOf(value)
    local luaType = type(value)
    if luaType == "table" then
        return "object"
    elseif luaType == "nil" then
        return "undefined"
    else
        return luaType
    end
end

local function __TS__ObjectKeys(obj)
    local result = {}
    local len = 0
    for key in pairs(obj) do
        len = len + 1
        result[len] = key
    end
    return result
end

local function __TS__ArrayIsArray(value)
    return type(value) == "table" and (value[1] ~= nil or next(value) == nil)
end

local Map
do
    Map = __TS__Class()
    Map.name = "Map"
    function Map.prototype.____constructor(self, entries)
        self[Symbol.toStringTag] = "Map"
        self.items = {}
        self.size = 0
        self.nextKey = {}
        self.previousKey = {}
        if entries == nil then
            return
        end
        local iterable = entries
        if iterable[Symbol.iterator] then
            local iterator = iterable[Symbol.iterator](iterable)
            while true do
                local result = iterator:next()
                if result.done then
                    break
                end
                local value = result.value
                self:set(value[1], value[2])
            end
        else
            local array = entries
            for ____, kvp in ipairs(array) do
                self:set(kvp[1], kvp[2])
            end
        end
    end
    function Map.prototype.clear(self)
        self.items = {}
        self.nextKey = {}
        self.previousKey = {}
        self.firstKey = nil
        self.lastKey = nil
        self.size = 0
    end
    function Map.prototype.delete(self, key)
        local contains = self:has(key)
        if contains then
            self.size = self.size - 1
            local next = self.nextKey[key]
            local previous = self.previousKey[key]
            if next ~= nil and previous ~= nil then
                self.nextKey[previous] = next
                self.previousKey[next] = previous
            elseif next ~= nil then
                self.firstKey = next
                self.previousKey[next] = nil
            elseif previous ~= nil then
                self.lastKey = previous
                self.nextKey[previous] = nil
            else
                self.firstKey = nil
                self.lastKey = nil
            end
            self.nextKey[key] = nil
            self.previousKey[key] = nil
        end
        self.items[key] = nil
        return contains
    end
    function Map.prototype.forEach(self, callback)
        for ____, key in __TS__Iterator(self:keys()) do
            callback(nil, self.items[key], key, self)
        end
    end
    function Map.prototype.get(self, key)
        return self.items[key]
    end
    function Map.prototype.has(self, key)
        return self.nextKey[key] ~= nil or self.lastKey == key
    end
    function Map.prototype.set(self, key, value)
        local isNewValue = not self:has(key)
        if isNewValue then
            self.size = self.size + 1
        end
        self.items[key] = value
        if self.firstKey == nil then
            self.firstKey = key
            self.lastKey = key
        elseif isNewValue then
            self.nextKey[self.lastKey] = key
            self.previousKey[key] = self.lastKey
            self.lastKey = key
        end
        return self
    end
    Map.prototype[Symbol.iterator] = function(self)
        return self:entries()
    end
    function Map.prototype.entries(self)
        local function getFirstKey()
            return self.firstKey
        end
        local items = self.items
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = {key, items[key]}}
            end
        }
    end
    function Map.prototype.keys(self)
        local function getFirstKey()
            return self.firstKey
        end
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = key}
            end
        }
    end
    function Map.prototype.values(self)
        local function getFirstKey()
            return self.firstKey
        end
        local items = self.items
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = items[key]}
            end
        }
    end
    Map[Symbol.species] = Map
end

local function __TS__StringTrim(self)
    local result = string.gsub(self, "^[%s ﻿]*(.-)[%s ﻿]*$", "%1")
    return result
end

local function __TS__StringAccess(self, index)
    if index >= 0 and index < #self then
        return string.sub(self, index + 1, index + 1)
    end
end

local __TS__Unpack = table.unpack or unpack

local function __TS__Spread(iterable)
    local arr = {}
    if type(iterable) == "string" then
        for i = 0, #iterable - 1 do
            arr[i + 1] = __TS__StringAccess(iterable, i)
        end
    else
        local len = 0
        for ____, item in __TS__Iterator(iterable) do
            len = len + 1
            arr[len] = item
        end
    end
    return __TS__Unpack(arr)
end

local function __TS__CloneDescriptor(____bindingPattern0)
    local value
    local writable
    local set
    local get
    local configurable
    local enumerable
    enumerable = ____bindingPattern0.enumerable
    configurable = ____bindingPattern0.configurable
    get = ____bindingPattern0.get
    set = ____bindingPattern0.set
    writable = ____bindingPattern0.writable
    value = ____bindingPattern0.value
    local descriptor = {enumerable = enumerable == true, configurable = configurable == true}
    local hasGetterOrSetter = get ~= nil or set ~= nil
    local hasValueOrWritableAttribute = writable ~= nil or value ~= nil
    if hasGetterOrSetter and hasValueOrWritableAttribute then
        error("Invalid property descriptor. Cannot both specify accessors and a value or writable attribute.", 0)
    end
    if get or set then
        descriptor.get = get
        descriptor.set = set
    else
        descriptor.value = value
        descriptor.writable = writable == true
    end
    return descriptor
end

local __TS__DescriptorGet
do
    local getmetatable = _G.getmetatable
    local ____rawget = _G.rawget
    function __TS__DescriptorGet(self, metatable, key)
        while metatable do
            local rawResult = ____rawget(metatable, key)
            if rawResult ~= nil then
                return rawResult
            end
            local descriptors = ____rawget(metatable, "_descriptors")
            if descriptors then
                local descriptor = descriptors[key]
                if descriptor ~= nil then
                    if descriptor.get then
                        return descriptor.get(self)
                    end
                    return descriptor.value
                end
            end
            metatable = getmetatable(metatable)
        end
    end
end

local __TS__DescriptorSet
do
    local getmetatable = _G.getmetatable
    local ____rawget = _G.rawget
    local rawset = _G.rawset
    function __TS__DescriptorSet(self, metatable, key, value)
        while metatable do
            local descriptors = ____rawget(metatable, "_descriptors")
            if descriptors then
                local descriptor = descriptors[key]
                if descriptor ~= nil then
                    if descriptor.set then
                        descriptor.set(self, value)
                    else
                        if descriptor.writable == false then
                            error(
                                ((("Cannot assign to read only property '" .. key) .. "' of object '") .. tostring(self)) .. "'",
                                0
                            )
                        end
                        descriptor.value = value
                    end
                    return
                end
            end
            metatable = getmetatable(metatable)
        end
        rawset(self, key, value)
    end
end

local __TS__SetDescriptor
do
    local getmetatable = _G.getmetatable
    local function descriptorIndex(self, key)
        return __TS__DescriptorGet(
            self,
            getmetatable(self),
            key
        )
    end
    local function descriptorNewIndex(self, key, value)
        return __TS__DescriptorSet(
            self,
            getmetatable(self),
            key,
            value
        )
    end
    function __TS__SetDescriptor(target, key, desc, isPrototype)
        if isPrototype == nil then
            isPrototype = false
        end
        local ____isPrototype_0
        if isPrototype then
            ____isPrototype_0 = target
        else
            ____isPrototype_0 = getmetatable(target)
        end
        local metatable = ____isPrototype_0
        if not metatable then
            metatable = {}
            setmetatable(target, metatable)
        end
        if not isPrototype and not rawget(metatable, "_isOwnDescriptorMetatable") then
            local instanceMetatable = {}
            instanceMetatable._isOwnDescriptorMetatable = true
            setmetatable(instanceMetatable, metatable)
            setmetatable(target, instanceMetatable)
            metatable = instanceMetatable
        end
        local value = rawget(target, key)
        if value ~= nil then
            rawset(target, key, nil)
        end
        if not rawget(metatable, "_descriptors") then
            metatable._descriptors = {}
        end
        metatable._descriptors[key] = __TS__CloneDescriptor(desc)
        metatable.__index = descriptorIndex
        metatable.__newindex = descriptorNewIndex
    end
end
-- End of Lua Library inline imports
local ____exports = {}
--- Extend with data fields and defaults. A stable static Token opts into persistence.
____exports.Store = __TS__Class()
local Store = ____exports.Store
Store.name = "Store"
function Store.prototype.____constructor(self)
end
local function copy(self, value, seen)
    if seen == nil then
        seen = __TS__New(Set)
    end
    if issecretvalue(value) then
        error("Secret values cannot be stored", 0)
    end
    if value == nil or type(value) == "string" or type(value) == "boolean" then
        return value
    end
    if type(value) == "number" and __TS__NumberIsFinite(value) then
        return value
    end
    if value == nil or type(value) ~= "table" then
        error("Store supports only finite numbers, strings, booleans, arrays and data objects", 0)
    end
    if seen:has(value) then
        error("Store does not support cyclic data", 0)
    end
    seen:add(value)
    local fields = {}
    for ____, ____value in ipairs(__TS__ObjectEntries(value)) do
        local key = ____value[1]
        local field = ____value[2]
        fields[key] = copy(nil, field, seen)
    end
    seen:delete(value)
    return fields
end
--- Fill new fields and reject incompatible saved field types using current defaults.
local function restore(self, defaults, saved)
    if saved == nil or __TS__TypeOf(saved) ~= __TS__TypeOf(defaults) or saved == nil then
        return copy(nil, defaults)
    end
    if type(defaults) == "table" and defaults ~= nil and #__TS__ObjectKeys(defaults) == 0 then
        return copy(nil, saved)
    end
    if __TS__ArrayIsArray(defaults) then
        local ____Array_isArray_result_0
        if __TS__ArrayIsArray(saved) then
            ____Array_isArray_result_0 = copy(nil, saved)
        else
            ____Array_isArray_result_0 = copy(nil, defaults)
        end
        return ____Array_isArray_result_0
    end
    if type(defaults) == "table" and defaults ~= nil then
        if __TS__ArrayIsArray(saved) then
            return copy(nil, defaults)
        end
        local result = copy(nil, saved)
        for ____, ____value in ipairs(__TS__ObjectEntries(defaults)) do
            local key = ____value[1]
            local value = ____value[2]
            result[key] = restore(nil, value, result[key])
        end
        return result
    end
    return copy(nil, saved)
end
____exports.StoreRegistry = __TS__Class()
local StoreRegistry = ____exports.StoreRegistry
StoreRegistry.name = "StoreRegistry"
function StoreRegistry.prototype.____constructor(self, options)
    self.options = options
    self.memory = __TS__New(Map)
    self.observers = __TS__New(Map)
    self.tokens = __TS__New(Map)
    self.updating = __TS__New(Set)
    self.readyCallbacks = {}
    if options == nil then
        return
    end
    if string.match(options.variable, "^[%a_][%w_]*$") == nil then
        error("Invalid SavedVariables name", 0)
    end
    local ____opt_1 = C_AddOns and C_AddOns.IsAddOnLoaded
    if ____opt_1 and ____opt_1(options.addon) then
        self:Load()
        return
    end
    self.listener = CreateFrame("Frame", nil, UIParent)
    self.listener:RegisterEvent("ADDON_LOADED")
    self.listener:SetScript(
        "OnEvent",
        function(_frame, _event, addon)
            if addon ~= options.addon then
                return
            end
            self:Load()
            local ____opt_5 = self.listener
            if ____opt_5 ~= nil then
                ____opt_5:UnregisterAllEvents()
            end
            local ____opt_7 = self.listener
            if ____opt_7 ~= nil then
                ____opt_7:SetScript("OnEvent", nil)
            end
            local ____opt_9 = self.listener
            if ____opt_9 ~= nil then
                ____opt_9:Hide()
            end
            self.listener = nil
            local callbacks = self.readyCallbacks
            self.readyCallbacks = {}
            for ____, callback in ipairs(callbacks) do
                callback(nil)
            end
        end
    )
end
function StoreRegistry.prototype.Load(self)
    local name = self.options.variable
    local saved = _G[name]
    self.saved = saved ~= nil and type(saved) == "table" and saved or ({})
    _G[name] = self.saved
end
function StoreRegistry.prototype.onReady(self, callback)
    if self.IsReady then
        callback(nil)
    else
        local ____self_readyCallbacks_11 = self.readyCallbacks
        ____self_readyCallbacks_11[#____self_readyCallbacks_11 + 1] = callback
    end
end
function StoreRegistry.prototype.Read(self, schema)
    local token = schema.Token
    if token == nil then
        if not self.memory:has(schema) then
            self.memory:set(
                schema,
                copy(
                    nil,
                    __TS__New(schema)
                )
            )
        end
        return self.memory:get(schema)
    end
    if type(token) ~= "string" or __TS__StringTrim(token) == "" then
        error("Store Token must be a nonempty stable string", 0)
    end
    if self.options == nil then
        error("Persistent stores require SavedVariables configuration", 0)
    end
    if self.saved == nil then
        error("SavedVariables are not loaded; use registry.onReady()", 0)
    end
    local owner = self.tokens:get(token)
    if owner ~= nil and owner ~= schema then
        error("Different Store classes cannot share a Token", 0)
    end
    if owner == nil then
        local defaults = copy(
            nil,
            __TS__New(schema)
        )
        local value
        do
            local function ____catch()
                value = defaults
            end
            local ____try = pcall(function()
                value = restore(nil, defaults, self.saved[token])
            end)
            if not ____try then
                ____catch()
            end
        end
        self.saved[token] = value
        self.tokens:set(token, schema)
    end
    return self.saved[token]
end
function StoreRegistry.prototype.get(self, schema)
    return copy(
        nil,
        self:Read(schema)
    )
end
function StoreRegistry.prototype.set(self, schema, update)
    if self.updating:has(schema) then
        error("Reentrant updates of the same Store are not allowed", 0)
    end
    local draft = copy(
        nil,
        self:Read(schema)
    )
    self.updating:add(schema)
    local committed
    do
        local ____try, ____error = pcall(function()
            local next = update(nil, draft)
            if next == nil or type(next) ~= "table" then
                error("Store updater must return settings", 0)
            end
            committed = copy(nil, next)
        end)
        do
            self.updating:delete(schema)
        end
        if not ____try then
            error(____error, 0)
        end
    end
    if schema.Token == nil then
        self.memory:set(schema, committed)
    else
        self.saved[schema.Token] = committed
    end
    local listeners = {__TS__Spread(self.observers:get(schema) or ({}))}
    for ____, observer in ipairs(listeners) do
        do
            local function ____catch()
                print("|cffff5555[wuira] Store observer failed after commit|r")
            end
            local ____try = pcall(function()
                observer(
                    nil,
                    copy(nil, committed)
                )
            end)
            if not ____try then
                ____catch()
            end
        end
    end
end
function StoreRegistry.prototype.subscribe(self, schema, observer)
    self:Read(schema)
    local listeners = self.observers:get(schema)
    if listeners == nil then
        listeners = __TS__New(Set)
        self.observers:set(schema, listeners)
    end
    local function listener(____, value)
        return observer(nil, value)
    end
    listeners:add(listener)
    return function()
        listeners:delete(listener)
    end
end
function StoreRegistry.prototype.Dispose(self)
    local ____opt_12 = self.listener
    if ____opt_12 ~= nil then
        ____opt_12:UnregisterAllEvents()
    end
    local ____opt_14 = self.listener
    if ____opt_14 ~= nil then
        ____opt_14:SetScript("OnEvent", nil)
    end
    local ____opt_16 = self.listener
    if ____opt_16 ~= nil then
        ____opt_16:Hide()
    end
    self.listener = nil
    self.observers:clear()
    self.readyCallbacks = {}
end
__TS__SetDescriptor(
    StoreRegistry.prototype,
    "IsReady",
    {get = function(self)
        return self.options == nil or self.saved ~= nil
    end},
    true
)
return ____exports

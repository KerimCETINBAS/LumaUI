/// <reference path="../platform/forever.d.ts" />
/** Extend with data fields and defaults. A stable static Token opts into persistence. */
export declare abstract class Store {
}
export interface StoreClass<T extends Store> {
    new (): T;
    readonly Token?: string;
}
export type ReadonlyData<T> = T extends object ? {
    readonly [K in keyof T]: ReadonlyData<T[K]>;
} : T;
export interface SavedStoreOptions {
    addon: string;
    variable: string;
}
export declare class StoreRegistry {
    private readonly options?;
    private readonly memory;
    private readonly observers;
    private readonly tokens;
    private readonly updating;
    private saved?;
    private listener?;
    private readyCallbacks;
    constructor(options?: SavedStoreOptions | undefined);
    private Load;
    get IsReady(): boolean;
    onReady(callback: () => void): void;
    private Read;
    /** One-time detached snapshot, with no subscription or mutable access to stored data. */
    get<T extends Store>(schema: StoreClass<T>): ReadonlyData<T>;
    /** Commit only after the updater succeeds; observers receive detached snapshots. */
    set<T extends Store>(schema: StoreClass<T>, update: (settings: T) => T): void;
    /** Observe future commits. Call get() separately for the initial snapshot. */
    subscribe<T extends Store>(schema: StoreClass<T>, observer: (settings: ReadonlyData<T>) => void): () => void;
    Dispose(): void;
}

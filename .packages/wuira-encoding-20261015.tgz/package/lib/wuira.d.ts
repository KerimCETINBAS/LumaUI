import type { Cell } from "./ui/Cell";
import type { Anchor } from "./types/Position";
import type { CommandCallback } from "./platform/SlashCommands";
/** Public entry point for mounting JSX UI trees. */
export declare class wuira {
    private constructor();
    /** Registers a slash command; the returned function removes this registration. */
    static registerCommand(command: string, callback: CommandCallback): () => void;
    static Mount(frame: Cell | void | (() => Cell | void), anchor?: Anchor, parent?: wuiraNativeFrame): wuiraNativeFrame | undefined;
    static Unmount(frame: wuiraNativeFrame): void;
}

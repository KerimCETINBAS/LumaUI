--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__ArrayIncludes(self, searchElement, fromIndex)
    if fromIndex == nil then
        fromIndex = 0
    end
    local len = #self
    local k = fromIndex
    if fromIndex < 0 then
        k = len + fromIndex
    end
    if k < 0 then
        k = 0
    end
    for i = k + 1, len do
        if self[i] == searchElement then
            return true
        end
    end
    return false
end

local function __TS__StringTrim(self)
    local result = string.gsub(self, "^[%s ﻿]*(.-)[%s ﻿]*$", "%1")
    return result
end

local function __TS__NumberIsFinite(value)
    return type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge
end

local function __TS__NumberIsInteger(value)
    return __TS__NumberIsFinite(value) and math.floor(value) == value
end

local function __TS__ArrayIndexOf(self, searchElement, fromIndex)
    if fromIndex == nil then
        fromIndex = 0
    end
    local len = #self
    if len == 0 then
        return -1
    end
    if fromIndex >= len then
        return -1
    end
    if fromIndex < 0 then
        fromIndex = len + fromIndex
        if fromIndex < 0 then
            fromIndex = 0
        end
    end
    for i = fromIndex + 1, len do
        if self[i] == searchElement then
            return i - 1
        end
    end
    return -1
end
-- End of Lua Library inline imports
local ____exports = {}
function ____exports.createSecureButton(self, parent, props)
    local name
    if props.binding ~= nil then
        local id = type(_G.__wuiraButtonSequence) == "number" and _G.__wuiraButtonSequence or 0
        repeat
            do
                id = id + 1
                name = "WuiraSecureButton" .. tostring(id)
            end
        until not (_G[name] ~= nil)
        _G.__wuiraButtonSequence = id
    end
    return CreateFrame("Button", name, parent, "SecureActionButtonTemplate")
end
local buttons = {
    "LeftButton",
    "RightButton",
    "MiddleButton",
    "Button4",
    "Button5"
}
--- Validate the whole tree before allocating any protected widgets.
function ____exports.validateSecureButton(self, props)
    if props.clickThrough ~= nil and props.clickThrough ~= false then
        error("SecureButton cannot be click-through")
    end
    if not __TS__ArrayIncludes(buttons, props.button or "LeftButton") then
        error("SecureButton: unsupported mouse button")
    end
    if props.binding ~= nil and (issecretvalue(props.binding) or type(props.binding) ~= "string" or #__TS__StringTrim(props.binding) == 0) then
        error("SecureButton: binding must be a non-empty key string")
    end
    local function reference(____, value)
        if issecretvalue(value) then
            error("SecureButton: action attributes cannot be secret")
        end
        if type(value) == "number" and __TS__NumberIsInteger(value) and value > 0 then
            return
        end
        if type(value) == "string" and #__TS__StringTrim(value) > 0 then
            return
        end
        error("SecureButton: action reference must be a positive integer or non-empty string")
    end
    local action = props.action
    if action == nil then
        return
    end
    if issecretvalue(action) or type(action) ~= "table" then
        error("SecureButton: invalid action")
    end
    repeat
        local ____switch15 = action.type
        local ____cond15 = ____switch15 == "spell"
        if ____cond15 then
            reference(nil, action.spell)
            break
        end
        ____cond15 = ____cond15 or ____switch15 == "item"
        if ____cond15 then
            reference(nil, action.item)
            break
        end
        ____cond15 = ____cond15 or ____switch15 == "macro"
        if ____cond15 then
            reference(nil, action.macro)
            break
        end
        ____cond15 = ____cond15 or ____switch15 == "action"
        if ____cond15 then
            if issecretvalue(action.slot) or not __TS__NumberIsInteger(action.slot) or action.slot <= 0 then
                error("SecureButton: slot must be a positive integer")
            end
            break
        end
        ____cond15 = ____cond15 or ____switch15 == "target"
        if ____cond15 then
            if action.unit == nil then
                error("SecureButton: target action requires a unit")
            end
            break
        end
        do
            error("SecureButton: unsupported action type")
        end
    until true
    if action.unit ~= nil and action.unit ~= nil then
        if issecretvalue(action.unit) or type(action.unit) ~= "string" or #__TS__StringTrim(action.unit) == 0 then
            error("SecureButton: unit must be a static unit token")
        end
    end
end
function ____exports.configureSecureButton(self, frame, props)
    local button = props.button or "LeftButton"
    local suffix = tostring(__TS__ArrayIndexOf(buttons, button) + 1)
    frame:RegisterForClicks(button .. "Up")
    frame:SetAttribute("useOnKeyDown", false)
    frame:SetID(0)
    local action = props.action
    if action ~= nil then
        if action.type == "spell" then
            frame:SetAttribute("spell" .. suffix, action.spell)
        elseif action.type == "item" then
            frame:SetAttribute(
                "item" .. suffix,
                type(action.item) == "number" and "item:" .. tostring(action.item) or action.item
            )
        elseif action.type == "macro" then
            frame:SetAttribute("macro" .. suffix, action.macro)
        elseif action.type == "action" then
            frame:SetAttribute("action" .. suffix, action.slot)
        end
        if action.unit ~= nil then
            frame:SetAttribute("unit" .. suffix, action.unit)
        end
        frame:SetAttribute("type" .. suffix, action.type)
    end
    if props.binding ~= nil then
        SetOverrideBindingClick(
            frame,
            false,
            props.binding,
            frame:GetName(),
            button
        )
    end
    return function()
        if props.binding ~= nil then
            ClearOverrideBindings(frame)
        end
        frame:SetAttribute("type" .. suffix, nil)
        frame:EnableMouse(false)
    end
end
return ____exports

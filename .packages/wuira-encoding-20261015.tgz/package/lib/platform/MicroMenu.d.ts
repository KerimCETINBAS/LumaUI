import type { Color } from "../types/Color";
export interface MicroMenuSkinOptions {
    background?: Color;
    border?: Color;
    buttonBackground?: Color;
    icon?: Color;
    accent?: Color;
    disabledIcon?: Color;
    padding?: number;
    panel?: boolean;
}
/** Style Forever's existing micro buttons without replacing their scripts or layout.
 * Disposing stops maintenance; reload restores the native textures.
 */
export declare function skinMicroMenu(options?: MicroMenuSkinOptions): () => void;

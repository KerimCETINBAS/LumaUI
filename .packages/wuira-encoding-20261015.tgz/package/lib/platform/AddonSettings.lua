--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end
-- End of Lua Library inline imports
local ____exports = {}
local ____wuira = require("wuira")
local wuira = ____wuira.wuira
--- Registers a JSX settings view in the client's native addon settings list.
____exports.AddonSettings = __TS__Class()
local AddonSettings = ____exports.AddonSettings
AddonSettings.name = "AddonSettings"
function AddonSettings.prototype.____constructor(self, name, view)
    if (Settings and Settings.RegisterCanvasLayoutCategory) == nil then
        error("AddonSettings: native settings API is unavailable")
    end
    self.Frame = CreateFrame("Frame", nil, UIParent)
    self.Frame:Hide()
    wuira:Mount(view, nil, self.Frame)
    self.category = Settings.RegisterCanvasLayoutCategory(self.Frame, name)
    Settings.RegisterAddOnCategory(self.category)
end
function AddonSettings.prototype.Open(self)
    Settings.OpenToCategory(self.category:GetID())
end
function AddonSettings.prototype.Close(self)
    local ____opt_2 = _G.SettingsPanel
    if ____opt_2 ~= nil then
        ____opt_2:Hide()
    end
end
return ____exports

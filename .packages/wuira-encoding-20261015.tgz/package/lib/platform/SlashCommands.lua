--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__StringCharAt(self, pos)
    if pos ~= pos then
        pos = 0
    end
    if pos < 0 then
        return ""
    end
    return string.sub(self, pos + 1, pos + 1)
end

local function __TS__StringStartsWith(self, searchString, position)
    if position == nil or position < 0 then
        position = 0
    end
    return string.sub(self, position + 1, #searchString + position) == searchString
end

local function __TS__ObjectEntries(obj)
    local result = {}
    local len = 0
    for key in pairs(obj) do
        len = len + 1
        result[len] = {key, obj[key]}
    end
    return result
end

local __TS__Unpack = table.unpack or unpack

local function __TS__StringIncludes(self, searchString, position)
    if not position then
        position = 1
    else
        position = position + 1
    end
    local index = string.find(self, searchString, position, true)
    return index ~= nil
end

local function __TS__New(target, ...)
    local instance = setmetatable({}, target.prototype)
    instance:____constructor(...)
    return instance
end

local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end

local function __TS__ClassExtends(target, base)
    target.____super = base
    local staticMetatable = setmetatable({__index = base}, base)
    setmetatable(target, staticMetatable)
    local baseMetatable = getmetatable(base)
    if baseMetatable then
        if type(baseMetatable.__index) == "function" then
            staticMetatable.__index = baseMetatable.__index
        end
        if type(baseMetatable.__newindex) == "function" then
            staticMetatable.__newindex = baseMetatable.__newindex
        end
    end
    setmetatable(target.prototype, base.prototype)
    if type(base.prototype.__index) == "function" then
        target.prototype.__index = base.prototype.__index
    end
    if type(base.prototype.__newindex) == "function" then
        target.prototype.__newindex = base.prototype.__newindex
    end
    if type(base.prototype.__tostring) == "function" then
        target.prototype.__tostring = base.prototype.__tostring
    end
end

local Error, RangeError, ReferenceError, SyntaxError, TypeError, URIError
do
    local function getErrorStack(self, constructor)
        if debug == nil then
            return nil
        end
        local level = 1
        while true do
            local info = debug.getinfo(level, "f")
            level = level + 1
            if not info then
                level = 1
                break
            elseif info.func == constructor then
                break
            end
        end
        if __TS__StringIncludes(_VERSION, "Lua 5.0") then
            return debug.traceback(("[Level " .. tostring(level)) .. "]")
        elseif _VERSION == "Lua 5.1" then
            return string.sub(
                debug.traceback("", level),
                2
            )
        else
            return debug.traceback(nil, level)
        end
    end
    local function wrapErrorToString(self, getDescription)
        return function(self)
            local description = getDescription(self)
            local caller = debug.getinfo(3, "f")
            local isClassicLua = __TS__StringIncludes(_VERSION, "Lua 5.0")
            if isClassicLua or caller and caller.func ~= error then
                return description
            else
                return (description .. "\n") .. tostring(self.stack)
            end
        end
    end
    local function initErrorClass(self, Type, name)
        Type.name = name
        return setmetatable(
            Type,
            {__call = function(____, _self, message) return __TS__New(Type, message) end}
        )
    end
    local ____initErrorClass_1 = initErrorClass
    local ____class_0 = __TS__Class()
    ____class_0.name = ""
    function ____class_0.prototype.____constructor(self, message)
        if message == nil then
            message = ""
        end
        self.message = message
        self.name = "Error"
        self.stack = getErrorStack(nil, __TS__New)
        local metatable = getmetatable(self)
        if metatable and not metatable.__errorToStringPatched then
            metatable.__errorToStringPatched = true
            metatable.__tostring = wrapErrorToString(nil, metatable.__tostring)
        end
    end
    function ____class_0.prototype.__tostring(self)
        return self.message ~= "" and (self.name .. ": ") .. self.message or self.name
    end
    Error = ____initErrorClass_1(nil, ____class_0, "Error")
    local function createErrorClass(self, name)
        local ____initErrorClass_3 = initErrorClass
        local ____class_2 = __TS__Class()
        ____class_2.name = ____class_2.name
        __TS__ClassExtends(____class_2, Error)
        function ____class_2.prototype.____constructor(self, ...)
            ____class_2.____super.prototype.____constructor(self, ...)
            self.name = name
        end
        return ____initErrorClass_3(nil, ____class_2, name)
    end
    RangeError = createErrorClass(nil, "RangeError")
    ReferenceError = createErrorClass(nil, "ReferenceError")
    SyntaxError = createErrorClass(nil, "SyntaxError")
    TypeError = createErrorClass(nil, "TypeError")
    URIError = createErrorClass(nil, "URIError")
end

local function __TS__ObjectGetOwnPropertyDescriptors(object)
    local metatable = getmetatable(object)
    if not metatable then
        return {}
    end
    return rawget(metatable, "_descriptors") or ({})
end

local function __TS__Delete(target, key)
    local descriptors = __TS__ObjectGetOwnPropertyDescriptors(target)
    local descriptor = descriptors[key]
    if descriptor then
        if not descriptor.configurable then
            error(
                __TS__New(
                    TypeError,
                    ((("Cannot delete property " .. tostring(key)) .. " of ") .. tostring(target)) .. "."
                ),
                0
            )
        end
        descriptors[key] = nil
        return true
    end
    target[key] = nil
    return true
end
-- End of Lua Library inline imports
local ____exports = {}
--- Whitespace separates arguments; quotes preserve spaces and empty values.
local function parseArguments(self, message)
    local args = {}
    local value = ""
    local quote
    local started = false
    do
        local index = 0
        while index < #message do
            local character = __TS__StringCharAt(message, index)
            if quote ~= nil then
                local next = __TS__StringCharAt(message, index + 1)
                if character == "\\" and (next == quote or next == "\\") then
                    value = value .. next
                    index = index + 1
                elseif character == quote then
                    quote = nil
                else
                    value = value .. character
                end
            elseif character == "\"" or character == "'" then
                quote = character
                started = true
            elseif string.match(character, "%s") ~= nil then
                if started then
                    args[#args + 1] = value
                end
                value = ""
                started = false
            else
                value = value .. character
                started = true
            end
            index = index + 1
        end
    end
    if quote ~= nil then
        error("wuira.registerCommand: unterminated quoted argument")
    end
    if started then
        args[#args + 1] = value
    end
    return args
end
--- Native slash registration, with an idempotent cleanup and no shared module state.
function ____exports.registerCommand(self, command, callback)
    if issecretvalue(command) or type(command) ~= "string" or string.match(command, "^/%a[%w_-]*$") == nil then
        error("wuira.registerCommand: use a slash followed by a command name, without arguments")
    end
    if type(callback) ~= "function" then
        error("wuira.registerCommand: callback must be a function")
    end
    local normalized = string.lower(command)
    local lookup = string.upper(normalized)
    local hash = _G.hash_SlashCmdList
    local chatTypes = _G.hash_ChatTypeInfoList
    if IsSecureCmd and IsSecureCmd(lookup) or (hash and hash[lookup]) ~= nil or (chatTypes and chatTypes[lookup]) ~= nil then
        error("wuira.registerCommand: command already registered: " .. normalized)
    end
    for ____, ____value in ipairs(__TS__ObjectEntries(_G)) do
        local key = ____value[1]
        local value = ____value[2]
        if __TS__StringStartsWith(key, "SLASH_") and not issecretvalue(value) and type(value) == "string" and string.upper(value) == lookup then
            error("wuira.registerCommand: command already registered: " .. normalized)
        end
    end
    local sequence = type(_G.__wuiraCommandSequence) == "number" and _G.__wuiraCommandSequence or 0
    local id
    repeat
        do
            sequence = sequence + 1
            id = "WUIRA_COMMAND_" .. tostring(sequence)
        end
    until not (SlashCmdList[id] ~= nil or _G[("SLASH_" .. id) .. "1"] ~= nil)
    _G.__wuiraCommandSequence = sequence
    local globalKey = ("SLASH_" .. id) .. "1"
    local current = callback
    local function handler(message)
        if current ~= nil then
            current(__TS__Unpack(parseArguments(nil, message)))
        end
    end
    _G[globalKey] = normalized
    SlashCmdList[id] = handler
    local disposed = false
    return function()
        if disposed then
            return
        end
        disposed = true
        current = nil
        local currentHash = _G.hash_SlashCmdList
        local currentChatTypes = _G.hash_ChatTypeInfoList
        local ownsEntry = SlashCmdList[id] == handler
        if ownsEntry then
            __TS__Delete(SlashCmdList, id)
            if _G[globalKey] == normalized then
                __TS__Delete(_G, globalKey)
            end
            local meta = getmetatable(SlashCmdList)
            if type(meta) == "table" and meta ~= nil then
                local proxy = meta.__index
                if type(proxy) == "table" and proxy ~= nil and proxy[id] == handler then
                    __TS__Delete(proxy, id)
                end
            end
            if (currentChatTypes and currentChatTypes[lookup]) == id then
                __TS__Delete(currentChatTypes, lookup)
            end
        end
        if (currentHash and currentHash[lookup]) == handler then
            __TS__Delete(currentHash, lookup)
        end
    end
end
return ____exports

--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end

local function __TS__ClassExtends(target, base)
    target.____super = base
    local staticMetatable = setmetatable({__index = base}, base)
    setmetatable(target, staticMetatable)
    local baseMetatable = getmetatable(base)
    if baseMetatable then
        if type(baseMetatable.__index) == "function" then
            staticMetatable.__index = baseMetatable.__index
        end
        if type(baseMetatable.__newindex) == "function" then
            staticMetatable.__newindex = baseMetatable.__newindex
        end
    end
    setmetatable(target.prototype, base.prototype)
    if type(base.prototype.__index) == "function" then
        target.prototype.__index = base.prototype.__index
    end
    if type(base.prototype.__newindex) == "function" then
        target.prototype.__newindex = base.prototype.__newindex
    end
    if type(base.prototype.__tostring) == "function" then
        target.prototype.__tostring = base.prototype.__tostring
    end
end

local function __TS__NumberIsFinite(value)
    return type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge
end

local function __TS__NumberIsInteger(value)
    return __TS__NumberIsFinite(value) and math.floor(value) == value
end

local __TS__Symbol, Symbol
do
    local symbolMetatable = {__tostring = function(self)
        return ("Symbol(" .. (self.description or "")) .. ")"
    end}
    function __TS__Symbol(description)
        return setmetatable({description = description}, symbolMetatable)
    end
    Symbol = {
        asyncDispose = __TS__Symbol("Symbol.asyncDispose"),
        dispose = __TS__Symbol("Symbol.dispose"),
        iterator = __TS__Symbol("Symbol.iterator"),
        hasInstance = __TS__Symbol("Symbol.hasInstance"),
        species = __TS__Symbol("Symbol.species"),
        toStringTag = __TS__Symbol("Symbol.toStringTag")
    }
end

local __TS__Iterator
do
    local function iteratorGeneratorStep(self)
        local co = self.____coroutine
        local status, value = coroutine.resume(co)
        if not status then
            error(value, 0)
        end
        if coroutine.status(co) == "dead" then
            return
        end
        return true, value
    end
    local function iteratorIteratorStep(self)
        local result = self:next()
        if result.done then
            return
        end
        return true, result.value
    end
    local function iteratorStringStep(self, index)
        index = index + 1
        if index > #self then
            return
        end
        return index, string.sub(self, index, index)
    end
    function __TS__Iterator(iterable)
        if type(iterable) == "string" then
            return iteratorStringStep, iterable, 0
        elseif iterable.____coroutine ~= nil then
            return iteratorGeneratorStep, iterable
        elseif iterable[Symbol.iterator] then
            local iterator = iterable[Symbol.iterator](iterable)
            return iteratorIteratorStep, iterator
        else
            return ipairs(iterable)
        end
    end
end

local Map
do
    Map = __TS__Class()
    Map.name = "Map"
    function Map.prototype.____constructor(self, entries)
        self[Symbol.toStringTag] = "Map"
        self.items = {}
        self.size = 0
        self.nextKey = {}
        self.previousKey = {}
        if entries == nil then
            return
        end
        local iterable = entries
        if iterable[Symbol.iterator] then
            local iterator = iterable[Symbol.iterator](iterable)
            while true do
                local result = iterator:next()
                if result.done then
                    break
                end
                local value = result.value
                self:set(value[1], value[2])
            end
        else
            local array = entries
            for ____, kvp in ipairs(array) do
                self:set(kvp[1], kvp[2])
            end
        end
    end
    function Map.prototype.clear(self)
        self.items = {}
        self.nextKey = {}
        self.previousKey = {}
        self.firstKey = nil
        self.lastKey = nil
        self.size = 0
    end
    function Map.prototype.delete(self, key)
        local contains = self:has(key)
        if contains then
            self.size = self.size - 1
            local next = self.nextKey[key]
            local previous = self.previousKey[key]
            if next ~= nil and previous ~= nil then
                self.nextKey[previous] = next
                self.previousKey[next] = previous
            elseif next ~= nil then
                self.firstKey = next
                self.previousKey[next] = nil
            elseif previous ~= nil then
                self.lastKey = previous
                self.nextKey[previous] = nil
            else
                self.firstKey = nil
                self.lastKey = nil
            end
            self.nextKey[key] = nil
            self.previousKey[key] = nil
        end
        self.items[key] = nil
        return contains
    end
    function Map.prototype.forEach(self, callback)
        for ____, key in __TS__Iterator(self:keys()) do
            callback(nil, self.items[key], key, self)
        end
    end
    function Map.prototype.get(self, key)
        return self.items[key]
    end
    function Map.prototype.has(self, key)
        return self.nextKey[key] ~= nil or self.lastKey == key
    end
    function Map.prototype.set(self, key, value)
        local isNewValue = not self:has(key)
        if isNewValue then
            self.size = self.size + 1
        end
        self.items[key] = value
        if self.firstKey == nil then
            self.firstKey = key
            self.lastKey = key
        elseif isNewValue then
            self.nextKey[self.lastKey] = key
            self.previousKey[key] = self.lastKey
            self.lastKey = key
        end
        return self
    end
    Map.prototype[Symbol.iterator] = function(self)
        return self:entries()
    end
    function Map.prototype.entries(self)
        local function getFirstKey()
            return self.firstKey
        end
        local items = self.items
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = {key, items[key]}}
            end
        }
    end
    function Map.prototype.keys(self)
        local function getFirstKey()
            return self.firstKey
        end
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = key}
            end
        }
    end
    function Map.prototype.values(self)
        local function getFirstKey()
            return self.firstKey
        end
        local items = self.items
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = items[key]}
            end
        }
    end
    Map[Symbol.species] = Map
end

local function __TS__New(target, ...)
    local instance = setmetatable({}, target.prototype)
    instance:____constructor(...)
    return instance
end

local function __TS__StringIncludes(self, searchString, position)
    if not position then
        position = 1
    else
        position = position + 1
    end
    local index = string.find(self, searchString, position, true)
    return index ~= nil
end

local Error, RangeError, ReferenceError, SyntaxError, TypeError, URIError
do
    local function getErrorStack(self, constructor)
        if debug == nil then
            return nil
        end
        local level = 1
        while true do
            local info = debug.getinfo(level, "f")
            level = level + 1
            if not info then
                level = 1
                break
            elseif info.func == constructor then
                break
            end
        end
        if __TS__StringIncludes(_VERSION, "Lua 5.0") then
            return debug.traceback(("[Level " .. tostring(level)) .. "]")
        elseif _VERSION == "Lua 5.1" then
            return string.sub(
                debug.traceback("", level),
                2
            )
        else
            return debug.traceback(nil, level)
        end
    end
    local function wrapErrorToString(self, getDescription)
        return function(self)
            local description = getDescription(self)
            local caller = debug.getinfo(3, "f")
            local isClassicLua = __TS__StringIncludes(_VERSION, "Lua 5.0")
            if isClassicLua or caller and caller.func ~= error then
                return description
            else
                return (description .. "\n") .. tostring(self.stack)
            end
        end
    end
    local function initErrorClass(self, Type, name)
        Type.name = name
        return setmetatable(
            Type,
            {__call = function(____, _self, message) return __TS__New(Type, message) end}
        )
    end
    local ____initErrorClass_1 = initErrorClass
    local ____class_0 = __TS__Class()
    ____class_0.name = ""
    function ____class_0.prototype.____constructor(self, message)
        if message == nil then
            message = ""
        end
        self.message = message
        self.name = "Error"
        self.stack = getErrorStack(nil, __TS__New)
        local metatable = getmetatable(self)
        if metatable and not metatable.__errorToStringPatched then
            metatable.__errorToStringPatched = true
            metatable.__tostring = wrapErrorToString(nil, metatable.__tostring)
        end
    end
    function ____class_0.prototype.__tostring(self)
        return self.message ~= "" and (self.name .. ": ") .. self.message or self.name
    end
    Error = ____initErrorClass_1(nil, ____class_0, "Error")
    local function createErrorClass(self, name)
        local ____initErrorClass_3 = initErrorClass
        local ____class_2 = __TS__Class()
        ____class_2.name = ____class_2.name
        __TS__ClassExtends(____class_2, Error)
        function ____class_2.prototype.____constructor(self, ...)
            ____class_2.____super.prototype.____constructor(self, ...)
            self.name = name
        end
        return ____initErrorClass_3(nil, ____class_2, name)
    end
    RangeError = createErrorClass(nil, "RangeError")
    ReferenceError = createErrorClass(nil, "ReferenceError")
    SyntaxError = createErrorClass(nil, "SyntaxError")
    TypeError = createErrorClass(nil, "TypeError")
    URIError = createErrorClass(nil, "URIError")
end

local function __TS__ObjectGetOwnPropertyDescriptors(object)
    local metatable = getmetatable(object)
    if not metatable then
        return {}
    end
    return rawget(metatable, "_descriptors") or ({})
end

local function __TS__Delete(target, key)
    local descriptors = __TS__ObjectGetOwnPropertyDescriptors(target)
    local descriptor = descriptors[key]
    if descriptor then
        if not descriptor.configurable then
            error(
                __TS__New(
                    TypeError,
                    ((("Cannot delete property " .. tostring(key)) .. " of ") .. tostring(target)) .. "."
                ),
                0
            )
        end
        descriptors[key] = nil
        return true
    end
    target[key] = nil
    return true
end
-- End of Lua Library inline imports
local ____exports = {}
local ____store = require("store.index")
local Store = ____store.Store
local StoreRegistry = ____store.StoreRegistry
local ____BlizzardUI = require("platform.BlizzardUI")
local BlizzardUI = ____BlizzardUI.BlizzardUI
local ActionBarBackup = __TS__Class()
ActionBarBackup.name = "ActionBarBackup"
__TS__ClassExtends(ActionBarBackup, Store)
function ActionBarBackup.prototype.____constructor(self, ...)
    Store.prototype.____constructor(self, ...)
    self.phase = "capture"
    self.slots = {}
end
ActionBarBackup.Token = "wuira.native-action-bars"
--- Explicit destructive action-slot operations. Persist Capture() before Clear().
____exports.ActionBars = __TS__Class()
local ActionBars = ____exports.ActionBars
ActionBars.name = "ActionBars"
function ActionBars.prototype.____constructor(self)
end
function ActionBars.AssertReady(self)
    if InCombatLockdown() then
        error("ActionBars: changes must wait until combat ends")
    end
    local cursor = GetCursorInfo()
    if issecretvalue(cursor) or cursor ~= nil then
        error("ActionBars: clear the cursor before changing action slots")
    end
end
function ActionBars.Pickup(self, entry)
    local spell = C_Spell and C_Spell.PickupSpell or PickupSpell
    local item = C_Item and C_Item.PickupItem or PickupItem
    if entry.type == "spell" and spell ~= nil then
        spell(entry.id)
    elseif entry.type == "item" and item ~= nil then
        item(entry.id)
    elseif entry.type == "macro" and PickupMacro ~= nil then
        PickupMacro(entry.id)
    else
        error("ActionBars: unsupported restore API for " .. entry.type)
    end
end
function ActionBars.Validate(self, entry)
    if not __TS__NumberIsInteger(entry.slot) or entry.slot < 1 or entry.slot > self.SlotCount or not __TS__NumberIsInteger(entry.id) or entry.id <= 0 then
        error("ActionBars: invalid backup entry")
    end
    if entry.type == "spell" and (C_Spell and C_Spell.PickupSpell or PickupSpell) ~= nil or entry.type == "item" and (C_Item and C_Item.PickupItem or PickupItem) ~= nil or entry.type == "macro" and PickupMacro ~= nil then
        return
    end
    error("ActionBars: cannot safely restore action type " .. entry.type)
end
function ActionBars.Capture(self)
    self:AssertReady()
    local entries = {}
    do
        local slot = 1
        while slot <= self.SlotCount do
            do
                local __continue16
                repeat
                    local ____type, id, subtype = GetActionInfo(slot)
                    if issecretvalue(____type) or issecretvalue(id) or issecretvalue(subtype) then
                        error("ActionBars: secret slot data cannot be backed up")
                    end
                    if ____type == nil then
                        __continue16 = true
                        break
                    end
                    if ____type ~= "spell" and ____type ~= "item" and ____type ~= "macro" then
                        error(("ActionBars: unsupported action type " .. ____type) .. "; no slots were cleared")
                    end
                    local entry = {slot = slot, type = ____type, id = id, subtype = subtype}
                    self:Validate(entry)
                    entries[#entries + 1] = entry
                    __continue16 = true
                until true
                if not __continue16 then
                    break
                end
            end
            slot = slot + 1
        end
    end
    return entries
end
function ActionBars.Clear(self, backup)
    self:AssertReady()
    local current = self:Capture()
    local covered = __TS__New(Map)
    for ____, entry in ipairs(backup) do
        self:Validate(entry)
        covered:set(entry.slot, entry)
    end
    for ____, entry in ipairs(current) do
        local saved = covered:get(entry.slot)
        if saved == nil or saved.type ~= entry.type or saved.id ~= entry.id then
            error("ActionBars: backup does not cover the current slot contents")
        end
    end
    for ____, entry in ipairs(current) do
        PickupAction(entry.slot)
        local remaining = GetActionInfo(entry.slot)
        if issecretvalue(remaining) or remaining ~= nil then
            error("ActionBars: client refused to clear slot " .. tostring(entry.slot))
        end
        ClearCursor()
    end
end
function ActionBars.Restore(self, backup)
    self:AssertReady()
    for ____, entry in ipairs(backup) do
        self:Validate(entry)
        local ____type, id = GetActionInfo(entry.slot)
        if issecretvalue(____type) or issecretvalue(id) then
            error("ActionBars: restricted slot cannot be restored")
        end
        if ____type ~= nil and (____type ~= entry.type or id ~= entry.id) then
            error("ActionBars: restore would overwrite slot " .. tostring(entry.slot))
        end
    end
    for ____, entry in ipairs(backup) do
        do
            local __continue34
            repeat
                local ____type = GetActionInfo(entry.slot)
                if ____type ~= nil then
                    __continue34 = true
                    break
                end
                self:Pickup(entry)
                local cursor = GetCursorInfo()
                if issecretvalue(cursor) or cursor == nil then
                    error("ActionBars: client refused to pick up action " .. tostring(entry.id))
                end
                PlaceAction(entry.slot)
                local placedType, placedId = GetActionInfo(entry.slot)
                if issecretvalue(placedType) or issecretvalue(placedId) or placedType ~= entry.type or placedId ~= entry.id then
                    error("ActionBars: client refused to restore slot " .. tostring(entry.slot))
                end
                ClearCursor()
                __continue34 = true
            until true
            if not __continue34 then
                break
            end
        end
    end
end
function ActionBars.InstallEmptyMode(self, options)
    local store = __TS__New(StoreRegistry, options)
    local listener = CreateFrame("Frame", nil, UIParent)
    local worldReady = false
    local busy = false
    local initialized = false
    local backupPersisted = false
    local disposed = false
    local stopSuppressing
    local stage = "initialization"
    local diagnostics = CreateFrame("Frame", nil, UIParent)
    diagnostics:RegisterEvent("ADDON_ACTION_BLOCKED")
    diagnostics:RegisterEvent("ADDON_ACTION_FORBIDDEN")
    diagnostics:SetScript(
        "OnEvent",
        function(_frame, event, addon, api)
            if busy or addon == options.addon then
                console.error(
                    "Action bars:",
                    stage,
                    event,
                    addon,
                    api
                )
            end
        end
    )
    local function attempt()
        if disposed or initialized or busy or not worldReady or not store.IsReady or InCombatLockdown() then
            return
        end
        busy = true
        do
            local function ____catch(failure)
                console.error("Action bars:", stage, failure)
            end
            local ____try, ____hasReturned = pcall(function()
                local settings = store:get(ActionBarBackup)
                backupPersisted = settings.phase ~= "capture"
                if settings.phase ~= "restored" and settings.phase ~= "restore" then
                    stage = "disable native bars"
                    do
                        local function ____catch(failure)
                            console.error("Native action bar suppression stopped:", failure)
                        end
                        local ____try, ____hasReturned = pcall(function()
                            stopSuppressing = BlizzardUI:DisableActionBars()
                        end)
                        if not ____try then
                            ____catch(____hasReturned)
                        end
                    end
                end
                stage = "capture backup"
                if settings.phase == "capture" then
                    local slots = self:Capture()
                    store:set(
                        ActionBarBackup,
                        function(____, draft)
                            draft.slots = slots
                            draft.phase = "ready"
                            return draft
                        end
                    )
                    console.log(("Action bars backed up. Use /reload to save the backup, then " .. options.clearCommand) .. " outside combat to clear slots.")
                elseif settings.phase == "restore" then
                    console.log(("Use " .. options.restoreCommand) .. " outside combat to restore action slots.")
                elseif settings.phase ~= "restored" then
                    console.log(("Native action bars disabled. Use " .. options.clearCommand) .. " outside combat to clear their slots.")
                end
            end)
            local ____rethrow
            if not ____try then
                ____try, ____rethrow = pcall(function()
                    ____catch(____hasReturned)
                end)
            end
            do
                initialized = true
                listener:UnregisterAllEvents()
                busy = false
            end
            if not ____try then
                error(____rethrow, 0)
            end
        end
    end
    listener:RegisterEvent("PLAYER_ENTERING_WORLD")
    listener:RegisterEvent("PLAYER_REGEN_ENABLED")
    listener:SetScript(
        "OnEvent",
        function(_frame, event)
            if event == "PLAYER_ENTERING_WORLD" then
                worldReady = true
            end
            attempt(nil)
        end
    )
    store:onReady(attempt)
    local clearCommand = "WUIRA_CLEAR_" .. string.upper(options.addon)
    local restoreCommand = "WUIRA_RESTORE_" .. string.upper(options.addon)
    if SlashCmdList[clearCommand] ~= nil or SlashCmdList[restoreCommand] ~= nil then
        error("ActionBars: command already registered")
    end
    local function run(____, restore)
        if disposed or busy then
            return
        end
        if InCombatLockdown() then
            console.warn("Change action bars after combat ends.")
            return
        end
        if not initialized or not store.IsReady or not backupPersisted then
            console.warn("Use /reload to persist the action bar backup first.")
            return
        end
        busy = true
        stage = restore and "restore slots" or "clear slots"
        do
            local function ____catch(failure)
                console.error("Action bars:", stage, failure)
            end
            local ____try, ____hasReturned = pcall(function()
                local settings = store:get(ActionBarBackup)
                if restore then
                    self:Restore(settings.slots)
                    store:set(
                        ActionBarBackup,
                        function(____, draft)
                            draft.phase = "restored"
                            return draft
                        end
                    )
                    console.log("Action slots restored. Use /reload to restore native bar handlers and visibility.")
                else
                    self:Clear(settings.slots)
                    store:set(
                        ActionBarBackup,
                        function(____, draft)
                            draft.phase = "disabled"
                            return draft
                        end
                    )
                    console.log("Native action slots cleared.")
                end
            end)
            local ____rethrow
            if not ____try then
                ____try, ____rethrow = pcall(function()
                    ____catch(____hasReturned)
                end)
            end
            do
                busy = false
            end
            if not ____try then
                error(____rethrow, 0)
            end
        end
    end
    _G[("SLASH_" .. clearCommand) .. "1"] = options.clearCommand
    _G[("SLASH_" .. restoreCommand) .. "1"] = options.restoreCommand
    SlashCmdList[clearCommand] = function() return run(nil, false) end
    SlashCmdList[restoreCommand] = function() return run(nil, true) end
    return function()
        disposed = true
        if stopSuppressing ~= nil then
            stopSuppressing(nil)
        end
        store:Dispose()
        listener:UnregisterAllEvents()
        listener:SetScript("OnEvent", nil)
        diagnostics:UnregisterAllEvents()
        diagnostics:SetScript("OnEvent", nil)
        _G[("SLASH_" .. clearCommand) .. "1"] = nil
        _G[("SLASH_" .. restoreCommand) .. "1"] = nil
        __TS__Delete(SlashCmdList, clearCommand)
        __TS__Delete(SlashCmdList, restoreCommand)
    end
end
ActionBars.SlotCount = 180
return ____exports

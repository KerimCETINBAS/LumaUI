import type { SecureButtonProps } from "../ui/SecureButton";
export declare function createSecureButton(parent: wuiraNativeFrame, props: SecureButtonProps): wuiraNativeSecureButton;
/** Validate the whole tree before allocating any protected widgets. */
export declare function validateSecureButton(props: SecureButtonProps): void;
export declare function configureSecureButton(frame: wuiraNativeSecureButton, props: SecureButtonProps): () => void;

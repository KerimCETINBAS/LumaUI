import type { SavedStoreOptions } from "../store";
export interface ActionSlot {
    slot: number;
    type: "spell" | "item" | "macro";
    id: number;
    subtype?: string;
}
export interface EmptyActionBarsOptions extends SavedStoreOptions {
    clearCommand: string;
    restoreCommand: string;
}
/** Explicit destructive action-slot operations. Persist Capture() before Clear(). */
export declare class ActionBars {
    private constructor();
    static readonly SlotCount = 180;
    private static AssertReady;
    private static Pickup;
    private static Validate;
    static Capture(): ActionSlot[];
    static Clear(backup: readonly Readonly<ActionSlot>[]): void;
    /** Restore only into empty or identical slots; never replace newly assigned actions. */
    static Restore(backup: readonly Readonly<ActionSlot>[]): void;
    /** Hide stock bars independently of slot changes. Clear/restore run only from slash commands.
     * Declare options.variable in SavedVariablesPerCharacter in the addon's TOC.
     */
    static InstallEmptyMode(options: EmptyActionBarsOptions): () => void;
}

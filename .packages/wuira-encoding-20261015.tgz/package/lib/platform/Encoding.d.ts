/** Native CBOR, compression and Base64 transport for serializable data. */
export declare class Encoding {
    static Encode(value: unknown): string;
    /** Returns unvalidated data; the size bound is also checked after decompression. */
    static Decode(value: string, maxBytes?: number): unknown;
}

--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end

local function __TS__NumberIsFinite(value)
    return type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge
end
-- End of Lua Library inline imports
local ____exports = {}
--- Native CBOR, compression and Base64 transport for serializable data.
____exports.Encoding = __TS__Class()
local Encoding = ____exports.Encoding
Encoding.name = "Encoding"
function Encoding.prototype.____constructor(self)
end
function Encoding.Encode(self, value)
    if C_EncodingUtil == nil then
        error("Encoding: native codec is unavailable")
    end
    local compressed = C_EncodingUtil.CompressString(C_EncodingUtil.SerializeCBOR(value))
    if compressed == nil then
        error("Encoding: compression failed")
    end
    local encoded = C_EncodingUtil.EncodeBase64(compressed)
    if encoded == nil then
        error("Encoding: encoding failed")
    end
    return encoded
end
function Encoding.Decode(self, value, maxBytes)
    if maxBytes == nil then
        maxBytes = 262144
    end
    if not __TS__NumberIsFinite(maxBytes) or maxBytes < 1 then
        error("Encoding: invalid size limit")
    end
    if type(value) ~= "string" or issecretvalue(value) or #value > maxBytes then
        error("Encoding: invalid encoded data")
    end
    if C_EncodingUtil == nil then
        error("Encoding: native codec is unavailable")
    end
    local decoded = C_EncodingUtil.DecodeBase64(value)
    if decoded == nil then
        error("Encoding: invalid encoding")
    end
    local decompressed = C_EncodingUtil.DecompressString(decoded)
    if decompressed == nil or #decompressed > maxBytes then
        error("Encoding: invalid or oversized compressed data")
    end
    return C_EncodingUtil.DeserializeCBOR(decompressed)
end
return ____exports

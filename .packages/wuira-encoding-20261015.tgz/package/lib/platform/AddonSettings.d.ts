import type { Cell } from "../ui/Cell";
/** Registers a JSX settings view in the client's native addon settings list. */
export declare class AddonSettings {
    readonly Frame: wuiraNativeFrame;
    private readonly category;
    constructor(name: string, view: Cell | (() => Cell | void));
    Open(): void;
    Close(): void;
}

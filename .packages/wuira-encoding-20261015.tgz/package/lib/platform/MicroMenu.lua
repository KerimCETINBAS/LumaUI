--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__NumberIsFinite(value)
    return type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge
end
-- End of Lua Library inline imports
local ____exports = {}
--- Style Forever's existing micro buttons without replacing their scripts or layout.
-- Disposing stops maintenance; reload restores the native textures.
function ____exports.skinMicroMenu(self, options)
    if options == nil then
        options = {}
    end
    local background = options.background or ({r = 0.035, g = 0.045, b = 0.065, a = 0.9})
    local border = options.border or ({r = 0.22, g = 0.28, b = 0.36, a = 0.8})
    local buttonBackground = options.buttonBackground or ({r = 0.08, g = 0.1, b = 0.14, a = 0.75})
    local icon = options.icon or ({r = 0.78, g = 0.83, b = 0.9})
    local accent = options.accent or ({r = 0.4, g = 0.75, b = 1})
    local disabledIcon = options.disabledIcon or ({r = 0.35, g = 0.38, b = 0.44})
    local padding = options.padding or 6
    if not __TS__NumberIsFinite(padding) or padding < 0 then
        error("MicroMenu: padding must be a non-negative number")
    end
    local listener = CreateFrame("Frame", nil, UIParent)
    local enabled = true
    local applying = false
    local hooked = false
    local panel
    local function tint(____, texture, color)
        if texture ~= nil then
            texture:SetVertexColor(color.r, color.g, color.b, color.a or 1)
        end
    end
    local function fill(____, texture, color)
        if texture ~= nil then
            texture:SetColorTexture(color.r, color.g, color.b, color.a or 1)
        end
    end
    local apply
    apply = function()
        if not enabled or applying or InCombatLockdown() then
            return
        end
        local menu = _G.MicroMenu
        if menu == nil then
            return
        end
        applying = true
        do
            local ____try, ____error = pcall(function()
                if not hooked and _G.LoadMicroButtonTextures ~= nil then
                    hooked = true
                    hooksecurefunc(
                        "LoadMicroButtonTextures",
                        function() return apply(nil) end
                    )
                end
                if panel == nil and options.panel ~= false then
                    panel = CreateFrame("Frame", nil, menu)
                    panel:EnableMouse(false)
                    panel:SetFrameLevel(menu:GetFrameLevel())
                    panel:SetPoint(
                        "TOPLEFT",
                        menu,
                        "TOPLEFT",
                        -padding,
                        padding
                    )
                    panel:SetPoint(
                        "BOTTOMRIGHT",
                        menu,
                        "BOTTOMRIGHT",
                        padding,
                        -padding
                    )
                    local bg = panel:CreateTexture(nil, "BACKGROUND")
                    bg:SetAllPoints(panel)
                    bg:SetColorTexture(background.r, background.g, background.b, background.a or 1)
                    for ____, edge in ipairs({"TOP", "BOTTOM", "LEFT", "RIGHT"}) do
                        local line = panel:CreateTexture(nil, "OVERLAY")
                        line:SetColorTexture(border.r, border.g, border.b, border.a or 1)
                        if edge == "TOP" or edge == "BOTTOM" then
                            local left = edge == "TOP" and "TOPLEFT" or "BOTTOMLEFT"
                            local right = edge == "TOP" and "TOPRIGHT" or "BOTTOMRIGHT"
                            line:SetPoint(
                                left,
                                panel,
                                left,
                                0,
                                0
                            )
                            line:SetPoint(
                                right,
                                panel,
                                right,
                                0,
                                0
                            )
                            line:SetSize(1, 1)
                        else
                            local top = edge == "LEFT" and "TOPLEFT" or "TOPRIGHT"
                            local bottom = edge == "LEFT" and "BOTTOMLEFT" or "BOTTOMRIGHT"
                            line:SetPoint(
                                top,
                                panel,
                                top,
                                0,
                                0
                            )
                            line:SetPoint(
                                bottom,
                                panel,
                                bottom,
                                0,
                                0
                            )
                            line:SetSize(1, 1)
                        end
                    end
                end
                local ____opt_4 = menu.BorderArt
                if ____opt_4 ~= nil then
                    ____opt_4:SetAlpha(0)
                end
                local ____opt_6 = menu.BackgroundArt
                if ____opt_6 ~= nil then
                    ____opt_6:SetAlpha(0)
                end
                for ____, name in ipairs({
                    "CharacterMicroButton",
                    "ProfessionMicroButton",
                    "SpellbookMicroButton",
                    "TalentMicroButton",
                    "PlayerSpellsMicroButton",
                    "QuestLogMicroButton",
                    "GuildMicroButton",
                    "LFDMicroButton",
                    "LegacyMicroButton",
                    "CollectionsMicroButton",
                    "EJMicroButton",
                    "AchievementMicroButton",
                    "HousingMicroButton",
                    "StoreMicroButton",
                    "MainMenuMicroButton",
                    "HelpMicroButton"
                }) do
                    do
                        local __continue17
                        repeat
                            local button = _G[name]
                            if button == nil then
                                __continue17 = true
                                break
                            end
                            fill(nil, button.Background, buttonBackground)
                            fill(nil, button.PushedBackground, {r = accent.r * 0.25, g = accent.g * 0.25, b = accent.b * 0.25, a = 0.9})
                            local ____opt_8 = button.Shadow
                            if ____opt_8 ~= nil then
                                ____opt_8:SetAlpha(0)
                            end
                            local ____opt_10 = button.PushedShadow
                            if ____opt_10 ~= nil then
                                ____opt_10:SetAlpha(0)
                            end
                            local ____opt_12 = button.GetNormalTexture
                            tint(
                                nil,
                                ____opt_12 and ____opt_12(button),
                                icon
                            )
                            local ____opt_14 = button.GetPushedTexture
                            tint(
                                nil,
                                ____opt_14 and ____opt_14(button),
                                accent
                            )
                            local ____opt_16 = button.GetHighlightTexture
                            tint(
                                nil,
                                ____opt_16 and ____opt_16(button),
                                accent
                            )
                            local ____opt_18 = button.GetDisabledTexture
                            tint(
                                nil,
                                ____opt_18 and ____opt_18(button),
                                disabledIcon
                            )
                            __continue17 = true
                        until true
                        if not __continue17 then
                            break
                        end
                    end
                end
            end)
            do
                applying = false
            end
            if not ____try then
                error(____error, 0)
            end
        end
    end
    listener:RegisterEvent("ADDON_LOADED")
    listener:RegisterEvent("PLAYER_ENTERING_WORLD")
    listener:RegisterEvent("PLAYER_REGEN_ENABLED")
    listener:SetScript("OnEvent", apply)
    apply(nil)
    return function()
        enabled = false
        listener:UnregisterAllEvents()
        listener:SetScript("OnEvent", nil)
        if panel ~= nil then
            panel:Hide()
        end
    end
end
return ____exports

import type { MicroMenuSkinOptions } from "./MicroMenu";
export interface BlizzardUIOptions {
    actionBars?: boolean;
    player?: boolean;
    target?: boolean;
    focus?: boolean;
}
/** Opt-in stock UI visibility. Native buttons, bindings and event handlers remain intact. */
export declare class BlizzardUI {
    private constructor();
    /** Style native micro-menu buttons. Reload restores their original textures. */
    static SkinMicroMenu(options?: MicroMenuSkinOptions): () => void;
    /** Disable stock action-bar event/update paths. Restoring their scripts requires reload. */
    static DisableActionBars(): () => void;
    /** Returns a restore function; protected changes wait until combat ends. */
    static Hide(options: BlizzardUIOptions): () => void;
}

export type CommandCallback = (this: void, ...args: string[]) => void;
/** Native slash registration, with an idempotent cleanup and no shared module state. */
export declare function registerCommand(command: string, callback: CommandCallback): () => void;

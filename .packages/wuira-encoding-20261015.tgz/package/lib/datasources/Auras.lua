--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end

local function __TS__ClassExtends(target, base)
    target.____super = base
    local staticMetatable = setmetatable({__index = base}, base)
    setmetatable(target, staticMetatable)
    local baseMetatable = getmetatable(base)
    if baseMetatable then
        if type(baseMetatable.__index) == "function" then
            staticMetatable.__index = baseMetatable.__index
        end
        if type(baseMetatable.__newindex) == "function" then
            staticMetatable.__newindex = baseMetatable.__newindex
        end
    end
    setmetatable(target.prototype, base.prototype)
    if type(base.prototype.__index) == "function" then
        target.prototype.__index = base.prototype.__index
    end
    if type(base.prototype.__newindex) == "function" then
        target.prototype.__newindex = base.prototype.__newindex
    end
    if type(base.prototype.__tostring) == "function" then
        target.prototype.__tostring = base.prototype.__tostring
    end
end

local function __TS__New(target, ...)
    local instance = setmetatable({}, target.prototype)
    instance:____constructor(...)
    return instance
end

local function __TS__CloneDescriptor(____bindingPattern0)
    local value
    local writable
    local set
    local get
    local configurable
    local enumerable
    enumerable = ____bindingPattern0.enumerable
    configurable = ____bindingPattern0.configurable
    get = ____bindingPattern0.get
    set = ____bindingPattern0.set
    writable = ____bindingPattern0.writable
    value = ____bindingPattern0.value
    local descriptor = {enumerable = enumerable == true, configurable = configurable == true}
    local hasGetterOrSetter = get ~= nil or set ~= nil
    local hasValueOrWritableAttribute = writable ~= nil or value ~= nil
    if hasGetterOrSetter and hasValueOrWritableAttribute then
        error("Invalid property descriptor. Cannot both specify accessors and a value or writable attribute.", 0)
    end
    if get or set then
        descriptor.get = get
        descriptor.set = set
    else
        descriptor.value = value
        descriptor.writable = writable == true
    end
    return descriptor
end

local __TS__DescriptorGet
do
    local getmetatable = _G.getmetatable
    local ____rawget = _G.rawget
    function __TS__DescriptorGet(self, metatable, key)
        while metatable do
            local rawResult = ____rawget(metatable, key)
            if rawResult ~= nil then
                return rawResult
            end
            local descriptors = ____rawget(metatable, "_descriptors")
            if descriptors then
                local descriptor = descriptors[key]
                if descriptor ~= nil then
                    if descriptor.get then
                        return descriptor.get(self)
                    end
                    return descriptor.value
                end
            end
            metatable = getmetatable(metatable)
        end
    end
end

local __TS__DescriptorSet
do
    local getmetatable = _G.getmetatable
    local ____rawget = _G.rawget
    local rawset = _G.rawset
    function __TS__DescriptorSet(self, metatable, key, value)
        while metatable do
            local descriptors = ____rawget(metatable, "_descriptors")
            if descriptors then
                local descriptor = descriptors[key]
                if descriptor ~= nil then
                    if descriptor.set then
                        descriptor.set(self, value)
                    else
                        if descriptor.writable == false then
                            error(
                                ((("Cannot assign to read only property '" .. key) .. "' of object '") .. tostring(self)) .. "'",
                                0
                            )
                        end
                        descriptor.value = value
                    end
                    return
                end
            end
            metatable = getmetatable(metatable)
        end
        rawset(self, key, value)
    end
end

local __TS__SetDescriptor
do
    local getmetatable = _G.getmetatable
    local function descriptorIndex(self, key)
        return __TS__DescriptorGet(
            self,
            getmetatable(self),
            key
        )
    end
    local function descriptorNewIndex(self, key, value)
        return __TS__DescriptorSet(
            self,
            getmetatable(self),
            key,
            value
        )
    end
    function __TS__SetDescriptor(target, key, desc, isPrototype)
        if isPrototype == nil then
            isPrototype = false
        end
        local ____isPrototype_0
        if isPrototype then
            ____isPrototype_0 = target
        else
            ____isPrototype_0 = getmetatable(target)
        end
        local metatable = ____isPrototype_0
        if not metatable then
            metatable = {}
            setmetatable(target, metatable)
        end
        if not isPrototype and not rawget(metatable, "_isOwnDescriptorMetatable") then
            local instanceMetatable = {}
            instanceMetatable._isOwnDescriptorMetatable = true
            setmetatable(instanceMetatable, metatable)
            setmetatable(target, instanceMetatable)
            metatable = instanceMetatable
        end
        local value = rawget(target, key)
        if value ~= nil then
            rawset(target, key, nil)
        end
        if not rawget(metatable, "_descriptors") then
            metatable._descriptors = {}
        end
        metatable._descriptors[key] = __TS__CloneDescriptor(desc)
        metatable.__index = descriptorIndex
        metatable.__newindex = descriptorNewIndex
    end
end
-- End of Lua Library inline imports
local ____exports = {}
local ____DataSource = require("datasources.DataSource")
local DataSource = ____DataSource.DataSource
local ____UnitSource = require("datasources.UnitSource")
local resolveUnit = ____UnitSource.resolveUnit
--- Readable aura snapshot. Unit tokens describe the source at snapshot time.
____exports.Aura = __TS__Class()
local Aura = ____exports.Aura
Aura.name = "Aura"
function Aura.prototype.____constructor(self, spellId, name, icon, sourceUnit, sourceStatus, sourceSelf)
    self.spellId = spellId
    self.name = name
    self.icon = icon
    self.sourceUnit = sourceUnit
    self.sourceStatus = sourceStatus
    self.sourceSelf = sourceSelf
end
function Aura.prototype.isSourceSelf(self)
    return self.sourceSelf
end
--- Reads a fresh snapshot on access; it does not install listeners or poll.
____exports.AuraSource = __TS__Class()
local AuraSource = ____exports.AuraSource
AuraSource.name = "AuraSource"
__TS__ClassExtends(AuraSource, DataSource)
function AuraSource.prototype.____constructor(self, unit, filter)
    DataSource.prototype.____constructor(self, {})
    self.filter = filter
    self.restricted = false
    self.target = resolveUnit(nil, unit)
end
function AuraSource.prototype.HasSecretFields(self)
    return self.restricted
end
function AuraSource.prototype.GetValue(self)
    self.restricted = false
    local read = C_UnitAuras and C_UnitAuras.GetAuraDataByIndex
    if read == nil then
        error("AuraSource: this client does not expose C_UnitAuras.GetAuraDataByIndex")
    end
    local result = {}
    do
        local index = 1
        while index <= 1024 do
            local raw = read(self.unit, index, self.filter)
            if issecretvalue(raw) then
                self.restricted = true
                return {}
            end
            if raw == nil then
                return result
            end
            if issecretvalue(raw.spellId) or issecretvalue(raw.name) or issecretvalue(raw.icon) then
                self.restricted = true
                return {}
            end
            local sourceUnit
            local sourceSelf
            local status = "unknown"
            if issecretvalue(raw.sourceUnit) then
                status = "restricted"
            elseif raw.sourceUnit ~= nil then
                sourceUnit = raw.sourceUnit
                status = "known"
                local ____self = UnitIsUnit(sourceUnit, "player")
                if not issecretvalue(____self) then
                    sourceSelf = ____self
                end
            end
            result[#result + 1] = __TS__New(
                ____exports.Aura,
                raw.spellId,
                raw.name,
                raw.icon,
                sourceUnit,
                status,
                sourceSelf
            )
            index = index + 1
        end
    end
    error("AuraSource: aura enumeration exceeded its safety limit")
end
__TS__SetDescriptor(
    AuraSource.prototype,
    "unit",
    {get = function(self)
        return self.target.Token
    end},
    true
)
____exports.Buffs = __TS__Class()
local Buffs = ____exports.Buffs
Buffs.name = "Buffs"
__TS__ClassExtends(Buffs, ____exports.AuraSource)
function Buffs.prototype.____constructor(self, unit)
    Buffs.____super.prototype.____constructor(self, unit, "HELPFUL")
end
____exports.Debuffs = __TS__Class()
local Debuffs = ____exports.Debuffs
Debuffs.name = "Debuffs"
__TS__ClassExtends(Debuffs, ____exports.AuraSource)
function Debuffs.prototype.____constructor(self, unit)
    Debuffs.____super.prototype.____constructor(self, unit, "HARMFUL")
end
return ____exports

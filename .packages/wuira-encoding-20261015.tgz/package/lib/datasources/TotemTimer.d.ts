import { TimerSource } from "./TimerSource";
export type TotemTimerStatus = "active" | "inactive" | "restricted" | "unavailable";
/** Player-owned ground effects exposed by the game's totem API, across spell ranks. */
export declare class TotemTimer extends TimerSource {
    readonly spell: number | string;
    private status;
    constructor(spell: number | string);
    get Status(): TotemTimerStatus;
    private ReadDuration;
}

import { DataSource } from "./DataSource";
import type { ProgressOverrides } from "./ProgressSource";
/** Opaque native object: pass it to the renderer instead of doing Lua arithmetic. */
export interface NativeDuration {
    readonly __wuiraDuration: unique symbol;
}
/** Duration reader whose animation is performed entirely by the native widget. */
export declare class TimerSource extends DataSource<NativeDuration | undefined> {
    private readonly read;
    private readonly events;
    private readonly unit?;
    private boundDuration?;
    private bindingCount;
    constructor(read: () => NativeDuration | undefined, events: readonly string[], unit?: string | undefined);
    protected GetValue(): NativeDuration | undefined;
    get IsActive(): boolean;
    /** A native radial cooldown owns timing, countdown text and completion effects. */
    BindCooldown(frame: wuiraNativeCooldown): () => void;
    BindTo(frame: wuiraNativeStatusBar, options?: ProgressOverrides): () => void;
}

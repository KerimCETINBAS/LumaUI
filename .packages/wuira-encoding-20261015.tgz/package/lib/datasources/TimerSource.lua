--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end

local function __TS__ClassExtends(target, base)
    target.____super = base
    local staticMetatable = setmetatable({__index = base}, base)
    setmetatable(target, staticMetatable)
    local baseMetatable = getmetatable(base)
    if baseMetatable then
        if type(baseMetatable.__index) == "function" then
            staticMetatable.__index = baseMetatable.__index
        end
        if type(baseMetatable.__newindex) == "function" then
            staticMetatable.__newindex = baseMetatable.__newindex
        end
    end
    setmetatable(target.prototype, base.prototype)
    if type(base.prototype.__index) == "function" then
        target.prototype.__index = base.prototype.__index
    end
    if type(base.prototype.__newindex) == "function" then
        target.prototype.__newindex = base.prototype.__newindex
    end
    if type(base.prototype.__tostring) == "function" then
        target.prototype.__tostring = base.prototype.__tostring
    end
end

local function __TS__StringStartsWith(self, searchString, position)
    if position == nil or position < 0 then
        position = 0
    end
    return string.sub(self, position + 1, #searchString + position) == searchString
end

local function __TS__CloneDescriptor(____bindingPattern0)
    local value
    local writable
    local set
    local get
    local configurable
    local enumerable
    enumerable = ____bindingPattern0.enumerable
    configurable = ____bindingPattern0.configurable
    get = ____bindingPattern0.get
    set = ____bindingPattern0.set
    writable = ____bindingPattern0.writable
    value = ____bindingPattern0.value
    local descriptor = {enumerable = enumerable == true, configurable = configurable == true}
    local hasGetterOrSetter = get ~= nil or set ~= nil
    local hasValueOrWritableAttribute = writable ~= nil or value ~= nil
    if hasGetterOrSetter and hasValueOrWritableAttribute then
        error("Invalid property descriptor. Cannot both specify accessors and a value or writable attribute.", 0)
    end
    if get or set then
        descriptor.get = get
        descriptor.set = set
    else
        descriptor.value = value
        descriptor.writable = writable == true
    end
    return descriptor
end

local __TS__DescriptorGet
do
    local getmetatable = _G.getmetatable
    local ____rawget = _G.rawget
    function __TS__DescriptorGet(self, metatable, key)
        while metatable do
            local rawResult = ____rawget(metatable, key)
            if rawResult ~= nil then
                return rawResult
            end
            local descriptors = ____rawget(metatable, "_descriptors")
            if descriptors then
                local descriptor = descriptors[key]
                if descriptor ~= nil then
                    if descriptor.get then
                        return descriptor.get(self)
                    end
                    return descriptor.value
                end
            end
            metatable = getmetatable(metatable)
        end
    end
end

local __TS__DescriptorSet
do
    local getmetatable = _G.getmetatable
    local ____rawget = _G.rawget
    local rawset = _G.rawset
    function __TS__DescriptorSet(self, metatable, key, value)
        while metatable do
            local descriptors = ____rawget(metatable, "_descriptors")
            if descriptors then
                local descriptor = descriptors[key]
                if descriptor ~= nil then
                    if descriptor.set then
                        descriptor.set(self, value)
                    else
                        if descriptor.writable == false then
                            error(
                                ((("Cannot assign to read only property '" .. key) .. "' of object '") .. tostring(self)) .. "'",
                                0
                            )
                        end
                        descriptor.value = value
                    end
                    return
                end
            end
            metatable = getmetatable(metatable)
        end
        rawset(self, key, value)
    end
end

local __TS__SetDescriptor
do
    local getmetatable = _G.getmetatable
    local function descriptorIndex(self, key)
        return __TS__DescriptorGet(
            self,
            getmetatable(self),
            key
        )
    end
    local function descriptorNewIndex(self, key, value)
        return __TS__DescriptorSet(
            self,
            getmetatable(self),
            key,
            value
        )
    end
    function __TS__SetDescriptor(target, key, desc, isPrototype)
        if isPrototype == nil then
            isPrototype = false
        end
        local ____isPrototype_0
        if isPrototype then
            ____isPrototype_0 = target
        else
            ____isPrototype_0 = getmetatable(target)
        end
        local metatable = ____isPrototype_0
        if not metatable then
            metatable = {}
            setmetatable(target, metatable)
        end
        if not isPrototype and not rawget(metatable, "_isOwnDescriptorMetatable") then
            local instanceMetatable = {}
            instanceMetatable._isOwnDescriptorMetatable = true
            setmetatable(instanceMetatable, metatable)
            setmetatable(target, instanceMetatable)
            metatable = instanceMetatable
        end
        local value = rawget(target, key)
        if value ~= nil then
            rawset(target, key, nil)
        end
        if not rawget(metatable, "_descriptors") then
            metatable._descriptors = {}
        end
        metatable._descriptors[key] = __TS__CloneDescriptor(desc)
        metatable.__index = descriptorIndex
        metatable.__newindex = descriptorNewIndex
    end
end
-- End of Lua Library inline imports
local ____exports = {}
local ____DataSource = require("datasources.DataSource")
local DataSource = ____DataSource.DataSource
--- Duration reader whose animation is performed entirely by the native widget.
____exports.TimerSource = __TS__Class()
local TimerSource = ____exports.TimerSource
TimerSource.name = "TimerSource"
__TS__ClassExtends(TimerSource, DataSource)
function TimerSource.prototype.____constructor(self, read, events, unit)
    DataSource.prototype.____constructor(self, nil)
    self.read = read
    self.events = events
    self.unit = unit
    self.bindingCount = 0
end
function TimerSource.prototype.GetValue(self)
    return self:read()
end
function TimerSource.prototype.BindCooldown(self, frame)
    if C_DurationUtil == nil then
        error("TimerSource: native duration support is unavailable")
    end
    local empty = C_DurationUtil.CreateDuration()
    local listener = CreateFrame("Frame", nil, UIParent)
    local function refresh()
        local duration = self:read()
        self.boundDuration = duration
        frame:SetCooldownFromDurationObject(
            self:CanEmit(duration) and (duration or empty) or empty,
            true
        )
    end
    listener:SetScript(
        "OnEvent",
        function(_frame, event, unit)
            if not __TS__StringStartsWith(event, "UNIT_") or self.unit == nil or unit == self.unit then
                refresh(nil)
            end
        end
    )
    for ____, event in ipairs(self.events) do
        listener:RegisterEvent(event)
    end
    self.bindingCount = self.bindingCount + 1
    do
        local function ____catch(failure)
            self.bindingCount = self.bindingCount - 1
            listener:UnregisterAllEvents()
            listener:SetScript("OnEvent", nil)
            error(failure, 0)
        end
        local ____try, ____hasReturned = pcall(function()
            refresh(nil)
        end)
        if not ____try then
            ____catch(____hasReturned)
        end
    end
    local disposed = false
    return function()
        if disposed then
            return
        end
        disposed = true
        self.bindingCount = self.bindingCount - 1
        listener:UnregisterAllEvents()
        listener:SetScript("OnEvent", nil)
        listener:Hide()
        frame:SetDrawBling(false)
        frame:Clear()
    end
end
function TimerSource.prototype.BindTo(self, frame, options)
    if options == nil then
        options = {}
    end
    if options.min ~= nil or options.max ~= nil or options.current ~= nil then
        error("TimerSource: min/max/current overrides are not supported")
    end
    local bar = frame
    local ____opt_0 = Enum and Enum.StatusBarInterpolation
    local immediate = ____opt_0 and ____opt_0.Immediate
    local ____opt_4 = Enum and Enum.StatusBarTimerDirection
    local remaining = ____opt_4 and ____opt_4.RemainingTime
    if bar.SetTimerDuration == nil or C_DurationUtil == nil or immediate == nil or remaining == nil then
        error("TimerSource: native timer support is unavailable")
    end
    local empty = C_DurationUtil.CreateDuration()
    bar:SetMinMaxValues(0, 1)
    local function refresh()
        local duration = self:read()
        self.boundDuration = duration
        local active = self:CanEmit(duration)
        local ____this_9
        ____this_9 = options
        local ____opt_8 = ____this_9.onActiveChange
        if ____opt_8 ~= nil then
            ____opt_8(____this_9, active)
        end
        if not active then
            return
        end
        if issecretvalue(duration) then
            bar:SetTimerDuration(duration, immediate, remaining)
            return
        end
        bar:SetTimerDuration(duration or empty, immediate, remaining)
        if duration == nil then
            bar:SetValue(0)
        end
    end
    frame:SetScript(
        "OnEvent",
        function(_frame, event, unit)
            if not __TS__StringStartsWith(event, "UNIT_") or self.unit == nil or unit == self.unit then
                refresh(nil)
            end
        end
    )
    for ____, event in ipairs(self.events) do
        frame:RegisterEvent(event)
    end
    self.bindingCount = self.bindingCount + 1
    refresh(nil)
    local disposed = false
    return function()
        if disposed then
            return
        end
        disposed = true
        self.bindingCount = self.bindingCount - 1
    end
end
__TS__SetDescriptor(
    TimerSource.prototype,
    "IsActive",
    {get = function(self)
        local ____temp_10
        if self.bindingCount > 0 then
            ____temp_10 = self.boundDuration
        else
            ____temp_10 = self:read()
        end
        local duration = ____temp_10
        if issecretvalue(duration) then
            return true
        end
        if duration == nil then
            return false
        end
        local ____this_12
        ____this_12 = duration
        local ____opt_11 = ____this_12.GetRemainingDuration
        local remaining = ____opt_11 and ____opt_11(____this_12)
        return issecretvalue(remaining) or remaining == nil or remaining > 0
    end},
    true
)
return ____exports

import { DataSource } from "./DataSource";
export type KnownSpellsStatus = "ready" | "unavailable" | "restricted";
export interface KnownSpell {
    readonly id: number;
    readonly name?: string;
    /** Undefined when the client cannot determine whether this spell is passive. */
    readonly isPassive?: boolean;
}
/** Cached learned player spellbook IDs. Native events refresh the snapshot; no polling. */
export declare class KnownSpells extends DataSource<readonly number[]> {
    private ids;
    private entries;
    private status;
    private readonly listeners;
    private readonly frame;
    private disposed;
    constructor();
    get Status(): KnownSpellsStatus;
    /** Detached cached metadata, with no native reads. Unreadable books return no entries. */
    get Entries(): readonly KnownSpell[];
    /** Whole-name glob over cached localized names. Supports * and ?, ignoring ASCII case. */
    Filter(pattern: string): readonly KnownSpell[];
    protected GetValue(): readonly number[];
    protected HasSecretFields(): boolean;
    /** Representative enum IDs match any learned rank through its localized name. */
    Has(spell: number | string): boolean;
    /** Resolve a representative spell ID or localized name to a learned rank. */
    Find(spell: number | string): KnownSpell | undefined;
    /** No initial emission; only changed, readable snapshots reach observers. */
    onChange(listener: (spells: readonly number[]) => void): () => void;
    private Refresh;
    Dispose(): void;
}

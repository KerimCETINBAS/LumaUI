import { DataSource } from "./DataSource";
export interface ProgressOverrides {
    min?: number;
    max?: number;
    current?: number;
    onActiveChange?: (active: boolean) => void;
    onRefresh?: () => void;
    healPredictionBar?: wuiraNativeStatusBar;
    absorbPredictionBar?: wuiraNativeStatusBar;
}
/** Shared contract for health, power, cooldowns, and other progress values. */
export declare abstract class ProgressSource extends DataSource<number> {
    private readonly readers;
    readonly Min: DataSource<number>;
    readonly Max: DataSource<number>;
    readonly Percent: DataSource<number>;
    protected constructor(readers: {
        current: () => number;
        min: () => number;
        max: () => number;
        percent: () => number;
    });
    protected GetValue(): number;
    IsSecret(): boolean;
    BindTo(frame: wuiraNativeStatusBar, options?: ProgressOverrides): void | (() => void);
    protected abstract Listen(frame: wuiraNativeFrame, refresh: () => void): void | (() => void);
}

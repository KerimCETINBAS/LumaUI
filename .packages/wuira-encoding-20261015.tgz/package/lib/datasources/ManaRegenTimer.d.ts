import { ProgressSource } from "./ProgressSource";
import type { ProgressOverrides } from "./ProgressSource";
type ObserveMana = (listener: (event: string, payload: unknown[], value: number) => void) => () => void;
export type ManaRegenPhase = "fiveSecondRule" | "estimatedTick" | "inactive";
/** Owned by Mana.UseRegenTimer(). The two-second phase is an estimate, not a server clock. */
export declare class ManaRegenTimer extends ProgressSource {
    private readonly observe;
    private phase;
    private start;
    private total;
    private manaChanged;
    private scheduled?;
    private unsubscribe?;
    private readonly bindings;
    private alphaCurve?;
    private disposed;
    constructor(observe: ObserveMana);
    get Phase(): ManaRegenPhase;
    get IsActive(): boolean;
    private Remaining;
    private OnManaEvent;
    private Begin;
    private Notify;
    private Stop;
    BindTo(frame: wuiraNativeStatusBar, options?: ProgressOverrides): () => void;
    protected Listen(): void;
    Dispose(): void;
}
export {};

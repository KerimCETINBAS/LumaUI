--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end

local function __TS__ClassExtends(target, base)
    target.____super = base
    local staticMetatable = setmetatable({__index = base}, base)
    setmetatable(target, staticMetatable)
    local baseMetatable = getmetatable(base)
    if baseMetatable then
        if type(baseMetatable.__index) == "function" then
            staticMetatable.__index = baseMetatable.__index
        end
        if type(baseMetatable.__newindex) == "function" then
            staticMetatable.__newindex = baseMetatable.__newindex
        end
    end
    setmetatable(target.prototype, base.prototype)
    if type(base.prototype.__index) == "function" then
        target.prototype.__index = base.prototype.__index
    end
    if type(base.prototype.__newindex) == "function" then
        target.prototype.__newindex = base.prototype.__newindex
    end
    if type(base.prototype.__tostring) == "function" then
        target.prototype.__tostring = base.prototype.__tostring
    end
end

local function __TS__CloneDescriptor(____bindingPattern0)
    local value
    local writable
    local set
    local get
    local configurable
    local enumerable
    enumerable = ____bindingPattern0.enumerable
    configurable = ____bindingPattern0.configurable
    get = ____bindingPattern0.get
    set = ____bindingPattern0.set
    writable = ____bindingPattern0.writable
    value = ____bindingPattern0.value
    local descriptor = {enumerable = enumerable == true, configurable = configurable == true}
    local hasGetterOrSetter = get ~= nil or set ~= nil
    local hasValueOrWritableAttribute = writable ~= nil or value ~= nil
    if hasGetterOrSetter and hasValueOrWritableAttribute then
        error("Invalid property descriptor. Cannot both specify accessors and a value or writable attribute.", 0)
    end
    if get or set then
        descriptor.get = get
        descriptor.set = set
    else
        descriptor.value = value
        descriptor.writable = writable == true
    end
    return descriptor
end

local __TS__DescriptorGet
do
    local getmetatable = _G.getmetatable
    local ____rawget = _G.rawget
    function __TS__DescriptorGet(self, metatable, key)
        while metatable do
            local rawResult = ____rawget(metatable, key)
            if rawResult ~= nil then
                return rawResult
            end
            local descriptors = ____rawget(metatable, "_descriptors")
            if descriptors then
                local descriptor = descriptors[key]
                if descriptor ~= nil then
                    if descriptor.get then
                        return descriptor.get(self)
                    end
                    return descriptor.value
                end
            end
            metatable = getmetatable(metatable)
        end
    end
end

local __TS__DescriptorSet
do
    local getmetatable = _G.getmetatable
    local ____rawget = _G.rawget
    local rawset = _G.rawset
    function __TS__DescriptorSet(self, metatable, key, value)
        while metatable do
            local descriptors = ____rawget(metatable, "_descriptors")
            if descriptors then
                local descriptor = descriptors[key]
                if descriptor ~= nil then
                    if descriptor.set then
                        descriptor.set(self, value)
                    else
                        if descriptor.writable == false then
                            error(
                                ((("Cannot assign to read only property '" .. key) .. "' of object '") .. tostring(self)) .. "'",
                                0
                            )
                        end
                        descriptor.value = value
                    end
                    return
                end
            end
            metatable = getmetatable(metatable)
        end
        rawset(self, key, value)
    end
end

local __TS__SetDescriptor
do
    local getmetatable = _G.getmetatable
    local function descriptorIndex(self, key)
        return __TS__DescriptorGet(
            self,
            getmetatable(self),
            key
        )
    end
    local function descriptorNewIndex(self, key, value)
        return __TS__DescriptorSet(
            self,
            getmetatable(self),
            key,
            value
        )
    end
    function __TS__SetDescriptor(target, key, desc, isPrototype)
        if isPrototype == nil then
            isPrototype = false
        end
        local ____isPrototype_0
        if isPrototype then
            ____isPrototype_0 = target
        else
            ____isPrototype_0 = getmetatable(target)
        end
        local metatable = ____isPrototype_0
        if not metatable then
            metatable = {}
            setmetatable(target, metatable)
        end
        if not isPrototype and not rawget(metatable, "_isOwnDescriptorMetatable") then
            local instanceMetatable = {}
            instanceMetatable._isOwnDescriptorMetatable = true
            setmetatable(instanceMetatable, metatable)
            setmetatable(target, instanceMetatable)
            metatable = instanceMetatable
        end
        local value = rawget(target, key)
        if value ~= nil then
            rawset(target, key, nil)
        end
        if not rawget(metatable, "_descriptors") then
            metatable._descriptors = {}
        end
        metatable._descriptors[key] = __TS__CloneDescriptor(desc)
        metatable.__index = descriptorIndex
        metatable.__newindex = descriptorNewIndex
    end
end
-- End of Lua Library inline imports
local ____exports = {}
local ____TimerSource = require("datasources.TimerSource")
local TimerSource = ____TimerSource.TimerSource
--- Player-owned ground effects exposed by the game's totem API, across spell ranks.
____exports.TotemTimer = __TS__Class()
local TotemTimer = ____exports.TotemTimer
TotemTimer.name = "TotemTimer"
__TS__ClassExtends(TotemTimer, TimerSource)
function TotemTimer.prototype.____constructor(self, spell)
    TimerSource.prototype.____constructor(
        self,
        function() return self:ReadDuration() end,
        {"PLAYER_TOTEM_UPDATE", "PLAYER_ENTERING_WORLD", "PLAYER_REGEN_ENABLED", "SPELLS_CHANGED"}
    )
    self.spell = spell
    self.status = "inactive"
end
function TotemTimer.prototype.ReadDuration(self)
    if GetTotemInfo == nil or GetTotemDuration == nil or GetNumTotemSlots == nil then
        self.status = "unavailable"
        return nil
    end
    local ____temp_4
    if type(self.spell) == "string" then
        ____temp_4 = self.spell
    else
        local ____opt_0 = C_Spell and C_Spell.GetSpellName
        ____temp_4 = ____opt_0 and ____opt_0(self.spell)
    end
    local name = ____temp_4
    if issecretvalue(name) then
        self.status = "restricted"
        return nil
    end
    local slots = GetNumTotemSlots()
    if issecretvalue(slots) then
        self.status = "restricted"
        return nil
    end
    local restricted = false
    do
        local slot = 1
        while slot <= slots do
            do
                local __continue9
                repeat
                    local active, effectName, ____, ____, ____, ____, spellId = GetTotemInfo(slot)
                    if issecretvalue(active) then
                        restricted = true
                        __continue9 = true
                        break
                    end
                    if not active then
                        __continue9 = true
                        break
                    end
                    local sameId = not issecretvalue(spellId) and spellId == self.spell
                    local sameName = not issecretvalue(effectName) and name ~= nil and effectName == name
                    if not sameId and not sameName then
                        if issecretvalue(spellId) or issecretvalue(effectName) then
                            restricted = true
                        end
                        __continue9 = true
                        break
                    end
                    self.status = "active"
                    return GetTotemDuration(slot)
                until true
                if not __continue9 then
                    break
                end
            end
            slot = slot + 1
        end
    end
    self.status = restricted and "restricted" or "inactive"
    return nil
end
__TS__SetDescriptor(
    TotemTimer.prototype,
    "Status",
    {get = function(self)
        self:ReadDuration()
        return self.status
    end},
    true
)
return ____exports

import { DataSource } from "./DataSource";
import { TextureSource } from "./TextureSource";
import { SpellCooldown } from "./SpellCooldown";
import type { SecureAction } from "../ui/SecureButton";
/** Localized spell identity, texture and native cooldown, independent of action slots. */
export declare class SpellSource extends DataSource<string | undefined> {
    readonly spellId: number;
    readonly Texture: TextureSource;
    readonly Cooldown: SpellCooldown;
    constructor(spellId: number);
    protected GetValue(): string | undefined;
    get Identifier(): number | string;
    get Action(): SecureAction;
}

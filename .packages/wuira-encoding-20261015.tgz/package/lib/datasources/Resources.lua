--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end

local function __TS__ClassExtends(target, base)
    target.____super = base
    local staticMetatable = setmetatable({__index = base}, base)
    setmetatable(target, staticMetatable)
    local baseMetatable = getmetatable(base)
    if baseMetatable then
        if type(baseMetatable.__index) == "function" then
            staticMetatable.__index = baseMetatable.__index
        end
        if type(baseMetatable.__newindex) == "function" then
            staticMetatable.__newindex = baseMetatable.__newindex
        end
    end
    setmetatable(target.prototype, base.prototype)
    if type(base.prototype.__index) == "function" then
        target.prototype.__index = base.prototype.__index
    end
    if type(base.prototype.__newindex) == "function" then
        target.prototype.__newindex = base.prototype.__newindex
    end
    if type(base.prototype.__tostring) == "function" then
        target.prototype.__tostring = base.prototype.__tostring
    end
end

local __TS__Symbol, Symbol
do
    local symbolMetatable = {__tostring = function(self)
        return ("Symbol(" .. (self.description or "")) .. ")"
    end}
    function __TS__Symbol(description)
        return setmetatable({description = description}, symbolMetatable)
    end
    Symbol = {
        asyncDispose = __TS__Symbol("Symbol.asyncDispose"),
        dispose = __TS__Symbol("Symbol.dispose"),
        iterator = __TS__Symbol("Symbol.iterator"),
        hasInstance = __TS__Symbol("Symbol.hasInstance"),
        species = __TS__Symbol("Symbol.species"),
        toStringTag = __TS__Symbol("Symbol.toStringTag")
    }
end

local __TS__Iterator
do
    local function iteratorGeneratorStep(self)
        local co = self.____coroutine
        local status, value = coroutine.resume(co)
        if not status then
            error(value, 0)
        end
        if coroutine.status(co) == "dead" then
            return
        end
        return true, value
    end
    local function iteratorIteratorStep(self)
        local result = self:next()
        if result.done then
            return
        end
        return true, result.value
    end
    local function iteratorStringStep(self, index)
        index = index + 1
        if index > #self then
            return
        end
        return index, string.sub(self, index, index)
    end
    function __TS__Iterator(iterable)
        if type(iterable) == "string" then
            return iteratorStringStep, iterable, 0
        elseif iterable.____coroutine ~= nil then
            return iteratorGeneratorStep, iterable
        elseif iterable[Symbol.iterator] then
            local iterator = iterable[Symbol.iterator](iterable)
            return iteratorIteratorStep, iterator
        else
            return ipairs(iterable)
        end
    end
end

local function __TS__New(target, ...)
    local instance = setmetatable({}, target.prototype)
    instance:____constructor(...)
    return instance
end

local Set
do
    Set = __TS__Class()
    Set.name = "Set"
    function Set.prototype.____constructor(self, values)
        self[Symbol.toStringTag] = "Set"
        self.size = 0
        self.nextKey = {}
        self.previousKey = {}
        if values == nil then
            return
        end
        local iterable = values
        if iterable[Symbol.iterator] then
            local iterator = iterable[Symbol.iterator](iterable)
            while true do
                local result = iterator:next()
                if result.done then
                    break
                end
                self:add(result.value)
            end
        else
            local array = values
            for ____, value in ipairs(array) do
                self:add(value)
            end
        end
    end
    function Set.prototype.add(self, value)
        local isNewValue = not self:has(value)
        if isNewValue then
            self.size = self.size + 1
        end
        if self.firstKey == nil then
            self.firstKey = value
            self.lastKey = value
        elseif isNewValue then
            self.nextKey[self.lastKey] = value
            self.previousKey[value] = self.lastKey
            self.lastKey = value
        end
        return self
    end
    function Set.prototype.clear(self)
        self.nextKey = {}
        self.previousKey = {}
        self.firstKey = nil
        self.lastKey = nil
        self.size = 0
    end
    function Set.prototype.delete(self, value)
        local contains = self:has(value)
        if contains then
            self.size = self.size - 1
            local next = self.nextKey[value]
            local previous = self.previousKey[value]
            if next ~= nil and previous ~= nil then
                self.nextKey[previous] = next
                self.previousKey[next] = previous
            elseif next ~= nil then
                self.firstKey = next
                self.previousKey[next] = nil
            elseif previous ~= nil then
                self.lastKey = previous
                self.nextKey[previous] = nil
            else
                self.firstKey = nil
                self.lastKey = nil
            end
            self.nextKey[value] = nil
            self.previousKey[value] = nil
        end
        return contains
    end
    function Set.prototype.forEach(self, callback)
        for ____, key in __TS__Iterator(self:keys()) do
            callback(nil, key, key, self)
        end
    end
    function Set.prototype.has(self, value)
        return self.nextKey[value] ~= nil or self.lastKey == value
    end
    Set.prototype[Symbol.iterator] = function(self)
        return self:values()
    end
    function Set.prototype.entries(self)
        local function getFirstKey()
            return self.firstKey
        end
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = {key, key}}
            end
        }
    end
    function Set.prototype.keys(self)
        local function getFirstKey()
            return self.firstKey
        end
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = key}
            end
        }
    end
    function Set.prototype.values(self)
        local function getFirstKey()
            return self.firstKey
        end
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = key}
            end
        }
    end
    function Set.prototype.union(self, other)
        local result = __TS__New(Set, self)
        for ____, item in __TS__Iterator(other) do
            result:add(item)
        end
        return result
    end
    function Set.prototype.intersection(self, other)
        local result = __TS__New(Set)
        for ____, item in __TS__Iterator(self) do
            if other:has(item) then
                result:add(item)
            end
        end
        return result
    end
    function Set.prototype.difference(self, other)
        local result = __TS__New(Set, self)
        for ____, item in __TS__Iterator(other) do
            result:delete(item)
        end
        return result
    end
    function Set.prototype.symmetricDifference(self, other)
        local result = __TS__New(Set, self)
        for ____, item in __TS__Iterator(other) do
            if self:has(item) then
                result:delete(item)
            else
                result:add(item)
            end
        end
        return result
    end
    function Set.prototype.isSubsetOf(self, other)
        for ____, item in __TS__Iterator(self) do
            if not other:has(item) then
                return false
            end
        end
        return true
    end
    function Set.prototype.isSupersetOf(self, other)
        for ____, item in __TS__Iterator(other) do
            if not self:has(item) then
                return false
            end
        end
        return true
    end
    function Set.prototype.isDisjointFrom(self, other)
        for ____, item in __TS__Iterator(self) do
            if other:has(item) then
                return false
            end
        end
        return true
    end
    Set[Symbol.species] = Set
end

local function __TS__ArrayIncludes(self, searchElement, fromIndex)
    if fromIndex == nil then
        fromIndex = 0
    end
    local len = #self
    local k = fromIndex
    if fromIndex < 0 then
        k = len + fromIndex
    end
    if k < 0 then
        k = 0
    end
    for i = k + 1, len do
        if self[i] == searchElement then
            return true
        end
    end
    return false
end

local function __TS__CloneDescriptor(____bindingPattern0)
    local value
    local writable
    local set
    local get
    local configurable
    local enumerable
    enumerable = ____bindingPattern0.enumerable
    configurable = ____bindingPattern0.configurable
    get = ____bindingPattern0.get
    set = ____bindingPattern0.set
    writable = ____bindingPattern0.writable
    value = ____bindingPattern0.value
    local descriptor = {enumerable = enumerable == true, configurable = configurable == true}
    local hasGetterOrSetter = get ~= nil or set ~= nil
    local hasValueOrWritableAttribute = writable ~= nil or value ~= nil
    if hasGetterOrSetter and hasValueOrWritableAttribute then
        error("Invalid property descriptor. Cannot both specify accessors and a value or writable attribute.", 0)
    end
    if get or set then
        descriptor.get = get
        descriptor.set = set
    else
        descriptor.value = value
        descriptor.writable = writable == true
    end
    return descriptor
end

local __TS__DescriptorGet
do
    local getmetatable = _G.getmetatable
    local ____rawget = _G.rawget
    function __TS__DescriptorGet(self, metatable, key)
        while metatable do
            local rawResult = ____rawget(metatable, key)
            if rawResult ~= nil then
                return rawResult
            end
            local descriptors = ____rawget(metatable, "_descriptors")
            if descriptors then
                local descriptor = descriptors[key]
                if descriptor ~= nil then
                    if descriptor.get then
                        return descriptor.get(self)
                    end
                    return descriptor.value
                end
            end
            metatable = getmetatable(metatable)
        end
    end
end

local __TS__DescriptorSet
do
    local getmetatable = _G.getmetatable
    local ____rawget = _G.rawget
    local rawset = _G.rawset
    function __TS__DescriptorSet(self, metatable, key, value)
        while metatable do
            local descriptors = ____rawget(metatable, "_descriptors")
            if descriptors then
                local descriptor = descriptors[key]
                if descriptor ~= nil then
                    if descriptor.set then
                        descriptor.set(self, value)
                    else
                        if descriptor.writable == false then
                            error(
                                ((("Cannot assign to read only property '" .. key) .. "' of object '") .. tostring(self)) .. "'",
                                0
                            )
                        end
                        descriptor.value = value
                    end
                    return
                end
            end
            metatable = getmetatable(metatable)
        end
        rawset(self, key, value)
    end
end

local __TS__SetDescriptor
do
    local getmetatable = _G.getmetatable
    local function descriptorIndex(self, key)
        return __TS__DescriptorGet(
            self,
            getmetatable(self),
            key
        )
    end
    local function descriptorNewIndex(self, key, value)
        return __TS__DescriptorSet(
            self,
            getmetatable(self),
            key,
            value
        )
    end
    function __TS__SetDescriptor(target, key, desc, isPrototype)
        if isPrototype == nil then
            isPrototype = false
        end
        local ____isPrototype_0
        if isPrototype then
            ____isPrototype_0 = target
        else
            ____isPrototype_0 = getmetatable(target)
        end
        local metatable = ____isPrototype_0
        if not metatable then
            metatable = {}
            setmetatable(target, metatable)
        end
        if not isPrototype and not rawget(metatable, "_isOwnDescriptorMetatable") then
            local instanceMetatable = {}
            instanceMetatable._isOwnDescriptorMetatable = true
            setmetatable(instanceMetatable, metatable)
            setmetatable(target, instanceMetatable)
            metatable = instanceMetatable
        end
        local value = rawget(target, key)
        if value ~= nil then
            rawset(target, key, nil)
        end
        if not rawget(metatable, "_descriptors") then
            metatable._descriptors = {}
        end
        metatable._descriptors[key] = __TS__CloneDescriptor(desc)
        metatable.__index = descriptorIndex
        metatable.__newindex = descriptorNewIndex
    end
end

local function __TS__ObjectAssign(target, ...)
    local sources = {...}
    for i = 1, #sources do
        local source = sources[i]
        if type(source) == "table" then
            for key in pairs(source) do
                target[key] = source[key]
            end
        end
    end
    return target
end
-- End of Lua Library inline imports
local ____exports = {}
local ____ProgressSource = require("datasources.ProgressSource")
local ProgressSource = ____ProgressSource.ProgressSource
local ____UnitSource = require("datasources.UnitSource")
local Unit = ____UnitSource.Unit
local resolveUnit = ____UnitSource.resolveUnit
local ____DataSource = require("datasources.DataSource")
local DataSource = ____DataSource.DataSource
local ____ManaRegenTimer = require("datasources.ManaRegenTimer")
local ManaRegenTimer = ____ManaRegenTimer.ManaRegenTimer
do
    local ____UnitSource = require("datasources.UnitSource")
    ____exports.Unit = ____UnitSource.Unit
end
--- Direct API-to-widget binding; opaque values are never compared or calculated.
local Resource = __TS__Class()
Resource.name = "Resource"
__TS__ClassExtends(Resource, ProgressSource)
function Resource.prototype.____constructor(self, current, maximum, percent, unitToken, events)
    ProgressSource.prototype.____constructor(
        self,
        {
            current = current,
            min = function() return 0 end,
            max = maximum,
            percent = percent
        }
    )
    self.unitToken = unitToken
    self.events = events
    self.listeners = __TS__New(Set)
    self.dispatching = false
    self.eventValue = 0
end
function Resource.prototype.AddEvents(self, ...)
    local events = {...}
    for ____, event in ipairs(events) do
        do
            local __continue5
            repeat
                if __TS__ArrayIncludes(self.events, event) then
                    __continue5 = true
                    break
                end
                local ____self_events_0 = self.events
                ____self_events_0[#____self_events_0 + 1] = event
                if self.listeners.size > 0 then
                    local ____opt_1 = self.eventFrame
                    if ____opt_1 ~= nil then
                        ____opt_1:RegisterEvent(event)
                    end
                end
                __continue5 = true
            until true
            if not __continue5 then
                break
            end
        end
    end
end
function Resource.prototype.GetValue(self)
    return self.dispatching and self.eventValue or ProgressSource.prototype.GetValue(self)
end
function Resource.prototype.onChange(self, listener)
    local previous = self:GetValue()
    local readable = not issecretvalue(previous)
    return self:Observe(function(____, _, _payload, value)
        if issecretvalue(value) or not self:CanEmit(value) then
            return
        end
        if readable and value == previous then
            return
        end
        previous = value
        readable = true
        listener(nil, value)
    end)
end
function Resource.prototype.Observe(self, listener)
    self.listeners:add(listener)
    if self.listeners.size == 1 then
        if self.eventFrame == nil then
            self.eventFrame = CreateFrame("Frame", nil, UIParent)
        end
        local frame = self.eventFrame
        frame:SetScript(
            "OnEvent",
            function(_frame, event, ...)
                local payload = {...}
                if event ~= "PLAYER_ENTERING_WORLD" and (issecretvalue(payload[1]) or payload[1] ~= self.unitToken) then
                    return
                end
                self.eventValue = ProgressSource.prototype.GetValue(self)
                self.dispatching = true
                do
                    local ____try, ____error = pcall(function()
                        for ____, callback in __TS__Iterator(self.listeners) do
                            callback(nil, event, payload, self.eventValue)
                        end
                    end)
                    do
                        self.dispatching = false
                    end
                    if not ____try then
                        error(____error, 0)
                    end
                end
            end
        )
        frame:RegisterEvent("PLAYER_ENTERING_WORLD")
        for ____, event in ipairs(self.events) do
            frame:RegisterEvent(event)
        end
    end
    return function()
        self.listeners:delete(listener)
        if self.listeners.size == 0 then
            local ____opt_3 = self.eventFrame
            if ____opt_3 ~= nil then
                ____opt_3:UnregisterAllEvents()
            end
            local ____opt_5 = self.eventFrame
            if ____opt_5 ~= nil then
                ____opt_5:SetScript("OnEvent", nil)
            end
        end
    end
end
function Resource.prototype.Listen(self, _frame, refresh)
    return self:Observe(function() return refresh(nil) end)
end
--- Live optional prediction channel. Secret amounts only travel to native sinks.
____exports.HealthPrediction = __TS__Class()
local HealthPrediction = ____exports.HealthPrediction
HealthPrediction.name = "HealthPrediction"
__TS__ClassExtends(HealthPrediction, DataSource)
function HealthPrediction.prototype.____constructor(self, read)
    DataSource.prototype.____constructor(self, 0)
    self.read = read
end
function HealthPrediction.prototype.GetValue(self)
    local ____opt_7 = self.read
    local value = ____opt_7 and ____opt_7(self)
    if issecretvalue(value) then
        return value
    end
    return value or 0
end
function HealthPrediction.prototype.ApplyTo(self, frame, maximum)
    if not self.IsAvailable then
        frame:Hide()
        return
    end
    local value = self:GetValue()
    if not self:CanEmit(value) then
        frame:Hide()
        return
    end
    frame:SetMinMaxValues(0, maximum)
    frame:SetValue(value)
    frame:Show()
end
__TS__SetDescriptor(
    HealthPrediction.prototype,
    "IsAvailable",
    {get = function(self)
        return self.read ~= nil
    end},
    true
)
____exports.HP = __TS__Class()
local HP = ____exports.HP
HP.name = "HP"
__TS__ClassExtends(HP, Resource)
function HP.prototype.____constructor(self, unit)
    if unit == nil then
        unit = Unit.Player
    end
    local target = resolveUnit(nil, unit)
    Resource.prototype.____constructor(
        self,
        function() return UnitHealth(target.Token) end,
        function() return UnitHealthMax(target.Token) end,
        function() return UnitHealthPercent(target.Token, true, CurveConstants.ScaleTo100) end,
        target.Token,
        {"UNIT_HEALTH", "UNIT_MAXHEALTH"}
    )
    self.target = target
end
function HP.prototype.UseHealPrediction(self)
    if self.healPrediction == nil then
        local ____exports_HealthPrediction_10 = ____exports.HealthPrediction
        local ____temp_9
        if UnitGetIncomingHeals == nil then
            ____temp_9 = nil
        else
            ____temp_9 = function() return UnitGetIncomingHeals(self.unit) end
        end
        self.healPrediction = __TS__New(____exports_HealthPrediction_10, ____temp_9)
        if self.healPrediction.IsAvailable then
            self:AddEvents("UNIT_HEAL_PREDICTION")
        end
    end
    return self
end
function HP.prototype.UseAbsorbPrediction(self)
    if self.absorbPrediction == nil then
        local ____exports_HealthPrediction_12 = ____exports.HealthPrediction
        local ____temp_11
        if UnitGetTotalAbsorbs == nil then
            ____temp_11 = nil
        else
            ____temp_11 = function() return UnitGetTotalAbsorbs(self.unit) end
        end
        self.absorbPrediction = __TS__New(____exports_HealthPrediction_12, ____temp_11)
        if self.absorbPrediction.IsAvailable then
            self:AddEvents("UNIT_ABSORB_AMOUNT_CHANGED")
        end
    end
    return self
end
function HP.prototype.BindTo(self, frame, options)
    if options == nil then
        options = {}
    end
    if (options.healPredictionBar ~= nil or options.absorbPredictionBar ~= nil) and (options.min ~= nil or options.max ~= nil or options.current ~= nil) then
        error("HP: prediction overlays require the native health scale without min/max/current overrides")
    end
    return Resource.prototype.BindTo(
        self,
        frame,
        __TS__ObjectAssign(
            {},
            options,
            {onRefresh = function()
                if options.healPredictionBar ~= nil or options.absorbPredictionBar ~= nil then
                    local maximum = UnitHealthMax(self.unit)
                    if options.healPredictionBar ~= nil then
                        local ____opt_13 = self.healPrediction
                        if ____opt_13 ~= nil then
                            ____opt_13:ApplyTo(options.healPredictionBar, maximum)
                        end
                    end
                    if options.absorbPredictionBar ~= nil then
                        local ____opt_15 = self.absorbPrediction
                        if ____opt_15 ~= nil then
                            ____opt_15:ApplyTo(options.absorbPredictionBar, maximum)
                        end
                    end
                end
                local ____this_18
                ____this_18 = options
                local ____opt_17 = ____this_18.onRefresh
                if ____opt_17 ~= nil then
                    ____opt_17(____this_18)
                end
            end}
        )
    )
end
__TS__SetDescriptor(
    HP.prototype,
    "HealPrediction",
    {get = function(self)
        return self.healPrediction
    end},
    true
)
__TS__SetDescriptor(
    HP.prototype,
    "AbsorbPrediction",
    {get = function(self)
        return self.absorbPrediction
    end},
    true
)
__TS__SetDescriptor(
    HP.prototype,
    "unit",
    {get = function(self)
        return self.target.Token
    end},
    true
)
--- Explicit mana (power type 0), even while the unit uses rage/energy.
____exports.Mana = __TS__Class()
local Mana = ____exports.Mana
Mana.name = "Mana"
__TS__ClassExtends(Mana, Resource)
function Mana.prototype.____constructor(self, unit)
    local target = resolveUnit(nil, unit)
    Resource.prototype.____constructor(
        self,
        function() return UnitPower(target.Token, 0) end,
        function() return UnitPowerMax(target.Token, 0) end,
        function() return UnitPowerPercent(target.Token, 0, true, CurveConstants.ScaleTo100) end,
        target.Token,
        {"UNIT_POWER_UPDATE", "UNIT_MAXPOWER", "UNIT_DISPLAYPOWER"}
    )
    self.target = target
end
function Mana.prototype.UseRegenTimer(self)
    if self.unit ~= "player" then
        error("Mana.UseRegenTimer: only the player is supported")
    end
    if self.regenTimer == nil then
        self:AddEvents("UNIT_SPELLCAST_SUCCEEDED")
        self.regenTimer = __TS__New(
            ManaRegenTimer,
            function(____, listener) return self:Observe(listener) end
        )
    end
    return self
end
__TS__SetDescriptor(
    Mana.prototype,
    "RegenTimer",
    {get = function(self)
        return self.regenTimer
    end},
    true
)
__TS__SetDescriptor(
    Mana.prototype,
    "unit",
    {get = function(self)
        return self.target.Token
    end},
    true
)
____exports.DataSources = {Resources = {HP = ____exports.HP, Mana = ____exports.Mana}}
return ____exports

import { DataSource } from "./DataSource";
/** Read-only API value; no cached assignment or game-state mutation. */
export declare class NativeNumberSource extends DataSource<number> {
    private readonly read;
    constructor(read: () => number);
    protected GetValue(): number;
}

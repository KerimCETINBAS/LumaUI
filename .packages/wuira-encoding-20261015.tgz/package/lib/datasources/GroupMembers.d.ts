import { DataSource } from "./DataSource";
export type GroupScope = "auto" | "party" | "raid";
/** Fresh roster tokens, including offline members. Tokens are not persistent identities. */
export declare class GroupMembers extends DataSource<readonly string[]> {
    readonly scope: GroupScope;
    private restricted;
    constructor(scope?: GroupScope);
    protected HasSecretFields(): boolean;
    protected GetValue(): readonly string[];
}
/** Includes the player in a party; empty when solo or in a raid. */
export declare class PartyMembers extends GroupMembers {
    constructor();
}
/** Includes the player through their raidN token; empty outside a raid. */
export declare class RaidMembers extends GroupMembers {
    constructor();
}

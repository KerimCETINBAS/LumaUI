import { ProgressSource } from "./ProgressSource";
import type { ProgressOverrides } from "./ProgressSource";
export declare const SwingHand: {
    readonly MainHand: "MainHand";
    readonly OffHand: "OffHand";
    readonly Ranged: "Ranged";
};
export type SwingHand = typeof SwingHand[keyof typeof SwingHand];
/** Player-only countdown driven by Forever's native PLAYER_SWING event. */
export declare class SwingTimer extends ProgressSource {
    readonly hand: SwingHand;
    private duration;
    private endTime;
    private known;
    private restricted;
    private events?;
    private readonly bindings;
    constructor(hand?: SwingHand);
    /** False until a readable swing event is received, including after reload/reset. */
    get HasTiming(): boolean;
    get IsActive(): boolean;
    protected HasSecretFields(): boolean;
    private Remaining;
    Start(): void;
    private Reset;
    private Notify;
    BindTo(frame: wuiraNativeStatusBar, options?: ProgressOverrides): () => void;
    protected Listen(): void;
    /** Dispose when the owning feature is removed; unmount only detaches its bars. */
    Dispose(): void;
}

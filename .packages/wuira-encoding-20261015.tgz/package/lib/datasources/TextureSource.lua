--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end

local function __TS__ClassExtends(target, base)
    target.____super = base
    local staticMetatable = setmetatable({__index = base}, base)
    setmetatable(target, staticMetatable)
    local baseMetatable = getmetatable(base)
    if baseMetatable then
        if type(baseMetatable.__index) == "function" then
            staticMetatable.__index = baseMetatable.__index
        end
        if type(baseMetatable.__newindex) == "function" then
            staticMetatable.__newindex = baseMetatable.__newindex
        end
    end
    setmetatable(target.prototype, base.prototype)
    if type(base.prototype.__index) == "function" then
        target.prototype.__index = base.prototype.__index
    end
    if type(base.prototype.__newindex) == "function" then
        target.prototype.__newindex = base.prototype.__newindex
    end
    if type(base.prototype.__tostring) == "function" then
        target.prototype.__tostring = base.prototype.__tostring
    end
end

local function __TS__StringStartsWith(self, searchString, position)
    if position == nil or position < 0 then
        position = 0
    end
    return string.sub(self, position + 1, #searchString + position) == searchString
end
-- End of Lua Library inline imports
local ____exports = {}
local ____DataSource = require("datasources.DataSource")
local DataSource = ____DataSource.DataSource
--- A native texture reader with event-driven updates; no per-frame polling.
____exports.TextureSource = __TS__Class()
local TextureSource = ____exports.TextureSource
TextureSource.name = "TextureSource"
__TS__ClassExtends(TextureSource, DataSource)
function TextureSource.prototype.____constructor(self, read, events, unit)
    DataSource.prototype.____constructor(self, nil)
    self.read = read
    self.events = events
    self.unit = unit
end
function TextureSource.prototype.GetValue(self)
    return self:read()
end
function TextureSource.prototype.BindTo(self, frame, texture, onActiveChange)
    local function refresh()
        local value = self:read()
        local active = self:CanEmit(value)
        if onActiveChange ~= nil then
            onActiveChange(nil, active)
        end
        if active then
            texture:SetTexture(value)
        end
    end
    frame:SetScript(
        "OnEvent",
        function(_frame, event, unit)
            if not __TS__StringStartsWith(event, "UNIT_") or self.unit == nil or unit == self.unit then
                refresh(nil)
            end
        end
    )
    for ____, event in ipairs(self.events) do
        frame:RegisterEvent(event)
    end
    refresh(nil)
end
return ____exports

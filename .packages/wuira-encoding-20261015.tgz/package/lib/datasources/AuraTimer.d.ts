import { TimerSource } from "./TimerSource";
import { TextureSource } from "./TextureSource";
import { UnitSource } from "./UnitSource";
import type { UnitInput } from "./UnitSource";
export interface AuraTimerOptions {
    /** Spell IDs resolve to localized names, so different ranks share a lookup. */
    spellIds: readonly number[];
    filter?: "HELPFUL" | "HARMFUL" | "HELPFUL|PLAYER" | "HARMFUL|PLAYER";
}
export type AuraTimerStatus = "active" | "inactive" | "restricted" | "unavailable";
/** Selected aura duration and icon; selection policy belongs to the application. */
export declare class AuraTimer extends TimerSource {
    private readonly options;
    readonly target: UnitSource;
    readonly Texture: TextureSource;
    private status;
    constructor(unit: UnitInput, options: AuraTimerOptions);
    get Status(): AuraTimerStatus;
    private ReadAura;
    private ReadDuration;
}

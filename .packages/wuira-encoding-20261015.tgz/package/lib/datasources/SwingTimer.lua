--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end

local function __TS__ClassExtends(target, base)
    target.____super = base
    local staticMetatable = setmetatable({__index = base}, base)
    setmetatable(target, staticMetatable)
    local baseMetatable = getmetatable(base)
    if baseMetatable then
        if type(baseMetatable.__index) == "function" then
            staticMetatable.__index = baseMetatable.__index
        end
        if type(baseMetatable.__newindex) == "function" then
            staticMetatable.__newindex = baseMetatable.__newindex
        end
    end
    setmetatable(target.prototype, base.prototype)
    if type(base.prototype.__index) == "function" then
        target.prototype.__index = base.prototype.__index
    end
    if type(base.prototype.__newindex) == "function" then
        target.prototype.__newindex = base.prototype.__newindex
    end
    if type(base.prototype.__tostring) == "function" then
        target.prototype.__tostring = base.prototype.__tostring
    end
end

local __TS__Symbol, Symbol
do
    local symbolMetatable = {__tostring = function(self)
        return ("Symbol(" .. (self.description or "")) .. ")"
    end}
    function __TS__Symbol(description)
        return setmetatable({description = description}, symbolMetatable)
    end
    Symbol = {
        asyncDispose = __TS__Symbol("Symbol.asyncDispose"),
        dispose = __TS__Symbol("Symbol.dispose"),
        iterator = __TS__Symbol("Symbol.iterator"),
        hasInstance = __TS__Symbol("Symbol.hasInstance"),
        species = __TS__Symbol("Symbol.species"),
        toStringTag = __TS__Symbol("Symbol.toStringTag")
    }
end

local __TS__Iterator
do
    local function iteratorGeneratorStep(self)
        local co = self.____coroutine
        local status, value = coroutine.resume(co)
        if not status then
            error(value, 0)
        end
        if coroutine.status(co) == "dead" then
            return
        end
        return true, value
    end
    local function iteratorIteratorStep(self)
        local result = self:next()
        if result.done then
            return
        end
        return true, result.value
    end
    local function iteratorStringStep(self, index)
        index = index + 1
        if index > #self then
            return
        end
        return index, string.sub(self, index, index)
    end
    function __TS__Iterator(iterable)
        if type(iterable) == "string" then
            return iteratorStringStep, iterable, 0
        elseif iterable.____coroutine ~= nil then
            return iteratorGeneratorStep, iterable
        elseif iterable[Symbol.iterator] then
            local iterator = iterable[Symbol.iterator](iterable)
            return iteratorIteratorStep, iterator
        else
            return ipairs(iterable)
        end
    end
end

local function __TS__New(target, ...)
    local instance = setmetatable({}, target.prototype)
    instance:____constructor(...)
    return instance
end

local Set
do
    Set = __TS__Class()
    Set.name = "Set"
    function Set.prototype.____constructor(self, values)
        self[Symbol.toStringTag] = "Set"
        self.size = 0
        self.nextKey = {}
        self.previousKey = {}
        if values == nil then
            return
        end
        local iterable = values
        if iterable[Symbol.iterator] then
            local iterator = iterable[Symbol.iterator](iterable)
            while true do
                local result = iterator:next()
                if result.done then
                    break
                end
                self:add(result.value)
            end
        else
            local array = values
            for ____, value in ipairs(array) do
                self:add(value)
            end
        end
    end
    function Set.prototype.add(self, value)
        local isNewValue = not self:has(value)
        if isNewValue then
            self.size = self.size + 1
        end
        if self.firstKey == nil then
            self.firstKey = value
            self.lastKey = value
        elseif isNewValue then
            self.nextKey[self.lastKey] = value
            self.previousKey[value] = self.lastKey
            self.lastKey = value
        end
        return self
    end
    function Set.prototype.clear(self)
        self.nextKey = {}
        self.previousKey = {}
        self.firstKey = nil
        self.lastKey = nil
        self.size = 0
    end
    function Set.prototype.delete(self, value)
        local contains = self:has(value)
        if contains then
            self.size = self.size - 1
            local next = self.nextKey[value]
            local previous = self.previousKey[value]
            if next ~= nil and previous ~= nil then
                self.nextKey[previous] = next
                self.previousKey[next] = previous
            elseif next ~= nil then
                self.firstKey = next
                self.previousKey[next] = nil
            elseif previous ~= nil then
                self.lastKey = previous
                self.nextKey[previous] = nil
            else
                self.firstKey = nil
                self.lastKey = nil
            end
            self.nextKey[value] = nil
            self.previousKey[value] = nil
        end
        return contains
    end
    function Set.prototype.forEach(self, callback)
        for ____, key in __TS__Iterator(self:keys()) do
            callback(nil, key, key, self)
        end
    end
    function Set.prototype.has(self, value)
        return self.nextKey[value] ~= nil or self.lastKey == value
    end
    Set.prototype[Symbol.iterator] = function(self)
        return self:values()
    end
    function Set.prototype.entries(self)
        local function getFirstKey()
            return self.firstKey
        end
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = {key, key}}
            end
        }
    end
    function Set.prototype.keys(self)
        local function getFirstKey()
            return self.firstKey
        end
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = key}
            end
        }
    end
    function Set.prototype.values(self)
        local function getFirstKey()
            return self.firstKey
        end
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = key}
            end
        }
    end
    function Set.prototype.union(self, other)
        local result = __TS__New(Set, self)
        for ____, item in __TS__Iterator(other) do
            result:add(item)
        end
        return result
    end
    function Set.prototype.intersection(self, other)
        local result = __TS__New(Set)
        for ____, item in __TS__Iterator(self) do
            if other:has(item) then
                result:add(item)
            end
        end
        return result
    end
    function Set.prototype.difference(self, other)
        local result = __TS__New(Set, self)
        for ____, item in __TS__Iterator(other) do
            result:delete(item)
        end
        return result
    end
    function Set.prototype.symmetricDifference(self, other)
        local result = __TS__New(Set, self)
        for ____, item in __TS__Iterator(other) do
            if self:has(item) then
                result:delete(item)
            else
                result:add(item)
            end
        end
        return result
    end
    function Set.prototype.isSubsetOf(self, other)
        for ____, item in __TS__Iterator(self) do
            if not other:has(item) then
                return false
            end
        end
        return true
    end
    function Set.prototype.isSupersetOf(self, other)
        for ____, item in __TS__Iterator(other) do
            if not self:has(item) then
                return false
            end
        end
        return true
    end
    function Set.prototype.isDisjointFrom(self, other)
        for ____, item in __TS__Iterator(self) do
            if other:has(item) then
                return false
            end
        end
        return true
    end
    Set[Symbol.species] = Set
end

local __TS__Unpack = table.unpack or unpack

local function __TS__NumberIsFinite(value)
    return type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge
end

local function __TS__CloneDescriptor(____bindingPattern0)
    local value
    local writable
    local set
    local get
    local configurable
    local enumerable
    enumerable = ____bindingPattern0.enumerable
    configurable = ____bindingPattern0.configurable
    get = ____bindingPattern0.get
    set = ____bindingPattern0.set
    writable = ____bindingPattern0.writable
    value = ____bindingPattern0.value
    local descriptor = {enumerable = enumerable == true, configurable = configurable == true}
    local hasGetterOrSetter = get ~= nil or set ~= nil
    local hasValueOrWritableAttribute = writable ~= nil or value ~= nil
    if hasGetterOrSetter and hasValueOrWritableAttribute then
        error("Invalid property descriptor. Cannot both specify accessors and a value or writable attribute.", 0)
    end
    if get or set then
        descriptor.get = get
        descriptor.set = set
    else
        descriptor.value = value
        descriptor.writable = writable == true
    end
    return descriptor
end

local __TS__DescriptorGet
do
    local getmetatable = _G.getmetatable
    local ____rawget = _G.rawget
    function __TS__DescriptorGet(self, metatable, key)
        while metatable do
            local rawResult = ____rawget(metatable, key)
            if rawResult ~= nil then
                return rawResult
            end
            local descriptors = ____rawget(metatable, "_descriptors")
            if descriptors then
                local descriptor = descriptors[key]
                if descriptor ~= nil then
                    if descriptor.get then
                        return descriptor.get(self)
                    end
                    return descriptor.value
                end
            end
            metatable = getmetatable(metatable)
        end
    end
end

local __TS__DescriptorSet
do
    local getmetatable = _G.getmetatable
    local ____rawget = _G.rawget
    local rawset = _G.rawset
    function __TS__DescriptorSet(self, metatable, key, value)
        while metatable do
            local descriptors = ____rawget(metatable, "_descriptors")
            if descriptors then
                local descriptor = descriptors[key]
                if descriptor ~= nil then
                    if descriptor.set then
                        descriptor.set(self, value)
                    else
                        if descriptor.writable == false then
                            error(
                                ((("Cannot assign to read only property '" .. key) .. "' of object '") .. tostring(self)) .. "'",
                                0
                            )
                        end
                        descriptor.value = value
                    end
                    return
                end
            end
            metatable = getmetatable(metatable)
        end
        rawset(self, key, value)
    end
end

local __TS__SetDescriptor
do
    local getmetatable = _G.getmetatable
    local function descriptorIndex(self, key)
        return __TS__DescriptorGet(
            self,
            getmetatable(self),
            key
        )
    end
    local function descriptorNewIndex(self, key, value)
        return __TS__DescriptorSet(
            self,
            getmetatable(self),
            key,
            value
        )
    end
    function __TS__SetDescriptor(target, key, desc, isPrototype)
        if isPrototype == nil then
            isPrototype = false
        end
        local ____isPrototype_0
        if isPrototype then
            ____isPrototype_0 = target
        else
            ____isPrototype_0 = getmetatable(target)
        end
        local metatable = ____isPrototype_0
        if not metatable then
            metatable = {}
            setmetatable(target, metatable)
        end
        if not isPrototype and not rawget(metatable, "_isOwnDescriptorMetatable") then
            local instanceMetatable = {}
            instanceMetatable._isOwnDescriptorMetatable = true
            setmetatable(instanceMetatable, metatable)
            setmetatable(target, instanceMetatable)
            metatable = instanceMetatable
        end
        local value = rawget(target, key)
        if value ~= nil then
            rawset(target, key, nil)
        end
        if not rawget(metatable, "_descriptors") then
            metatable._descriptors = {}
        end
        metatable._descriptors[key] = __TS__CloneDescriptor(desc)
        metatable.__index = descriptorIndex
        metatable.__newindex = descriptorNewIndex
    end
end
-- End of Lua Library inline imports
local ____exports = {}
local ____ProgressSource = require("datasources.ProgressSource")
local ProgressSource = ____ProgressSource.ProgressSource
____exports.SwingHand = {MainHand = "MainHand", OffHand = "OffHand", Ranged = "Ranged"}
--- Player-only countdown driven by Forever's native PLAYER_SWING event.
____exports.SwingTimer = __TS__Class()
local SwingTimer = ____exports.SwingTimer
SwingTimer.name = "SwingTimer"
__TS__ClassExtends(SwingTimer, ProgressSource)
function SwingTimer.prototype.____constructor(self, hand)
    if hand == nil then
        hand = ____exports.SwingHand.MainHand
    end
    ProgressSource.prototype.____constructor(
        self,
        {
            current = function() return self:Remaining() end,
            min = function() return 0 end,
            max = function() return self.duration end,
            percent = function() return self.duration > 0 and self:Remaining() / self.duration * 100 or 0 end
        }
    )
    self.hand = hand
    self.duration = 0
    self.endTime = 0
    self.known = false
    self.restricted = false
    self.bindings = __TS__New(Set)
    self:Start()
end
function SwingTimer.prototype.HasSecretFields(self)
    return self.restricted
end
function SwingTimer.prototype.Remaining(self)
    return self.known and math.max(
        0,
        self.endTime - GetTime()
    ) or 0
end
function SwingTimer.prototype.Start(self)
    if self.events ~= nil then
        return
    end
    if C_SwingTimer == nil or (Enum and Enum.PlayerSwingType) == nil then
        error("SwingTimer: this client does not expose the Forever swing API")
    end
    local swingType = Enum.PlayerSwingType[self.hand]
    if swingType == nil then
        error("SwingTimer: unsupported swing hand")
    end
    local events = CreateFrame("Frame", nil, UIParent)
    self.events = events
    events:RegisterEvent("PLAYER_SWING")
    events:RegisterEvent("PLAYER_ENTERING_WORLD")
    events:RegisterEvent("WEAPON_SLOT_CHANGED")
    events:SetScript(
        "OnEvent",
        function(_frame, event, ...)
            local payload = {...}
            if event ~= "PLAYER_SWING" then
                self:Reset()
                return
            end
            local duration, hand = __TS__Unpack(payload)
            if issecretvalue(hand) then
                self:Reset(true)
                return
            end
            if hand ~= swingType then
                return
            end
            if issecretvalue(duration) then
                self:Reset(true)
                return
            end
            if type(duration) ~= "number" or not __TS__NumberIsFinite(duration) or duration <= 0 then
                self:Reset()
                return
            end
            self.duration = duration
            self.endTime = GetTime() + duration
            self.known = true
            self.restricted = false
            self:Notify()
        end
    )
end
function SwingTimer.prototype.Reset(self, restricted)
    if restricted == nil then
        restricted = false
    end
    self.duration = 0
    self.endTime = 0
    self.known = false
    self.restricted = restricted
    self:Notify()
end
function SwingTimer.prototype.Notify(self)
    for ____, refresh in __TS__Iterator(self.bindings) do
        refresh(nil)
    end
end
function SwingTimer.prototype.BindTo(self, frame, options)
    if options == nil then
        options = {}
    end
    if options.min ~= nil or options.max ~= nil or options.current ~= nil then
        error("SwingTimer: native timer binding does not support min/max/current overrides")
    end
    local bar = frame
    local ____opt_2 = Enum and Enum.StatusBarInterpolation
    local interpolation = ____opt_2 and ____opt_2.Immediate
    local ____opt_6 = Enum and Enum.StatusBarTimerDirection
    local direction = ____opt_6 and ____opt_6.RemainingTime
    if bar.SetTimerDuration == nil or C_DurationUtil == nil or interpolation == nil or direction == nil then
        error("SwingTimer: native StatusBar timer support is unavailable")
    end
    self:Start()
    local timer = C_DurationUtil.CreateDuration()
    bar:SetMinMaxValues(0, 1)
    local function refresh()
        local active = self:CanEmit(self:Remaining())
        local ____this_11
        ____this_11 = options
        local ____opt_10 = ____this_11.onActiveChange
        if ____opt_10 ~= nil then
            ____opt_10(____this_11, active)
        end
        if not active then
            return
        end
        if self.HasTiming and self:Remaining() > 0 then
            timer:SetTimeFromStart(self.endTime - self.duration, self.duration)
            bar:SetTimerDuration(timer, interpolation, direction)
        else
            timer:SetTimeFromStart(
                GetTime() - 1,
                1
            )
            bar:SetTimerDuration(timer, interpolation, direction)
            bar:SetValue(0)
        end
    end
    self.bindings:add(refresh)
    refresh(nil)
    return function()
        self.bindings:delete(refresh)
    end
end
function SwingTimer.prototype.Listen(self)
end
function SwingTimer.prototype.Dispose(self)
    self:Reset()
    self.bindings:clear()
    local ____opt_12 = self.events
    if ____opt_12 ~= nil then
        ____opt_12:UnregisterAllEvents()
    end
    local ____opt_14 = self.events
    if ____opt_14 ~= nil then
        ____opt_14:SetScript("OnEvent", nil)
    end
    local ____opt_16 = self.events
    if ____opt_16 ~= nil then
        ____opt_16:Hide()
    end
    self.events = nil
end
__TS__SetDescriptor(
    SwingTimer.prototype,
    "HasTiming",
    {get = function(self)
        return self.known and not self.restricted
    end},
    true
)
__TS__SetDescriptor(
    SwingTimer.prototype,
    "IsActive",
    {get = function(self)
        return self.HasTiming and self:Remaining() > 0
    end},
    true
)
return ____exports

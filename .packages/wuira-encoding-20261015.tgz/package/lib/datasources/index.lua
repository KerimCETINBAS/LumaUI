--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
do
    local ____DataSource = require("datasources.DataSource")
    ____exports.DataSource = ____DataSource.DataSource
end
do
    local ____ProgressSource = require("datasources.ProgressSource")
    ____exports.ProgressSource = ____ProgressSource.ProgressSource
end
do
    local ____Resources = require("datasources.Resources")
    ____exports.HP = ____Resources.HP
    ____exports.Mana = ____Resources.Mana
    ____exports.Unit = ____Resources.Unit
    ____exports.DataSources = ____Resources.DataSources
    ____exports.HealthPrediction = ____Resources.HealthPrediction
end
do
    local ____Auras = require("datasources.Auras")
    ____exports.Aura = ____Auras.Aura
    ____exports.AuraSource = ____Auras.AuraSource
    ____exports.Buffs = ____Auras.Buffs
    ____exports.Debuffs = ____Auras.Debuffs
end
do
    local ____GroupMembers = require("datasources.GroupMembers")
    ____exports.GroupMembers = ____GroupMembers.GroupMembers
    ____exports.PartyMembers = ____GroupMembers.PartyMembers
    ____exports.RaidMembers = ____GroupMembers.RaidMembers
end
do
    local ____UnitInfo = require("datasources.UnitInfo")
    ____exports.ClassSource = ____UnitInfo.ClassSource
    ____exports.SpecSource = ____UnitInfo.SpecSource
    ____exports.Specializations = ____UnitInfo.Specializations
end
do
    local ____UnitSource = require("datasources.UnitSource")
    ____exports.UnitSource = ____UnitSource.UnitSource
end
do
    local ____SwingTimer = require("datasources.SwingTimer")
    ____exports.SwingTimer = ____SwingTimer.SwingTimer
    ____exports.SwingHand = ____SwingTimer.SwingHand
end
do
    local ____TimerSource = require("datasources.TimerSource")
    ____exports.TimerSource = ____TimerSource.TimerSource
end
do
    local ____TotemTimer = require("datasources.TotemTimer")
    ____exports.TotemTimer = ____TotemTimer.TotemTimer
end
do
    local ____TextureSource = require("datasources.TextureSource")
    ____exports.TextureSource = ____TextureSource.TextureSource
end
do
    local ____CastTimer = require("datasources.CastTimer")
    ____exports.CastTimer = ____CastTimer.CastTimer
end
do
    local ____AuraTimer = require("datasources.AuraTimer")
    ____exports.AuraTimer = ____AuraTimer.AuraTimer
end
do
    local ____SpellCooldown = require("datasources.SpellCooldown")
    ____exports.SpellCooldown = ____SpellCooldown.SpellCooldown
    ____exports.GlobalCooldown = ____SpellCooldown.GlobalCooldown
end
do
    local ____SpellSource = require("datasources.SpellSource")
    ____exports.SpellSource = ____SpellSource.SpellSource
end
do
    local ____KnownSpells = require("datasources.KnownSpells")
    ____exports.KnownSpells = ____KnownSpells.KnownSpells
end
do
    local ____ManaRegenTimer = require("datasources.ManaRegenTimer")
    ____exports.ManaRegenTimer = ____ManaRegenTimer.ManaRegenTimer
end
return ____exports

import { TimerSource } from "./TimerSource";
/** Native cooldown duration, including opaque timings during combat. */
export declare class SpellCooldown extends TimerSource {
    readonly spellId: number | string;
    constructor(spellId: number | string, options?: {
        ignoreGCD?: boolean;
    });
    get IsAvailable(): boolean;
}
export declare class GlobalCooldown extends SpellCooldown {
    constructor();
}

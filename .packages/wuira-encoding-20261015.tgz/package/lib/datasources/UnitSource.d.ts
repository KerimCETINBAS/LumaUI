import { DataSource } from "./DataSource";
export declare const Unit: {
    readonly Player: "player";
    readonly Target: "target";
    readonly Focus: "focus";
};
export interface UnitIdentity {
    readonly token: string;
    readonly guid: string;
}
export declare class UnitPredicates {
    private readonly token;
    constructor(token: string);
    get PC(): boolean | undefined;
    get Self(): boolean | undefined;
}
/** Shared live unit reference; identity is read again rather than cached by token. */
export declare class UnitSource extends DataSource<UnitIdentity | undefined> {
    readonly Token: string;
    readonly Is: UnitPredicates;
    private restricted;
    constructor(Token: string);
    protected HasSecretFields(): boolean;
    protected GetValue(): UnitIdentity | undefined;
}
export type UnitInput = string | UnitSource;
/** Reuse explicit unit references; string inputs remain a convenience shorthand. */
export declare function resolveUnit(unit: UnitInput): UnitSource;

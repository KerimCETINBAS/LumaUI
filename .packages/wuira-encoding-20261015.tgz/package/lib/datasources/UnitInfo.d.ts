import { DataSource } from "./DataSource";
import { UnitSource } from "./UnitSource";
import type { UnitInput } from "./UnitSource";
export interface ClassInfo {
    readonly id: number;
    readonly token: string;
    readonly name: string;
}
export declare class ClassSource extends DataSource<ClassInfo | undefined> {
    private restricted;
    readonly target: UnitSource;
    constructor(unit: UnitInput);
    get unit(): string;
    protected HasSecretFields(): boolean;
    protected GetValue(): ClassInfo | undefined;
}
export interface SpecializationInfo {
    readonly id: number;
    readonly name?: string;
    readonly icon?: number;
    readonly role?: string;
    /** Native value when provided by the client; never estimated. */
    readonly pointsSpent?: number;
}
export type InspectStatus = "idle" | "pending" | "ready" | "unsupported";
/** Own data is read live; other units require an explicit inspect request. */
export declare class SpecSource extends DataSource<readonly SpecializationInfo[] | undefined> {
    private restricted;
    private snapshot?;
    private snapshotGUID?;
    private listener?;
    private status;
    readonly target: UnitSource;
    constructor(unit: UnitInput);
    get unit(): string;
    get Status(): InspectStatus;
    protected HasSecretFields(): boolean;
    protected GetValue(): readonly SpecializationInfo[] | undefined;
    private Read;
    /** Returns false if an inspect cannot start. No request is made from a getter. */
    RequestInspect(): boolean;
    private StopListening;
    Dispose(): void;
}
export { SpecSource as Specializations };

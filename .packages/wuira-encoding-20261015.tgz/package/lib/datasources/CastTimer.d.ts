import { TimerSource } from "./TimerSource";
import { UnitSource } from "./UnitSource";
import type { UnitInput } from "./UnitSource";
/** Remaining cast/channel time using the native duration object. */
export declare class CastTimer extends TimerSource {
    readonly target: UnitSource;
    get SpellName(): string;
    constructor(unit?: UnitInput);
}

--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end

local function __TS__ClassExtends(target, base)
    target.____super = base
    local staticMetatable = setmetatable({__index = base}, base)
    setmetatable(target, staticMetatable)
    local baseMetatable = getmetatable(base)
    if baseMetatable then
        if type(baseMetatable.__index) == "function" then
            staticMetatable.__index = baseMetatable.__index
        end
        if type(baseMetatable.__newindex) == "function" then
            staticMetatable.__newindex = baseMetatable.__newindex
        end
    end
    setmetatable(target.prototype, base.prototype)
    if type(base.prototype.__index) == "function" then
        target.prototype.__index = base.prototype.__index
    end
    if type(base.prototype.__newindex) == "function" then
        target.prototype.__newindex = base.prototype.__newindex
    end
    if type(base.prototype.__tostring) == "function" then
        target.prototype.__tostring = base.prototype.__tostring
    end
end

local __TS__Symbol, Symbol
do
    local symbolMetatable = {__tostring = function(self)
        return ("Symbol(" .. (self.description or "")) .. ")"
    end}
    function __TS__Symbol(description)
        return setmetatable({description = description}, symbolMetatable)
    end
    Symbol = {
        asyncDispose = __TS__Symbol("Symbol.asyncDispose"),
        dispose = __TS__Symbol("Symbol.dispose"),
        iterator = __TS__Symbol("Symbol.iterator"),
        hasInstance = __TS__Symbol("Symbol.hasInstance"),
        species = __TS__Symbol("Symbol.species"),
        toStringTag = __TS__Symbol("Symbol.toStringTag")
    }
end

local __TS__Iterator
do
    local function iteratorGeneratorStep(self)
        local co = self.____coroutine
        local status, value = coroutine.resume(co)
        if not status then
            error(value, 0)
        end
        if coroutine.status(co) == "dead" then
            return
        end
        return true, value
    end
    local function iteratorIteratorStep(self)
        local result = self:next()
        if result.done then
            return
        end
        return true, result.value
    end
    local function iteratorStringStep(self, index)
        index = index + 1
        if index > #self then
            return
        end
        return index, string.sub(self, index, index)
    end
    function __TS__Iterator(iterable)
        if type(iterable) == "string" then
            return iteratorStringStep, iterable, 0
        elseif iterable.____coroutine ~= nil then
            return iteratorGeneratorStep, iterable
        elseif iterable[Symbol.iterator] then
            local iterator = iterable[Symbol.iterator](iterable)
            return iteratorIteratorStep, iterator
        else
            return ipairs(iterable)
        end
    end
end

local function __TS__New(target, ...)
    local instance = setmetatable({}, target.prototype)
    instance:____constructor(...)
    return instance
end

local Set
do
    Set = __TS__Class()
    Set.name = "Set"
    function Set.prototype.____constructor(self, values)
        self[Symbol.toStringTag] = "Set"
        self.size = 0
        self.nextKey = {}
        self.previousKey = {}
        if values == nil then
            return
        end
        local iterable = values
        if iterable[Symbol.iterator] then
            local iterator = iterable[Symbol.iterator](iterable)
            while true do
                local result = iterator:next()
                if result.done then
                    break
                end
                self:add(result.value)
            end
        else
            local array = values
            for ____, value in ipairs(array) do
                self:add(value)
            end
        end
    end
    function Set.prototype.add(self, value)
        local isNewValue = not self:has(value)
        if isNewValue then
            self.size = self.size + 1
        end
        if self.firstKey == nil then
            self.firstKey = value
            self.lastKey = value
        elseif isNewValue then
            self.nextKey[self.lastKey] = value
            self.previousKey[value] = self.lastKey
            self.lastKey = value
        end
        return self
    end
    function Set.prototype.clear(self)
        self.nextKey = {}
        self.previousKey = {}
        self.firstKey = nil
        self.lastKey = nil
        self.size = 0
    end
    function Set.prototype.delete(self, value)
        local contains = self:has(value)
        if contains then
            self.size = self.size - 1
            local next = self.nextKey[value]
            local previous = self.previousKey[value]
            if next ~= nil and previous ~= nil then
                self.nextKey[previous] = next
                self.previousKey[next] = previous
            elseif next ~= nil then
                self.firstKey = next
                self.previousKey[next] = nil
            elseif previous ~= nil then
                self.lastKey = previous
                self.nextKey[previous] = nil
            else
                self.firstKey = nil
                self.lastKey = nil
            end
            self.nextKey[value] = nil
            self.previousKey[value] = nil
        end
        return contains
    end
    function Set.prototype.forEach(self, callback)
        for ____, key in __TS__Iterator(self:keys()) do
            callback(nil, key, key, self)
        end
    end
    function Set.prototype.has(self, value)
        return self.nextKey[value] ~= nil or self.lastKey == value
    end
    Set.prototype[Symbol.iterator] = function(self)
        return self:values()
    end
    function Set.prototype.entries(self)
        local function getFirstKey()
            return self.firstKey
        end
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = {key, key}}
            end
        }
    end
    function Set.prototype.keys(self)
        local function getFirstKey()
            return self.firstKey
        end
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = key}
            end
        }
    end
    function Set.prototype.values(self)
        local function getFirstKey()
            return self.firstKey
        end
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = key}
            end
        }
    end
    function Set.prototype.union(self, other)
        local result = __TS__New(Set, self)
        for ____, item in __TS__Iterator(other) do
            result:add(item)
        end
        return result
    end
    function Set.prototype.intersection(self, other)
        local result = __TS__New(Set)
        for ____, item in __TS__Iterator(self) do
            if other:has(item) then
                result:add(item)
            end
        end
        return result
    end
    function Set.prototype.difference(self, other)
        local result = __TS__New(Set, self)
        for ____, item in __TS__Iterator(other) do
            result:delete(item)
        end
        return result
    end
    function Set.prototype.symmetricDifference(self, other)
        local result = __TS__New(Set, self)
        for ____, item in __TS__Iterator(other) do
            if self:has(item) then
                result:delete(item)
            else
                result:add(item)
            end
        end
        return result
    end
    function Set.prototype.isSubsetOf(self, other)
        for ____, item in __TS__Iterator(self) do
            if not other:has(item) then
                return false
            end
        end
        return true
    end
    function Set.prototype.isSupersetOf(self, other)
        for ____, item in __TS__Iterator(other) do
            if not self:has(item) then
                return false
            end
        end
        return true
    end
    function Set.prototype.isDisjointFrom(self, other)
        for ____, item in __TS__Iterator(self) do
            if other:has(item) then
                return false
            end
        end
        return true
    end
    Set[Symbol.species] = Set
end

local function __TS__StringIncludes(self, searchString, position)
    if not position then
        position = 1
    else
        position = position + 1
    end
    local index = string.find(self, searchString, position, true)
    return index ~= nil
end

local function __TS__ObjectAssign(target, ...)
    local sources = {...}
    for i = 1, #sources do
        local source = sources[i]
        if type(source) == "table" then
            for key in pairs(source) do
                target[key] = source[key]
            end
        end
    end
    return target
end

local function __TS__ArrayFilter(self, callbackfn, thisArg)
    local result = {}
    local len = 0
    for i = 1, #self do
        if callbackfn(thisArg, self[i], i - 1, self) then
            len = len + 1
            result[len] = self[i]
        end
    end
    return result
end

local function __TS__ArrayMap(self, callbackfn, thisArg)
    local result = {}
    for i = 1, #self do
        result[i] = callbackfn(thisArg, self[i], i - 1, self)
    end
    return result
end

local function __TS__ArraySlice(self, first, last)
    local len = #self
    first = first or 0
    if first < 0 then
        first = len + first
        if first < 0 then
            first = 0
        end
    else
        if first > len then
            first = len
        end
    end
    last = last or len
    if last < 0 then
        last = len + last
        if last < 0 then
            last = 0
        end
    else
        if last > len then
            last = len
        end
    end
    local out = {}
    first = first + 1
    last = last + 1
    local n = 1
    while first < last do
        out[n] = self[first]
        first = first + 1
        n = n + 1
    end
    return out
end

local function __TS__ArrayFind(self, predicate, thisArg)
    for i = 1, #self do
        local elem = self[i]
        if predicate(thisArg, elem, i - 1, self) then
            return elem
        end
    end
    return nil
end

local Map
do
    Map = __TS__Class()
    Map.name = "Map"
    function Map.prototype.____constructor(self, entries)
        self[Symbol.toStringTag] = "Map"
        self.items = {}
        self.size = 0
        self.nextKey = {}
        self.previousKey = {}
        if entries == nil then
            return
        end
        local iterable = entries
        if iterable[Symbol.iterator] then
            local iterator = iterable[Symbol.iterator](iterable)
            while true do
                local result = iterator:next()
                if result.done then
                    break
                end
                local value = result.value
                self:set(value[1], value[2])
            end
        else
            local array = entries
            for ____, kvp in ipairs(array) do
                self:set(kvp[1], kvp[2])
            end
        end
    end
    function Map.prototype.clear(self)
        self.items = {}
        self.nextKey = {}
        self.previousKey = {}
        self.firstKey = nil
        self.lastKey = nil
        self.size = 0
    end
    function Map.prototype.delete(self, key)
        local contains = self:has(key)
        if contains then
            self.size = self.size - 1
            local next = self.nextKey[key]
            local previous = self.previousKey[key]
            if next ~= nil and previous ~= nil then
                self.nextKey[previous] = next
                self.previousKey[next] = previous
            elseif next ~= nil then
                self.firstKey = next
                self.previousKey[next] = nil
            elseif previous ~= nil then
                self.lastKey = previous
                self.nextKey[previous] = nil
            else
                self.firstKey = nil
                self.lastKey = nil
            end
            self.nextKey[key] = nil
            self.previousKey[key] = nil
        end
        self.items[key] = nil
        return contains
    end
    function Map.prototype.forEach(self, callback)
        for ____, key in __TS__Iterator(self:keys()) do
            callback(nil, self.items[key], key, self)
        end
    end
    function Map.prototype.get(self, key)
        return self.items[key]
    end
    function Map.prototype.has(self, key)
        return self.nextKey[key] ~= nil or self.lastKey == key
    end
    function Map.prototype.set(self, key, value)
        local isNewValue = not self:has(key)
        if isNewValue then
            self.size = self.size + 1
        end
        self.items[key] = value
        if self.firstKey == nil then
            self.firstKey = key
            self.lastKey = key
        elseif isNewValue then
            self.nextKey[self.lastKey] = key
            self.previousKey[key] = self.lastKey
            self.lastKey = key
        end
        return self
    end
    Map.prototype[Symbol.iterator] = function(self)
        return self:entries()
    end
    function Map.prototype.entries(self)
        local function getFirstKey()
            return self.firstKey
        end
        local items = self.items
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = {key, items[key]}}
            end
        }
    end
    function Map.prototype.keys(self)
        local function getFirstKey()
            return self.firstKey
        end
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = key}
            end
        }
    end
    function Map.prototype.values(self)
        local function getFirstKey()
            return self.firstKey
        end
        local items = self.items
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = items[key]}
            end
        }
    end
    Map[Symbol.species] = Map
end

local __TS__ArrayFrom
do
    local function arrayLikeStep(self, index)
        index = index + 1
        if index > self.length then
            return
        end
        return index, self[index]
    end
    local function arrayLikeIterator(arr)
        if type(arr.length) == "number" then
            return arrayLikeStep, arr, 0
        end
        return __TS__Iterator(arr)
    end
    function __TS__ArrayFrom(arrayLike, mapFn, thisArg)
        local result = {}
        if mapFn == nil then
            for ____, v in arrayLikeIterator(arrayLike) do
                result[#result + 1] = v
            end
        else
            local i = 0
            for ____, v in arrayLikeIterator(arrayLike) do
                local ____mapFn_3 = mapFn
                local ____thisArg_1 = thisArg
                local ____v_2 = v
                local ____i_0 = i
                i = ____i_0 + 1
                result[#result + 1] = ____mapFn_3(____thisArg_1, ____v_2, ____i_0)
            end
        end
        return result
    end
end

local function __TS__ArraySort(self, compareFn)
    if compareFn ~= nil then
        table.sort(
            self,
            function(a, b) return compareFn(nil, a, b) < 0 end
        )
    else
        table.sort(self)
    end
    return self
end

local function __TS__CloneDescriptor(____bindingPattern0)
    local value
    local writable
    local set
    local get
    local configurable
    local enumerable
    enumerable = ____bindingPattern0.enumerable
    configurable = ____bindingPattern0.configurable
    get = ____bindingPattern0.get
    set = ____bindingPattern0.set
    writable = ____bindingPattern0.writable
    value = ____bindingPattern0.value
    local descriptor = {enumerable = enumerable == true, configurable = configurable == true}
    local hasGetterOrSetter = get ~= nil or set ~= nil
    local hasValueOrWritableAttribute = writable ~= nil or value ~= nil
    if hasGetterOrSetter and hasValueOrWritableAttribute then
        error("Invalid property descriptor. Cannot both specify accessors and a value or writable attribute.", 0)
    end
    if get or set then
        descriptor.get = get
        descriptor.set = set
    else
        descriptor.value = value
        descriptor.writable = writable == true
    end
    return descriptor
end

local __TS__DescriptorGet
do
    local getmetatable = _G.getmetatable
    local ____rawget = _G.rawget
    function __TS__DescriptorGet(self, metatable, key)
        while metatable do
            local rawResult = ____rawget(metatable, key)
            if rawResult ~= nil then
                return rawResult
            end
            local descriptors = ____rawget(metatable, "_descriptors")
            if descriptors then
                local descriptor = descriptors[key]
                if descriptor ~= nil then
                    if descriptor.get then
                        return descriptor.get(self)
                    end
                    return descriptor.value
                end
            end
            metatable = getmetatable(metatable)
        end
    end
end

local __TS__DescriptorSet
do
    local getmetatable = _G.getmetatable
    local ____rawget = _G.rawget
    local rawset = _G.rawset
    function __TS__DescriptorSet(self, metatable, key, value)
        while metatable do
            local descriptors = ____rawget(metatable, "_descriptors")
            if descriptors then
                local descriptor = descriptors[key]
                if descriptor ~= nil then
                    if descriptor.set then
                        descriptor.set(self, value)
                    else
                        if descriptor.writable == false then
                            error(
                                ((("Cannot assign to read only property '" .. key) .. "' of object '") .. tostring(self)) .. "'",
                                0
                            )
                        end
                        descriptor.value = value
                    end
                    return
                end
            end
            metatable = getmetatable(metatable)
        end
        rawset(self, key, value)
    end
end

local __TS__SetDescriptor
do
    local getmetatable = _G.getmetatable
    local function descriptorIndex(self, key)
        return __TS__DescriptorGet(
            self,
            getmetatable(self),
            key
        )
    end
    local function descriptorNewIndex(self, key, value)
        return __TS__DescriptorSet(
            self,
            getmetatable(self),
            key,
            value
        )
    end
    function __TS__SetDescriptor(target, key, desc, isPrototype)
        if isPrototype == nil then
            isPrototype = false
        end
        local ____isPrototype_0
        if isPrototype then
            ____isPrototype_0 = target
        else
            ____isPrototype_0 = getmetatable(target)
        end
        local metatable = ____isPrototype_0
        if not metatable then
            metatable = {}
            setmetatable(target, metatable)
        end
        if not isPrototype and not rawget(metatable, "_isOwnDescriptorMetatable") then
            local instanceMetatable = {}
            instanceMetatable._isOwnDescriptorMetatable = true
            setmetatable(instanceMetatable, metatable)
            setmetatable(target, instanceMetatable)
            metatable = instanceMetatable
        end
        local value = rawget(target, key)
        if value ~= nil then
            rawset(target, key, nil)
        end
        if not rawget(metatable, "_descriptors") then
            metatable._descriptors = {}
        end
        metatable._descriptors[key] = __TS__CloneDescriptor(desc)
        metatable.__index = descriptorIndex
        metatable.__newindex = descriptorNewIndex
    end
end
-- End of Lua Library inline imports
local ____exports = {}
local ____DataSource = require("datasources.DataSource")
local DataSource = ____DataSource.DataSource
--- Cached learned player spellbook IDs. Native events refresh the snapshot; no polling.
____exports.KnownSpells = __TS__Class()
local KnownSpells = ____exports.KnownSpells
KnownSpells.name = "KnownSpells"
__TS__ClassExtends(KnownSpells, DataSource)
function KnownSpells.prototype.____constructor(self)
    DataSource.prototype.____constructor(self, {})
    self.ids = {}
    self.entries = {}
    self.status = "unavailable"
    self.listeners = __TS__New(Set)
    self.disposed = false
    self.frame = CreateFrame("Frame", nil, UIParent)
    for ____, event in ipairs({
        "PLAYER_ENTERING_WORLD",
        "PLAYER_LEVEL_UP",
        "SPELLS_CHANGED",
        "LEARNED_SPELL_IN_SKILL_LINE",
        "PLAYER_TALENT_UPDATE",
        "CHARACTER_POINTS_CHANGED"
    }) do
        do
            pcall(function()
                self.frame:RegisterEvent(event)
            end)
        end
    end
    self.frame:SetScript(
        "OnEvent",
        function() return self:Refresh() end
    )
    self:Refresh()
end
function KnownSpells.prototype.Filter(self, pattern)
    if issecretvalue(pattern) or type(pattern) ~= "string" then
        error("KnownSpells.Filter requires a public name pattern")
    end
    local glob = "^"
    for ____, character in __TS__Iterator(string.lower(pattern)) do
        if character == "*" then
            glob = glob .. ".*"
        elseif character == "?" then
            glob = glob .. "."
        else
            glob = glob .. (__TS__StringIncludes("^$()%.[]+-", character) and "%" or "") .. character
        end
    end
    glob = glob .. "$"
    return __TS__ArrayMap(
        __TS__ArrayFilter(
            self.entries,
            function(____, entry) return entry.name ~= nil and string.match(
                string.lower(entry.name),
                glob
            ) ~= nil end
        ),
        function(____, entry) return __TS__ObjectAssign({}, entry) end
    )
end
function KnownSpells.prototype.GetValue(self)
    return __TS__ArraySlice(self.ids)
end
function KnownSpells.prototype.HasSecretFields(self)
    return self.status == "restricted"
end
function KnownSpells.prototype.Has(self, spell)
    return self:Find(spell) ~= nil
end
function KnownSpells.prototype.Find(self, spell)
    if self.status ~= "ready" or issecretvalue(spell) then
        return nil
    end
    local exact = __TS__ArrayFind(
        self.entries,
        function(____, entry) return entry.id == spell end
    )
    if exact ~= nil then
        return __TS__ObjectAssign({}, exact)
    end
    local ____temp_4
    if type(spell) == "string" then
        ____temp_4 = spell
    else
        local ____opt_0 = C_Spell and C_Spell.GetSpellName
        ____temp_4 = ____opt_0 and ____opt_0(spell)
    end
    local name = ____temp_4
    if issecretvalue(name) or name == nil then
        return nil
    end
    local entry = __TS__ArrayFind(
        self.entries,
        function(____, entry) return entry.name == name end
    )
    local ____temp_5
    if entry == nil then
        ____temp_5 = nil
    else
        ____temp_5 = __TS__ObjectAssign({}, entry)
    end
    return ____temp_5
end
function KnownSpells.prototype.onChange(self, listener)
    if self.disposed then
        error("KnownSpells: source is disposed")
    end
    self.listeners:add(listener)
    return function()
        self.listeners:delete(listener)
    end
end
function KnownSpells.prototype.Refresh(self)
    local function signature()
        return (self.status .. ":") .. table.concat(
            __TS__ArrayMap(
                self.entries,
                function(____, entry) return (((tostring(entry.id) .. ":") .. (entry.name or "")) .. ":") .. tostring(entry.isPassive) end
            ),
            "|"
        )
    end
    local previous = signature(nil)
    local ids = __TS__New(Set)
    local entries = __TS__New(Map)
    self.status = "ready"
    local function add(____, id, name, passive)
        if issecretvalue(id) or issecretvalue(name) then
            self.status = "restricted"
            return
        end
        if id == nil or id <= 0 then
            return
        end
        ids:add(id)
        local ____name_10 = name
        if ____name_10 == nil then
            local ____opt_6 = C_Spell and C_Spell.GetSpellName
            ____name_10 = ____opt_6 and ____opt_6(id)
        end
        local resolved = ____name_10
        if issecretvalue(resolved) then
            self.status = "restricted"
            return
        end
        local ____passive_15 = passive
        if ____passive_15 == nil then
            local ____opt_11 = C_Spell and C_Spell.IsSpellPassive
            ____passive_15 = ____opt_11 and ____opt_11(id)
        end
        local isPassive = ____passive_15
        if issecretvalue(isPassive) then
            self.status = "restricted"
            return
        end
        entries:set(id, {id = id, name = resolved, isPassive = isPassive})
    end
    local book = C_SpellBook
    local ____opt_16 = Enum and Enum.SpellBookSpellBank
    local bank = ____opt_16 and ____opt_16.Player
    local ____opt_20 = Enum and Enum.SpellBookItemType
    local spellType = ____opt_20 and ____opt_20.Spell
    if (book and book.GetNumSpellBookSkillLines) ~= nil and book.GetSpellBookSkillLineInfo ~= nil and book.GetSpellBookItemInfo ~= nil and bank ~= nil and spellType ~= nil then
        local count = book.GetNumSpellBookSkillLines()
        if issecretvalue(count) then
            self.status = "restricted"
        else
            do
                local line = 1
                while line <= count do
                    do
                        local __continue40
                        repeat
                            local info = book.GetSpellBookSkillLineInfo(line)
                            if issecretvalue(info) then
                                self.status = "restricted"
                                break
                            end
                            if info == nil then
                                __continue40 = true
                                break
                            end
                            if issecretvalue(info.itemIndexOffset) or issecretvalue(info.numSpellBookItems) then
                                self.status = "restricted"
                                break
                            end
                            do
                                local slot = info.itemIndexOffset + 1
                                while slot <= info.itemIndexOffset + info.numSpellBookItems do
                                    do
                                        local __continue45
                                        repeat
                                            local item = book.GetSpellBookItemInfo(slot, bank)
                                            if issecretvalue(item) then
                                                self.status = "restricted"
                                                break
                                            end
                                            if item == nil then
                                                __continue45 = true
                                                break
                                            end
                                            if issecretvalue(item.itemType) or issecretvalue(item.isOffSpec) then
                                                self.status = "restricted"
                                                break
                                            end
                                            if item.itemType == spellType and not item.isOffSpec then
                                                add(nil, item.spellID, item.name, item.isPassive)
                                            end
                                            __continue45 = true
                                        until true
                                        if not __continue45 then
                                            break
                                        end
                                    end
                                    slot = slot + 1
                                end
                            end
                            __continue40 = true
                        until true
                        if not __continue40 then
                            break
                        end
                    end
                    line = line + 1
                end
            end
        end
    elseif GetNumSpellTabs ~= nil and GetSpellTabInfo ~= nil and GetSpellBookItemInfo ~= nil then
        local count = GetNumSpellTabs()
        if issecretvalue(count) then
            self.status = "restricted"
        else
            do
                local tab = 1
                while tab <= count do
                    local ____, ____, offset, size = GetSpellTabInfo(tab)
                    if issecretvalue(offset) or issecretvalue(size) then
                        self.status = "restricted"
                        break
                    end
                    do
                        local slot = offset + 1
                        while slot <= offset + size do
                            local kind, id = GetSpellBookItemInfo(slot, "spell")
                            if issecretvalue(kind) then
                                self.status = "restricted"
                                break
                            end
                            if kind == "SPELL" then
                                add(
                                    nil,
                                    id,
                                    nil,
                                    IsPassiveSpell and IsPassiveSpell(slot, "spell")
                                )
                            end
                            slot = slot + 1
                        end
                    end
                    tab = tab + 1
                end
            end
        end
    else
        self.status = "unavailable"
    end
    self.ids = self.status == "ready" and __TS__ArraySort(
        __TS__ArrayFrom(ids),
        function(____, a, b) return a - b end
    ) or ({})
    self.entries = __TS__ArrayMap(
        self.ids,
        function(____, id) return entries:get(id) end
    )
    local next = signature(nil)
    if next ~= previous and self.status == "ready" and self:CanEmit(self.ids) then
        for ____, listener in __TS__Iterator(self.listeners) do
            listener(
                nil,
                __TS__ArraySlice(self.ids)
            )
        end
    end
end
function KnownSpells.prototype.Dispose(self)
    if self.disposed then
        return
    end
    self.disposed = true
    self.frame:UnregisterAllEvents()
    self.frame:SetScript("OnEvent", nil)
    self.frame:Hide()
    self.listeners:clear()
end
__TS__SetDescriptor(
    KnownSpells.prototype,
    "Status",
    {get = function(self)
        return self.status
    end},
    true
)
__TS__SetDescriptor(
    KnownSpells.prototype,
    "Entries",
    {get = function(self)
        return __TS__ArrayMap(
            self.entries,
            function(____, entry) return __TS__ObjectAssign({}, entry) end
        )
    end},
    true
)
return ____exports

--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end

local function __TS__ClassExtends(target, base)
    target.____super = base
    local staticMetatable = setmetatable({__index = base}, base)
    setmetatable(target, staticMetatable)
    local baseMetatable = getmetatable(base)
    if baseMetatable then
        if type(baseMetatable.__index) == "function" then
            staticMetatable.__index = baseMetatable.__index
        end
        if type(baseMetatable.__newindex) == "function" then
            staticMetatable.__newindex = baseMetatable.__newindex
        end
    end
    setmetatable(target.prototype, base.prototype)
    if type(base.prototype.__index) == "function" then
        target.prototype.__index = base.prototype.__index
    end
    if type(base.prototype.__newindex) == "function" then
        target.prototype.__newindex = base.prototype.__newindex
    end
    if type(base.prototype.__tostring) == "function" then
        target.prototype.__tostring = base.prototype.__tostring
    end
end

local __TS__Symbol, Symbol
do
    local symbolMetatable = {__tostring = function(self)
        return ("Symbol(" .. (self.description or "")) .. ")"
    end}
    function __TS__Symbol(description)
        return setmetatable({description = description}, symbolMetatable)
    end
    Symbol = {
        asyncDispose = __TS__Symbol("Symbol.asyncDispose"),
        dispose = __TS__Symbol("Symbol.dispose"),
        iterator = __TS__Symbol("Symbol.iterator"),
        hasInstance = __TS__Symbol("Symbol.hasInstance"),
        species = __TS__Symbol("Symbol.species"),
        toStringTag = __TS__Symbol("Symbol.toStringTag")
    }
end

local __TS__Iterator
do
    local function iteratorGeneratorStep(self)
        local co = self.____coroutine
        local status, value = coroutine.resume(co)
        if not status then
            error(value, 0)
        end
        if coroutine.status(co) == "dead" then
            return
        end
        return true, value
    end
    local function iteratorIteratorStep(self)
        local result = self:next()
        if result.done then
            return
        end
        return true, result.value
    end
    local function iteratorStringStep(self, index)
        index = index + 1
        if index > #self then
            return
        end
        return index, string.sub(self, index, index)
    end
    function __TS__Iterator(iterable)
        if type(iterable) == "string" then
            return iteratorStringStep, iterable, 0
        elseif iterable.____coroutine ~= nil then
            return iteratorGeneratorStep, iterable
        elseif iterable[Symbol.iterator] then
            local iterator = iterable[Symbol.iterator](iterable)
            return iteratorIteratorStep, iterator
        else
            return ipairs(iterable)
        end
    end
end

local function __TS__New(target, ...)
    local instance = setmetatable({}, target.prototype)
    instance:____constructor(...)
    return instance
end

local Set
do
    Set = __TS__Class()
    Set.name = "Set"
    function Set.prototype.____constructor(self, values)
        self[Symbol.toStringTag] = "Set"
        self.size = 0
        self.nextKey = {}
        self.previousKey = {}
        if values == nil then
            return
        end
        local iterable = values
        if iterable[Symbol.iterator] then
            local iterator = iterable[Symbol.iterator](iterable)
            while true do
                local result = iterator:next()
                if result.done then
                    break
                end
                self:add(result.value)
            end
        else
            local array = values
            for ____, value in ipairs(array) do
                self:add(value)
            end
        end
    end
    function Set.prototype.add(self, value)
        local isNewValue = not self:has(value)
        if isNewValue then
            self.size = self.size + 1
        end
        if self.firstKey == nil then
            self.firstKey = value
            self.lastKey = value
        elseif isNewValue then
            self.nextKey[self.lastKey] = value
            self.previousKey[value] = self.lastKey
            self.lastKey = value
        end
        return self
    end
    function Set.prototype.clear(self)
        self.nextKey = {}
        self.previousKey = {}
        self.firstKey = nil
        self.lastKey = nil
        self.size = 0
    end
    function Set.prototype.delete(self, value)
        local contains = self:has(value)
        if contains then
            self.size = self.size - 1
            local next = self.nextKey[value]
            local previous = self.previousKey[value]
            if next ~= nil and previous ~= nil then
                self.nextKey[previous] = next
                self.previousKey[next] = previous
            elseif next ~= nil then
                self.firstKey = next
                self.previousKey[next] = nil
            elseif previous ~= nil then
                self.lastKey = previous
                self.nextKey[previous] = nil
            else
                self.firstKey = nil
                self.lastKey = nil
            end
            self.nextKey[value] = nil
            self.previousKey[value] = nil
        end
        return contains
    end
    function Set.prototype.forEach(self, callback)
        for ____, key in __TS__Iterator(self:keys()) do
            callback(nil, key, key, self)
        end
    end
    function Set.prototype.has(self, value)
        return self.nextKey[value] ~= nil or self.lastKey == value
    end
    Set.prototype[Symbol.iterator] = function(self)
        return self:values()
    end
    function Set.prototype.entries(self)
        local function getFirstKey()
            return self.firstKey
        end
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = {key, key}}
            end
        }
    end
    function Set.prototype.keys(self)
        local function getFirstKey()
            return self.firstKey
        end
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = key}
            end
        }
    end
    function Set.prototype.values(self)
        local function getFirstKey()
            return self.firstKey
        end
        local nextKey = self.nextKey
        local key
        local started = false
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                if not started then
                    started = true
                    key = getFirstKey(nil)
                else
                    key = nextKey[key]
                end
                return {done = not key, value = key}
            end
        }
    end
    function Set.prototype.union(self, other)
        local result = __TS__New(Set, self)
        for ____, item in __TS__Iterator(other) do
            result:add(item)
        end
        return result
    end
    function Set.prototype.intersection(self, other)
        local result = __TS__New(Set)
        for ____, item in __TS__Iterator(self) do
            if other:has(item) then
                result:add(item)
            end
        end
        return result
    end
    function Set.prototype.difference(self, other)
        local result = __TS__New(Set, self)
        for ____, item in __TS__Iterator(other) do
            result:delete(item)
        end
        return result
    end
    function Set.prototype.symmetricDifference(self, other)
        local result = __TS__New(Set, self)
        for ____, item in __TS__Iterator(other) do
            if self:has(item) then
                result:delete(item)
            else
                result:add(item)
            end
        end
        return result
    end
    function Set.prototype.isSubsetOf(self, other)
        for ____, item in __TS__Iterator(self) do
            if not other:has(item) then
                return false
            end
        end
        return true
    end
    function Set.prototype.isSupersetOf(self, other)
        for ____, item in __TS__Iterator(other) do
            if not self:has(item) then
                return false
            end
        end
        return true
    end
    function Set.prototype.isDisjointFrom(self, other)
        for ____, item in __TS__Iterator(self) do
            if other:has(item) then
                return false
            end
        end
        return true
    end
    Set[Symbol.species] = Set
end

local function __TS__CloneDescriptor(____bindingPattern0)
    local value
    local writable
    local set
    local get
    local configurable
    local enumerable
    enumerable = ____bindingPattern0.enumerable
    configurable = ____bindingPattern0.configurable
    get = ____bindingPattern0.get
    set = ____bindingPattern0.set
    writable = ____bindingPattern0.writable
    value = ____bindingPattern0.value
    local descriptor = {enumerable = enumerable == true, configurable = configurable == true}
    local hasGetterOrSetter = get ~= nil or set ~= nil
    local hasValueOrWritableAttribute = writable ~= nil or value ~= nil
    if hasGetterOrSetter and hasValueOrWritableAttribute then
        error("Invalid property descriptor. Cannot both specify accessors and a value or writable attribute.", 0)
    end
    if get or set then
        descriptor.get = get
        descriptor.set = set
    else
        descriptor.value = value
        descriptor.writable = writable == true
    end
    return descriptor
end

local __TS__DescriptorGet
do
    local getmetatable = _G.getmetatable
    local ____rawget = _G.rawget
    function __TS__DescriptorGet(self, metatable, key)
        while metatable do
            local rawResult = ____rawget(metatable, key)
            if rawResult ~= nil then
                return rawResult
            end
            local descriptors = ____rawget(metatable, "_descriptors")
            if descriptors then
                local descriptor = descriptors[key]
                if descriptor ~= nil then
                    if descriptor.get then
                        return descriptor.get(self)
                    end
                    return descriptor.value
                end
            end
            metatable = getmetatable(metatable)
        end
    end
end

local __TS__DescriptorSet
do
    local getmetatable = _G.getmetatable
    local ____rawget = _G.rawget
    local rawset = _G.rawset
    function __TS__DescriptorSet(self, metatable, key, value)
        while metatable do
            local descriptors = ____rawget(metatable, "_descriptors")
            if descriptors then
                local descriptor = descriptors[key]
                if descriptor ~= nil then
                    if descriptor.set then
                        descriptor.set(self, value)
                    else
                        if descriptor.writable == false then
                            error(
                                ((("Cannot assign to read only property '" .. key) .. "' of object '") .. tostring(self)) .. "'",
                                0
                            )
                        end
                        descriptor.value = value
                    end
                    return
                end
            end
            metatable = getmetatable(metatable)
        end
        rawset(self, key, value)
    end
end

local __TS__SetDescriptor
do
    local getmetatable = _G.getmetatable
    local function descriptorIndex(self, key)
        return __TS__DescriptorGet(
            self,
            getmetatable(self),
            key
        )
    end
    local function descriptorNewIndex(self, key, value)
        return __TS__DescriptorSet(
            self,
            getmetatable(self),
            key,
            value
        )
    end
    function __TS__SetDescriptor(target, key, desc, isPrototype)
        if isPrototype == nil then
            isPrototype = false
        end
        local ____isPrototype_0
        if isPrototype then
            ____isPrototype_0 = target
        else
            ____isPrototype_0 = getmetatable(target)
        end
        local metatable = ____isPrototype_0
        if not metatable then
            metatable = {}
            setmetatable(target, metatable)
        end
        if not isPrototype and not rawget(metatable, "_isOwnDescriptorMetatable") then
            local instanceMetatable = {}
            instanceMetatable._isOwnDescriptorMetatable = true
            setmetatable(instanceMetatable, metatable)
            setmetatable(target, instanceMetatable)
            metatable = instanceMetatable
        end
        local value = rawget(target, key)
        if value ~= nil then
            rawset(target, key, nil)
        end
        if not rawget(metatable, "_descriptors") then
            metatable._descriptors = {}
        end
        metatable._descriptors[key] = __TS__CloneDescriptor(desc)
        metatable.__index = descriptorIndex
        metatable.__newindex = descriptorNewIndex
    end
end
-- End of Lua Library inline imports
local ____exports = {}
local ____ProgressSource = require("datasources.ProgressSource")
local ProgressSource = ____ProgressSource.ProgressSource
--- Owned by Mana.UseRegenTimer(). The two-second phase is an estimate, not a server clock.
____exports.ManaRegenTimer = __TS__Class()
local ManaRegenTimer = ____exports.ManaRegenTimer
ManaRegenTimer.name = "ManaRegenTimer"
__TS__ClassExtends(ManaRegenTimer, ProgressSource)
function ManaRegenTimer.prototype.____constructor(self, observe)
    ProgressSource.prototype.____constructor(
        self,
        {
            current = function() return self:Remaining() end,
            min = function() return 0 end,
            max = function() return self.total end,
            percent = function() return self.total > 0 and self:Remaining() / self.total * 100 or 0 end
        }
    )
    self.observe = observe
    self.phase = "inactive"
    self.start = 0
    self.total = 0
    self.manaChanged = false
    self.bindings = __TS__New(Set)
    self.disposed = false
end
function ManaRegenTimer.prototype.Remaining(self)
    return self.IsActive and math.max(
        0,
        self.start + self.total - GetTime()
    ) or 0
end
function ManaRegenTimer.prototype.OnManaEvent(self, event, payload, mana)
    if event == "PLAYER_ENTERING_WORLD" then
        self:Stop()
        return
    end
    if not issecretvalue(mana) then
        local maximum = UnitPowerMax("player", 0)
        if not issecretvalue(maximum) and mana >= maximum then
            self:Stop()
            return
        end
    end
    if event == "UNIT_SPELLCAST_SUCCEEDED" then
        local spellId = payload[3]
        if issecretvalue(spellId) or type(spellId) ~= "number" then
            return
        end
        local ____opt_0 = C_Spell and C_Spell.GetSpellPowerCost
        local costs = ____opt_0 and ____opt_0(spellId)
        if issecretvalue(costs) or costs == nil then
            return
        end
        for ____, cost in ipairs(costs) do
            do
                local __continue15
                repeat
                    if issecretvalue(cost.type) or cost.type ~= 0 then
                        __continue15 = true
                        break
                    end
                    if issecretvalue(cost.cost) or cost.cost ~= nil and cost.cost > 0 then
                        self:Begin(
                            "fiveSecondRule",
                            GetTime()
                        )
                        return
                    end
                    __continue15 = true
                until true
                if not __continue15 then
                    break
                end
            end
        end
    elseif event == "UNIT_POWER_UPDATE" and not issecretvalue(payload[2]) and payload[2] == "MANA" then
        if self.phase == "inactive" then
            self:Begin(
                "estimatedTick",
                GetTime()
            )
        elseif self.phase == "estimatedTick" then
            self.manaChanged = true
        end
    end
    self:Notify()
end
function ManaRegenTimer.prototype.Begin(self, phase, start)
    local ____opt_4 = self.scheduled
    if ____opt_4 ~= nil then
        ____opt_4:Cancel()
    end
    self.phase = phase
    self.total = phase == "fiveSecondRule" and 5 or 2
    self.start = start
    self.manaChanged = false
    self:Notify()
    local ____end = start + self.total
    self.scheduled = C_Timer.NewTimer(
        math.max(
            0.01,
            ____end - GetTime()
        ),
        function()
            self.scheduled = nil
            if self.phase == "fiveSecondRule" or self.manaChanged then
                self:Begin(
                    "estimatedTick",
                    ____end > GetTime() - 2 and ____end or GetTime()
                )
            else
                self:Stop()
            end
        end
    )
end
function ManaRegenTimer.prototype.Notify(self)
    for ____, refresh in __TS__Iterator(self.bindings) do
        refresh(nil)
    end
end
function ManaRegenTimer.prototype.Stop(self)
    local ____opt_6 = self.scheduled
    if ____opt_6 ~= nil then
        ____opt_6:Cancel()
    end
    self.scheduled = nil
    self.phase = "inactive"
    self.total = 0
    self.manaChanged = false
    self:Notify()
end
function ManaRegenTimer.prototype.BindTo(self, frame, options)
    if options == nil then
        options = {}
    end
    if self.disposed then
        error("ManaRegenTimer: source is disposed")
    end
    if options.min ~= nil or options.max ~= nil or options.current ~= nil then
        error("ManaRegenTimer: range/current overrides are unsupported")
    end
    local bar = frame
    if bar.SetTimerDuration == nil or C_DurationUtil == nil then
        error("ManaRegenTimer: native duration support is unavailable")
    end
    local timer = C_DurationUtil.CreateDuration()
    if self.alphaCurve == nil and C_CurveUtil ~= nil and Enum.LuaCurveType ~= nil then
        self.alphaCurve = C_CurveUtil.CreateCurve()
        self.alphaCurve:SetType(Enum.LuaCurveType.Step)
        self.alphaCurve:AddPoint(0, 1)
        self.alphaCurve:AddPoint(1, 0)
    end
    bar:SetMinMaxValues(0, 1)
    local lastStart
    local lastTotal
    local function refresh()
        local active = self.IsActive and self:CanEmit(self:Remaining())
        local ____this_9
        ____this_9 = options
        local ____opt_8 = ____this_9.onActiveChange
        if ____opt_8 ~= nil then
            ____opt_8(____this_9, active)
        end
        if not active then
            return
        end
        if self.alphaCurve ~= nil then
            bar:SetAlpha(UnitPowerPercent("player", 0, true, self.alphaCurve))
        end
        if lastStart ~= self.start or lastTotal ~= self.total then
            timer:SetTimeFromStart(self.start, self.total)
            bar:SetTimerDuration(timer, Enum.StatusBarInterpolation.Immediate, Enum.StatusBarTimerDirection.RemainingTime)
            lastStart = self.start
            lastTotal = self.total
        end
    end
    self.bindings:add(refresh)
    if self.unsubscribe == nil then
        self.unsubscribe = self:observe(function(____, event, payload, mana) return self:OnManaEvent(event, payload, mana) end)
    end
    refresh(nil)
    return function()
        self.bindings:delete(refresh)
        if self.bindings.size == 0 then
            local ____opt_10 = self.unsubscribe
            if ____opt_10 ~= nil then
                ____opt_10(self)
            end
            self.unsubscribe = nil
            self:Stop()
        end
    end
end
function ManaRegenTimer.prototype.Listen(self)
end
function ManaRegenTimer.prototype.Dispose(self)
    self.disposed = true
    self:Stop()
    self.bindings:clear()
    local ____opt_12 = self.unsubscribe
    if ____opt_12 ~= nil then
        ____opt_12(self)
    end
    self.unsubscribe = nil
end
__TS__SetDescriptor(
    ManaRegenTimer.prototype,
    "Phase",
    {get = function(self)
        return self.phase
    end},
    true
)
__TS__SetDescriptor(
    ManaRegenTimer.prototype,
    "IsActive",
    {get = function(self)
        return self.phase ~= "inactive"
    end},
    true
)
return ____exports

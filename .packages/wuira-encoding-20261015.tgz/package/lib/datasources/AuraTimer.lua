--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end

local function __TS__ClassExtends(target, base)
    target.____super = base
    local staticMetatable = setmetatable({__index = base}, base)
    setmetatable(target, staticMetatable)
    local baseMetatable = getmetatable(base)
    if baseMetatable then
        if type(baseMetatable.__index) == "function" then
            staticMetatable.__index = baseMetatable.__index
        end
        if type(baseMetatable.__newindex) == "function" then
            staticMetatable.__newindex = baseMetatable.__newindex
        end
    end
    setmetatable(target.prototype, base.prototype)
    if type(base.prototype.__index) == "function" then
        target.prototype.__index = base.prototype.__index
    end
    if type(base.prototype.__newindex) == "function" then
        target.prototype.__newindex = base.prototype.__newindex
    end
    if type(base.prototype.__tostring) == "function" then
        target.prototype.__tostring = base.prototype.__tostring
    end
end

local function __TS__New(target, ...)
    local instance = setmetatable({}, target.prototype)
    instance:____constructor(...)
    return instance
end

local function __TS__CloneDescriptor(____bindingPattern0)
    local value
    local writable
    local set
    local get
    local configurable
    local enumerable
    enumerable = ____bindingPattern0.enumerable
    configurable = ____bindingPattern0.configurable
    get = ____bindingPattern0.get
    set = ____bindingPattern0.set
    writable = ____bindingPattern0.writable
    value = ____bindingPattern0.value
    local descriptor = {enumerable = enumerable == true, configurable = configurable == true}
    local hasGetterOrSetter = get ~= nil or set ~= nil
    local hasValueOrWritableAttribute = writable ~= nil or value ~= nil
    if hasGetterOrSetter and hasValueOrWritableAttribute then
        error("Invalid property descriptor. Cannot both specify accessors and a value or writable attribute.", 0)
    end
    if get or set then
        descriptor.get = get
        descriptor.set = set
    else
        descriptor.value = value
        descriptor.writable = writable == true
    end
    return descriptor
end

local __TS__DescriptorGet
do
    local getmetatable = _G.getmetatable
    local ____rawget = _G.rawget
    function __TS__DescriptorGet(self, metatable, key)
        while metatable do
            local rawResult = ____rawget(metatable, key)
            if rawResult ~= nil then
                return rawResult
            end
            local descriptors = ____rawget(metatable, "_descriptors")
            if descriptors then
                local descriptor = descriptors[key]
                if descriptor ~= nil then
                    if descriptor.get then
                        return descriptor.get(self)
                    end
                    return descriptor.value
                end
            end
            metatable = getmetatable(metatable)
        end
    end
end

local __TS__DescriptorSet
do
    local getmetatable = _G.getmetatable
    local ____rawget = _G.rawget
    local rawset = _G.rawset
    function __TS__DescriptorSet(self, metatable, key, value)
        while metatable do
            local descriptors = ____rawget(metatable, "_descriptors")
            if descriptors then
                local descriptor = descriptors[key]
                if descriptor ~= nil then
                    if descriptor.set then
                        descriptor.set(self, value)
                    else
                        if descriptor.writable == false then
                            error(
                                ((("Cannot assign to read only property '" .. key) .. "' of object '") .. tostring(self)) .. "'",
                                0
                            )
                        end
                        descriptor.value = value
                    end
                    return
                end
            end
            metatable = getmetatable(metatable)
        end
        rawset(self, key, value)
    end
end

local __TS__SetDescriptor
do
    local getmetatable = _G.getmetatable
    local function descriptorIndex(self, key)
        return __TS__DescriptorGet(
            self,
            getmetatable(self),
            key
        )
    end
    local function descriptorNewIndex(self, key, value)
        return __TS__DescriptorSet(
            self,
            getmetatable(self),
            key,
            value
        )
    end
    function __TS__SetDescriptor(target, key, desc, isPrototype)
        if isPrototype == nil then
            isPrototype = false
        end
        local ____isPrototype_0
        if isPrototype then
            ____isPrototype_0 = target
        else
            ____isPrototype_0 = getmetatable(target)
        end
        local metatable = ____isPrototype_0
        if not metatable then
            metatable = {}
            setmetatable(target, metatable)
        end
        if not isPrototype and not rawget(metatable, "_isOwnDescriptorMetatable") then
            local instanceMetatable = {}
            instanceMetatable._isOwnDescriptorMetatable = true
            setmetatable(instanceMetatable, metatable)
            setmetatable(target, instanceMetatable)
            metatable = instanceMetatable
        end
        local value = rawget(target, key)
        if value ~= nil then
            rawset(target, key, nil)
        end
        if not rawget(metatable, "_descriptors") then
            metatable._descriptors = {}
        end
        metatable._descriptors[key] = __TS__CloneDescriptor(desc)
        metatable.__index = descriptorIndex
        metatable.__newindex = descriptorNewIndex
    end
end
-- End of Lua Library inline imports
local ____exports = {}
local ____TimerSource = require("datasources.TimerSource")
local TimerSource = ____TimerSource.TimerSource
local ____TextureSource = require("datasources.TextureSource")
local TextureSource = ____TextureSource.TextureSource
local ____UnitSource = require("datasources.UnitSource")
local resolveUnit = ____UnitSource.resolveUnit
--- Selected aura duration and icon; selection policy belongs to the application.
____exports.AuraTimer = __TS__Class()
local AuraTimer = ____exports.AuraTimer
AuraTimer.name = "AuraTimer"
__TS__ClassExtends(AuraTimer, TimerSource)
function AuraTimer.prototype.____constructor(self, unit, options)
    local target = resolveUnit(nil, unit)
    local events = {
        "UNIT_AURA",
        "PLAYER_ENTERING_WORLD",
        "PLAYER_TARGET_CHANGED",
        "PLAYER_FOCUS_CHANGED",
        "SPELLS_CHANGED"
    }
    TimerSource.prototype.____constructor(
        self,
        function() return self:ReadDuration() end,
        events,
        target.Token
    )
    self.options = options
    self.status = "inactive"
    self.target = target
    self.Texture = __TS__New(
        TextureSource,
        function()
            local ____opt_0 = self:ReadAura()
            return ____opt_0 and ____opt_0.icon
        end,
        events,
        target.Token
    )
end
function AuraTimer.prototype.ReadAura(self)
    local query = C_UnitAuras and C_UnitAuras.GetAuraDataBySpellName
    local getName = C_Spell and C_Spell.GetSpellName
    if query == nil or getName == nil then
        self.status = "unavailable"
        return nil
    end
    do
        local function ____catch()
            self.status = "unavailable"
        end
        local ____try, ____hasReturned, ____returnValue = pcall(function()
            for ____, id in ipairs(self.options.spellIds) do
                do
                    local __continue8
                    repeat
                        local name = getName(id)
                        if issecretvalue(name) then
                            self.status = "restricted"
                            return true, nil
                        end
                        if name == nil then
                            __continue8 = true
                            break
                        end
                        local aura = query(self.target.Token, name, self.options.filter or "HELPFUL")
                        if issecretvalue(aura) then
                            self.status = "restricted"
                            return true, nil
                        end
                        if aura ~= nil then
                            self.status = "active"
                            return true, aura
                        end
                        __continue8 = true
                    until true
                    if not __continue8 then
                        break
                    end
                end
            end
            local ____opt_6 = C_Secrets and C_Secrets.ShouldAurasBeSecret
            local restricted = ____opt_6 and ____opt_6()
            self.status = (issecretvalue(restricted) or restricted == true) and "restricted" or "inactive"
        end)
        if not ____try then
            ____hasReturned, ____returnValue = ____catch()
        end
        if ____hasReturned then
            return ____returnValue
        end
    end
    return nil
end
function AuraTimer.prototype.ReadDuration(self)
    local aura = self:ReadAura()
    if aura == nil then
        return nil
    end
    do
        local function ____catch()
            self.status = "unavailable"
            return true, nil
        end
        local ____try, ____hasReturned, ____returnValue = pcall(function()
            local id = aura.auraInstanceID
            if (C_UnitAuras and C_UnitAuras.GetAuraDuration) ~= nil and (issecretvalue(id) or id ~= nil) then
                return true, C_UnitAuras.GetAuraDuration(self.target.Token, id)
            end
            local total = aura.duration
            local ____end = aura.expirationTime
            if issecretvalue(total) or issecretvalue(____end) then
                self.status = "restricted"
                return true, nil
            end
            if total == nil or ____end == nil or total <= 0 then
                return true, nil
            end
            if C_DurationUtil == nil then
                self.status = "unavailable"
                return true, nil
            end
            local timer = C_DurationUtil.CreateDuration()
            timer:SetTimeFromStart(____end - total, total)
            return true, timer
        end)
        if not ____try then
            ____hasReturned, ____returnValue = ____catch()
        end
        if ____hasReturned then
            return ____returnValue
        end
    end
end
__TS__SetDescriptor(
    AuraTimer.prototype,
    "Status",
    {get = function(self)
        self:ReadAura()
        return self.status
    end},
    true
)
return ____exports

import { DataSource } from "./DataSource";
import { UnitSource } from "./UnitSource";
import type { UnitInput } from "./UnitSource";
export type AuraSourceStatus = "known" | "unknown" | "restricted";
/** Readable aura snapshot. Unit tokens describe the source at snapshot time. */
export declare class Aura {
    readonly spellId: number;
    readonly name: string;
    readonly icon: number;
    readonly sourceUnit: string | undefined;
    readonly sourceStatus: AuraSourceStatus;
    private readonly sourceSelf;
    constructor(spellId: number, name: string, icon: number, sourceUnit: string | undefined, sourceStatus: AuraSourceStatus, sourceSelf: boolean | undefined);
    /** Undefined means ownership could not be established; it does not mean another caster. */
    isSourceSelf(): boolean | undefined;
}
/** Reads a fresh snapshot on access; it does not install listeners or poll. */
export declare abstract class AuraSource extends DataSource<readonly Aura[]> {
    private readonly filter;
    private restricted;
    readonly target: UnitSource;
    protected constructor(unit: UnitInput, filter: "HELPFUL" | "HARMFUL");
    get unit(): string;
    protected HasSecretFields(): boolean;
    protected GetValue(): readonly Aura[];
}
export declare class Buffs extends AuraSource {
    constructor(unit: UnitInput);
}
export declare class Debuffs extends AuraSource {
    constructor(unit: UnitInput);
}

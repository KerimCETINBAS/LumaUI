--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end

local function __TS__CloneDescriptor(____bindingPattern0)
    local value
    local writable
    local set
    local get
    local configurable
    local enumerable
    enumerable = ____bindingPattern0.enumerable
    configurable = ____bindingPattern0.configurable
    get = ____bindingPattern0.get
    set = ____bindingPattern0.set
    writable = ____bindingPattern0.writable
    value = ____bindingPattern0.value
    local descriptor = {enumerable = enumerable == true, configurable = configurable == true}
    local hasGetterOrSetter = get ~= nil or set ~= nil
    local hasValueOrWritableAttribute = writable ~= nil or value ~= nil
    if hasGetterOrSetter and hasValueOrWritableAttribute then
        error("Invalid property descriptor. Cannot both specify accessors and a value or writable attribute.", 0)
    end
    if get or set then
        descriptor.get = get
        descriptor.set = set
    else
        descriptor.value = value
        descriptor.writable = writable == true
    end
    return descriptor
end

local __TS__DescriptorGet
do
    local getmetatable = _G.getmetatable
    local ____rawget = _G.rawget
    function __TS__DescriptorGet(self, metatable, key)
        while metatable do
            local rawResult = ____rawget(metatable, key)
            if rawResult ~= nil then
                return rawResult
            end
            local descriptors = ____rawget(metatable, "_descriptors")
            if descriptors then
                local descriptor = descriptors[key]
                if descriptor ~= nil then
                    if descriptor.get then
                        return descriptor.get(self)
                    end
                    return descriptor.value
                end
            end
            metatable = getmetatable(metatable)
        end
    end
end

local __TS__DescriptorSet
do
    local getmetatable = _G.getmetatable
    local ____rawget = _G.rawget
    local rawset = _G.rawset
    function __TS__DescriptorSet(self, metatable, key, value)
        while metatable do
            local descriptors = ____rawget(metatable, "_descriptors")
            if descriptors then
                local descriptor = descriptors[key]
                if descriptor ~= nil then
                    if descriptor.set then
                        descriptor.set(self, value)
                    else
                        if descriptor.writable == false then
                            error(
                                ((("Cannot assign to read only property '" .. key) .. "' of object '") .. tostring(self)) .. "'",
                                0
                            )
                        end
                        descriptor.value = value
                    end
                    return
                end
            end
            metatable = getmetatable(metatable)
        end
        rawset(self, key, value)
    end
end

local __TS__SetDescriptor
do
    local getmetatable = _G.getmetatable
    local function descriptorIndex(self, key)
        return __TS__DescriptorGet(
            self,
            getmetatable(self),
            key
        )
    end
    local function descriptorNewIndex(self, key, value)
        return __TS__DescriptorSet(
            self,
            getmetatable(self),
            key,
            value
        )
    end
    function __TS__SetDescriptor(target, key, desc, isPrototype)
        if isPrototype == nil then
            isPrototype = false
        end
        local ____isPrototype_0
        if isPrototype then
            ____isPrototype_0 = target
        else
            ____isPrototype_0 = getmetatable(target)
        end
        local metatable = ____isPrototype_0
        if not metatable then
            metatable = {}
            setmetatable(target, metatable)
        end
        if not isPrototype and not rawget(metatable, "_isOwnDescriptorMetatable") then
            local instanceMetatable = {}
            instanceMetatable._isOwnDescriptorMetatable = true
            setmetatable(instanceMetatable, metatable)
            setmetatable(target, instanceMetatable)
            metatable = instanceMetatable
        end
        local value = rawget(target, key)
        if value ~= nil then
            rawset(target, key, nil)
        end
        if not rawget(metatable, "_descriptors") then
            metatable._descriptors = {}
        end
        metatable._descriptors[key] = __TS__CloneDescriptor(desc)
        metatable.__index = descriptorIndex
        metatable.__newindex = descriptorNewIndex
    end
end
-- End of Lua Library inline imports
local ____exports = {}
--- A value-producing source. Secrecy describes data, not native frame protection.
____exports.DataSource = __TS__Class()
local DataSource = ____exports.DataSource
DataSource.name = "DataSource"
function DataSource.prototype.____constructor(self, value, secret)
    if secret == nil then
        secret = false
    end
    self.value = value
    self.secret = secret
end
function DataSource.prototype.IsSecret(self)
    return self:IsValueSecret(self:GetValue())
end
function DataSource.prototype.Compute(self, compute)
    local value = self:GetValue()
    self:AssertReadable(value)
    return compute(nil, value)
end
function DataSource.prototype.GetValue(self)
    return self.value
end
function DataSource.prototype.When(self, condition)
    local ____self_0, ____conditions_1 = self, "conditions"
    if ____self_0[____conditions_1] == nil then
        ____self_0[____conditions_1] = {}
    end
    local ____self_conditions_3 = self.conditions
    ____self_conditions_3[#____self_conditions_3 + 1] = condition
    return self
end
function DataSource.prototype.CanEmit(self, value)
    if self.conditions == nil then
        return true
    end
    if self:IsValueSecret(value) then
        return false
    end
    for ____, condition in ipairs(self.conditions) do
        local result = condition(nil, value)
        if issecretvalue(result) or not result then
            return false
        end
    end
    return true
end
function DataSource.prototype.IsValueSecret(self, value)
    return issecretvalue(value) or self.secret or self:HasSecretFields(value)
end
function DataSource.prototype.SetValue(self, value, secret)
    if secret == nil then
        secret = false
    end
    self.value = value
    self.secret = secret
end
function DataSource.prototype.HasSecretFields(self, _value)
    return false
end
function DataSource.prototype.AssertReadable(self, value)
    if self:IsValueSecret(value) then
        error("DataSource: secret data cannot be read or used in computations")
    end
end
__TS__SetDescriptor(
    DataSource.prototype,
    "Value",
    {get = function(self)
        local value = self:GetValue()
        self:AssertReadable(value)
        return value
    end},
    true
)
return ____exports

import { DataSource } from "./DataSource";
/** A native texture reader with event-driven updates; no per-frame polling. */
export declare class TextureSource extends DataSource<string | number | undefined> {
    private readonly read;
    private readonly events;
    private readonly unit?;
    constructor(read: () => string | number | undefined, events: readonly string[], unit?: string | undefined);
    protected GetValue(): string | number | undefined;
    BindTo(frame: wuiraNativeFrame, texture: wuiraNativeTexture, onActiveChange?: (active: boolean) => void): void;
}

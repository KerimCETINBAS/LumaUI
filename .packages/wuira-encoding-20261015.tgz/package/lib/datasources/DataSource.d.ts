/** A value-producing source. Secrecy describes data, not native frame protection. */
export declare abstract class DataSource<T> {
    private value;
    private secret;
    private conditions?;
    protected constructor(value: T, secret?: boolean);
    /** Checked when consumed, rather than inferred from combat state. */
    IsSecret(): boolean;
    get Value(): T;
    Compute<TResult>(compute: (value: T) => TResult): TResult;
    protected GetValue(): T;
    /** Filters native binding emissions; Value remains a checked, fresh snapshot. */
    When(condition: (value: T) => boolean): this;
    protected CanEmit(value: T): boolean;
    private IsValueSecret;
    /** Replace the value and its explicit restriction together, clearing stale flags. */
    protected SetValue(value: T, secret?: boolean): void;
    /** Aggregate sources override this to check known fields without comparing them. */
    protected HasSecretFields(_value: T): boolean;
    private AssertReadable;
}

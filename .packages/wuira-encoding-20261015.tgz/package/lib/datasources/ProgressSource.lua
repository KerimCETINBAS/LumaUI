--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end

local function __TS__ClassExtends(target, base)
    target.____super = base
    local staticMetatable = setmetatable({__index = base}, base)
    setmetatable(target, staticMetatable)
    local baseMetatable = getmetatable(base)
    if baseMetatable then
        if type(baseMetatable.__index) == "function" then
            staticMetatable.__index = baseMetatable.__index
        end
        if type(baseMetatable.__newindex) == "function" then
            staticMetatable.__newindex = baseMetatable.__newindex
        end
    end
    setmetatable(target.prototype, base.prototype)
    if type(base.prototype.__index) == "function" then
        target.prototype.__index = base.prototype.__index
    end
    if type(base.prototype.__newindex) == "function" then
        target.prototype.__newindex = base.prototype.__newindex
    end
    if type(base.prototype.__tostring) == "function" then
        target.prototype.__tostring = base.prototype.__tostring
    end
end

local function __TS__New(target, ...)
    local instance = setmetatable({}, target.prototype)
    instance:____constructor(...)
    return instance
end
-- End of Lua Library inline imports
local ____exports = {}
local ____DataSource = require("datasources.DataSource")
local DataSource = ____DataSource.DataSource
local ____NativeNumberSource = require("datasources.NativeNumberSource")
local NativeNumberSource = ____NativeNumberSource.NativeNumberSource
--- Shared contract for health, power, cooldowns, and other progress values.
____exports.ProgressSource = __TS__Class()
local ProgressSource = ____exports.ProgressSource
ProgressSource.name = "ProgressSource"
__TS__ClassExtends(ProgressSource, DataSource)
function ProgressSource.prototype.____constructor(self, readers)
    DataSource.prototype.____constructor(self, 0)
    self.readers = readers
    self.Min = __TS__New(NativeNumberSource, readers.min)
    self.Max = __TS__New(NativeNumberSource, readers.max)
    self.Percent = __TS__New(NativeNumberSource, readers.percent)
end
function ProgressSource.prototype.GetValue(self)
    return self.readers:current()
end
function ProgressSource.prototype.IsSecret(self)
    return DataSource.prototype.IsSecret(self) or self.Min:IsSecret() or self.Max:IsSecret() or self.Percent:IsSecret()
end
function ProgressSource.prototype.BindTo(self, frame, options)
    if options == nil then
        options = {}
    end
    local function refresh()
        local sourceValue = self:GetValue()
        local active = self:CanEmit(sourceValue)
        local ____this_1
        ____this_1 = options
        local ____opt_0 = ____this_1.onActiveChange
        if ____opt_0 ~= nil then
            ____opt_0(____this_1, active)
        end
        if not active then
            return
        end
        local current = options.current ~= nil and options.current or sourceValue
        frame:SetMinMaxValues(
            options.min ~= nil and options.min or self.readers:min(),
            options.max ~= nil and options.max or self.readers:max()
        )
        frame:SetValue(current)
        local ____this_3
        ____this_3 = options
        local ____opt_2 = ____this_3.onRefresh
        if ____opt_2 ~= nil then
            ____opt_2(____this_3)
        end
    end
    local dispose = self:Listen(frame, refresh)
    do
        local function ____catch(failure)
            if dispose ~= nil then
                dispose(nil)
            end
            error(failure, 0)
        end
        local ____try, ____hasReturned = pcall(function()
            refresh(nil)
        end)
        if not ____try then
            ____catch(____hasReturned)
        end
    end
    return dispose
end
return ____exports

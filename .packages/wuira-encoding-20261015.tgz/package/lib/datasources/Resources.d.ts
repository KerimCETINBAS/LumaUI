import { ProgressSource } from "./ProgressSource";
import { UnitSource } from "./UnitSource";
import type { UnitInput } from "./UnitSource";
import { DataSource } from "./DataSource";
import type { ProgressOverrides } from "./ProgressSource";
import { ManaRegenTimer } from "./ManaRegenTimer";
export { Unit } from "./UnitSource";
/** Direct API-to-widget binding; opaque values are never compared or calculated. */
declare abstract class Resource extends ProgressSource {
    private readonly unitToken;
    private readonly events;
    private readonly listeners;
    private eventFrame?;
    private dispatching;
    private eventValue;
    protected constructor(current: () => number, maximum: () => number, percent: () => number, unitToken: string, events: string[]);
    protected AddEvents(...events: string[]): void;
    protected GetValue(): number;
    /** Future readable value changes only. Unsubscribe when the consumer is removed. */
    onChange(listener: (value: number) => void): () => void;
    /** One native event frame is shared by widgets, observers, and accessories. */
    protected Observe(listener: (event: string, payload: unknown[], value: number) => void): () => void;
    protected Listen(_frame: wuiraNativeFrame, refresh: () => void): () => void;
}
/** Live optional prediction channel. Secret amounts only travel to native sinks. */
export declare class HealthPrediction extends DataSource<number> {
    private readonly read;
    constructor(read: (() => number | undefined) | undefined);
    get IsAvailable(): boolean;
    protected GetValue(): number;
    ApplyTo(frame: wuiraNativeStatusBar, maximum: number): void;
}
export declare class HP extends Resource {
    private healPrediction?;
    private absorbPrediction?;
    get HealPrediction(): HealthPrediction | undefined;
    get AbsorbPrediction(): HealthPrediction | undefined;
    UseHealPrediction(): this;
    UseAbsorbPrediction(): this;
    BindTo(frame: wuiraNativeStatusBar, options?: ProgressOverrides): () => void;
    readonly target: UnitSource;
    get unit(): string;
    constructor(unit?: UnitInput);
}
/** Explicit mana (power type 0), even while the unit uses rage/energy. */
export declare class Mana extends Resource {
    private regenTimer?;
    get RegenTimer(): ManaRegenTimer | undefined;
    UseRegenTimer(): this;
    readonly target: UnitSource;
    get unit(): string;
    constructor(unit: UnitInput);
}
export declare const DataSources: {
    Resources: {
        HP: typeof HP;
        Mana: typeof Mana;
    };
};

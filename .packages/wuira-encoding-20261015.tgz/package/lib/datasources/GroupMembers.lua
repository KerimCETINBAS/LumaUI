--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end

local function __TS__ClassExtends(target, base)
    target.____super = base
    local staticMetatable = setmetatable({__index = base}, base)
    setmetatable(target, staticMetatable)
    local baseMetatable = getmetatable(base)
    if baseMetatable then
        if type(baseMetatable.__index) == "function" then
            staticMetatable.__index = baseMetatable.__index
        end
        if type(baseMetatable.__newindex) == "function" then
            staticMetatable.__newindex = baseMetatable.__newindex
        end
    end
    setmetatable(target.prototype, base.prototype)
    if type(base.prototype.__index) == "function" then
        target.prototype.__index = base.prototype.__index
    end
    if type(base.prototype.__newindex) == "function" then
        target.prototype.__newindex = base.prototype.__newindex
    end
    if type(base.prototype.__tostring) == "function" then
        target.prototype.__tostring = base.prototype.__tostring
    end
end

local function __TS__NumberIsFinite(value)
    return type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge
end

local function __TS__NumberIsInteger(value)
    return __TS__NumberIsFinite(value) and math.floor(value) == value
end
-- End of Lua Library inline imports
local ____exports = {}
local ____DataSource = require("datasources.DataSource")
local DataSource = ____DataSource.DataSource
--- Fresh roster tokens, including offline members. Tokens are not persistent identities.
____exports.GroupMembers = __TS__Class()
local GroupMembers = ____exports.GroupMembers
GroupMembers.name = "GroupMembers"
__TS__ClassExtends(GroupMembers, DataSource)
function GroupMembers.prototype.____constructor(self, scope)
    if scope == nil then
        scope = "auto"
    end
    DataSource.prototype.____constructor(self, {})
    self.scope = scope
    self.restricted = false
end
function GroupMembers.prototype.HasSecretFields(self)
    return self.restricted
end
function GroupMembers.prototype.GetValue(self)
    self.restricted = false
    if IsInRaid == nil or GetNumGroupMembers == nil then
        error("GroupMembers: this client does not expose the required group APIs")
    end
    local raid = IsInRaid()
    local count = GetNumGroupMembers()
    if issecretvalue(raid) or issecretvalue(count) then
        self.restricted = true
        return {}
    end
    if not __TS__NumberIsInteger(count) or count < 0 or count > 1024 then
        error("GroupMembers: invalid group member count")
    end
    if raid then
        if self.scope == "party" then
            return {}
        end
        local units = {}
        do
            local index = 1
            while index <= count do
                units[#units + 1] = "raid" .. tostring(index)
                index = index + 1
            end
        end
        return units
    end
    if self.scope == "raid" then
        return {}
    end
    if count == 0 then
        return self.scope == "auto" and ({"player"}) or ({})
    end
    local units = {"player"}
    do
        local index = 1
        while index < count do
            units[#units + 1] = "party" .. tostring(index)
            index = index + 1
        end
    end
    return units
end
--- Includes the player in a party; empty when solo or in a raid.
____exports.PartyMembers = __TS__Class()
local PartyMembers = ____exports.PartyMembers
PartyMembers.name = "PartyMembers"
__TS__ClassExtends(PartyMembers, ____exports.GroupMembers)
function PartyMembers.prototype.____constructor(self)
    PartyMembers.____super.prototype.____constructor(self, "party")
end
--- Includes the player through their raidN token; empty outside a raid.
____exports.RaidMembers = __TS__Class()
local RaidMembers = ____exports.RaidMembers
RaidMembers.name = "RaidMembers"
__TS__ClassExtends(RaidMembers, ____exports.GroupMembers)
function RaidMembers.prototype.____constructor(self)
    RaidMembers.____super.prototype.____constructor(self, "raid")
end
return ____exports

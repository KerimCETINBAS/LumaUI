--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end

local function __TS__ClassExtends(target, base)
    target.____super = base
    local staticMetatable = setmetatable({__index = base}, base)
    setmetatable(target, staticMetatable)
    local baseMetatable = getmetatable(base)
    if baseMetatable then
        if type(baseMetatable.__index) == "function" then
            staticMetatable.__index = baseMetatable.__index
        end
        if type(baseMetatable.__newindex) == "function" then
            staticMetatable.__newindex = baseMetatable.__newindex
        end
    end
    setmetatable(target.prototype, base.prototype)
    if type(base.prototype.__index) == "function" then
        target.prototype.__index = base.prototype.__index
    end
    if type(base.prototype.__newindex) == "function" then
        target.prototype.__newindex = base.prototype.__newindex
    end
    if type(base.prototype.__tostring) == "function" then
        target.prototype.__tostring = base.prototype.__tostring
    end
end

local function __TS__CloneDescriptor(____bindingPattern0)
    local value
    local writable
    local set
    local get
    local configurable
    local enumerable
    enumerable = ____bindingPattern0.enumerable
    configurable = ____bindingPattern0.configurable
    get = ____bindingPattern0.get
    set = ____bindingPattern0.set
    writable = ____bindingPattern0.writable
    value = ____bindingPattern0.value
    local descriptor = {enumerable = enumerable == true, configurable = configurable == true}
    local hasGetterOrSetter = get ~= nil or set ~= nil
    local hasValueOrWritableAttribute = writable ~= nil or value ~= nil
    if hasGetterOrSetter and hasValueOrWritableAttribute then
        error("Invalid property descriptor. Cannot both specify accessors and a value or writable attribute.", 0)
    end
    if get or set then
        descriptor.get = get
        descriptor.set = set
    else
        descriptor.value = value
        descriptor.writable = writable == true
    end
    return descriptor
end

local __TS__DescriptorGet
do
    local getmetatable = _G.getmetatable
    local ____rawget = _G.rawget
    function __TS__DescriptorGet(self, metatable, key)
        while metatable do
            local rawResult = ____rawget(metatable, key)
            if rawResult ~= nil then
                return rawResult
            end
            local descriptors = ____rawget(metatable, "_descriptors")
            if descriptors then
                local descriptor = descriptors[key]
                if descriptor ~= nil then
                    if descriptor.get then
                        return descriptor.get(self)
                    end
                    return descriptor.value
                end
            end
            metatable = getmetatable(metatable)
        end
    end
end

local __TS__DescriptorSet
do
    local getmetatable = _G.getmetatable
    local ____rawget = _G.rawget
    local rawset = _G.rawset
    function __TS__DescriptorSet(self, metatable, key, value)
        while metatable do
            local descriptors = ____rawget(metatable, "_descriptors")
            if descriptors then
                local descriptor = descriptors[key]
                if descriptor ~= nil then
                    if descriptor.set then
                        descriptor.set(self, value)
                    else
                        if descriptor.writable == false then
                            error(
                                ((("Cannot assign to read only property '" .. key) .. "' of object '") .. tostring(self)) .. "'",
                                0
                            )
                        end
                        descriptor.value = value
                    end
                    return
                end
            end
            metatable = getmetatable(metatable)
        end
        rawset(self, key, value)
    end
end

local __TS__SetDescriptor
do
    local getmetatable = _G.getmetatable
    local function descriptorIndex(self, key)
        return __TS__DescriptorGet(
            self,
            getmetatable(self),
            key
        )
    end
    local function descriptorNewIndex(self, key, value)
        return __TS__DescriptorSet(
            self,
            getmetatable(self),
            key,
            value
        )
    end
    function __TS__SetDescriptor(target, key, desc, isPrototype)
        if isPrototype == nil then
            isPrototype = false
        end
        local ____isPrototype_0
        if isPrototype then
            ____isPrototype_0 = target
        else
            ____isPrototype_0 = getmetatable(target)
        end
        local metatable = ____isPrototype_0
        if not metatable then
            metatable = {}
            setmetatable(target, metatable)
        end
        if not isPrototype and not rawget(metatable, "_isOwnDescriptorMetatable") then
            local instanceMetatable = {}
            instanceMetatable._isOwnDescriptorMetatable = true
            setmetatable(instanceMetatable, metatable)
            setmetatable(target, instanceMetatable)
            metatable = instanceMetatable
        end
        local value = rawget(target, key)
        if value ~= nil then
            rawset(target, key, nil)
        end
        if not rawget(metatable, "_descriptors") then
            metatable._descriptors = {}
        end
        metatable._descriptors[key] = __TS__CloneDescriptor(desc)
        metatable.__index = descriptorIndex
        metatable.__newindex = descriptorNewIndex
    end
end

local function __TS__New(target, ...)
    local instance = setmetatable({}, target.prototype)
    instance:____constructor(...)
    return instance
end

local function __TS__NumberIsFinite(value)
    return type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge
end

local function __TS__NumberIsInteger(value)
    return __TS__NumberIsFinite(value) and math.floor(value) == value
end

local function __TS__ArraySome(self, callbackfn, thisArg)
    for i = 1, #self do
        if callbackfn(thisArg, self[i], i - 1, self) then
            return true
        end
    end
    return false
end
-- End of Lua Library inline imports
local ____exports = {}
local ____DataSource = require("datasources.DataSource")
local DataSource = ____DataSource.DataSource
local ____UnitSource = require("datasources.UnitSource")
local resolveUnit = ____UnitSource.resolveUnit
____exports.ClassSource = __TS__Class()
local ClassSource = ____exports.ClassSource
ClassSource.name = "ClassSource"
__TS__ClassExtends(ClassSource, DataSource)
function ClassSource.prototype.____constructor(self, unit)
    DataSource.prototype.____constructor(self, nil)
    self.restricted = false
    self.target = resolveUnit(nil, unit)
end
function ClassSource.prototype.HasSecretFields(self)
    return self.restricted
end
function ClassSource.prototype.GetValue(self)
    self.restricted = false
    local player = UnitIsPlayer(self.unit)
    if issecretvalue(player) then
        self.restricted = true
        return nil
    end
    if not player then
        return nil
    end
    local name, token, id = UnitClass(self.unit)
    if issecretvalue(name) or issecretvalue(token) or issecretvalue(id) then
        self.restricted = true
        return nil
    end
    if name == nil or token == nil or id == nil then
        return nil
    end
    return {name = name, token = token, id = id}
end
__TS__SetDescriptor(
    ClassSource.prototype,
    "unit",
    {get = function(self)
        return self.target.Token
    end},
    true
)
--- Own data is read live; other units require an explicit inspect request.
____exports.SpecSource = __TS__Class()
local SpecSource = ____exports.SpecSource
SpecSource.name = "SpecSource"
__TS__ClassExtends(SpecSource, DataSource)
function SpecSource.prototype.____constructor(self, unit)
    DataSource.prototype.____constructor(self, nil)
    self.restricted = false
    self.status = "idle"
    self.target = resolveUnit(nil, unit)
end
function SpecSource.prototype.HasSecretFields(self)
    return self.restricted
end
function SpecSource.prototype.GetValue(self)
    local player = UnitIsPlayer(self.unit)
    if issecretvalue(player) then
        self.restricted = true
        return nil
    end
    if not player then
        self.restricted = false
        return nil
    end
    local ____self = UnitIsUnit(self.unit, "player")
    if issecretvalue(____self) then
        self.restricted = true
        return nil
    end
    if ____self then
        return self:Read(false)
    end
    local guid = UnitGUID(self.unit)
    if issecretvalue(guid) then
        self.restricted = true
        return nil
    end
    if guid == nil or guid ~= self.snapshotGUID then
        self.restricted = false
        return nil
    end
    return self.snapshot
end
function SpecSource.prototype.Read(self, inspect)
    self.restricted = false
    local api = C_SpecializationInfo
    if (api and api.GetNumSpecializationsForClassID) == nil or api.GetSpecializationInfo == nil then
        self.status = "unsupported"
        return nil
    end
    local classes = __TS__New(____exports.ClassSource, self.target)
    if classes:IsSecret() then
        self.restricted = true
        return nil
    end
    local info = classes.Value
    if info == nil then
        return nil
    end
    local count = api.GetNumSpecializationsForClassID(info.id)
    if issecretvalue(count) then
        self.restricted = true
        return nil
    end
    if not __TS__NumberIsInteger(count) or count < 0 or count > 32 then
        error("Specializations: invalid specialization count")
    end
    local result = {}
    do
        local index = 1
        while index <= count do
            local id, name, _description, icon, role, _stat, pointsSpent = api.GetSpecializationInfo(
                index,
                inspect,
                false,
                inspect and self.unit or nil,
                nil,
                nil,
                info.id
            )
            if __TS__ArraySome(
                {
                    id,
                    name,
                    icon,
                    role,
                    pointsSpent
                },
                function(____, value) return issecretvalue(value) end
            ) then
                self.restricted = true
                return nil
            end
            if id <= 0 then
                return nil
            end
            result[#result + 1] = {
                id = id,
                name = name,
                icon = icon,
                role = role,
                pointsSpent = pointsSpent
            }
            index = index + 1
        end
    end
    self.status = "ready"
    return result
end
function SpecSource.prototype.RequestInspect(self)
    self:Dispose()
    self.snapshot = nil
    self.snapshotGUID = nil
    self.restricted = false
    local player = UnitIsPlayer(self.unit)
    if issecretvalue(player) then
        self.restricted = true
        return false
    end
    if not player then
        return false
    end
    if CanInspect == nil or NotifyInspect == nil or (C_SpecializationInfo and C_SpecializationInfo.GetSpecializationInfo) == nil then
        self.status = "unsupported"
        return false
    end
    if InCombatLockdown() then
        return false
    end
    local guid = UnitGUID(self.unit)
    if issecretvalue(guid) then
        self.restricted = true
        return false
    end
    local allowed = CanInspect(self.unit)
    if issecretvalue(allowed) then
        self.restricted = true
        return false
    end
    if guid == nil or not allowed then
        return false
    end
    self.snapshotGUID = guid
    self.status = "pending"
    local listener = CreateFrame("Frame", nil, UIParent)
    self.listener = listener
    listener:RegisterEvent("INSPECT_READY")
    listener:SetScript(
        "OnEvent",
        function(_frame, _event, inspectedGUID)
            if issecretvalue(inspectedGUID) or inspectedGUID ~= guid then
                return
            end
            local current = UnitGUID(self.unit)
            if issecretvalue(current) or current ~= guid then
                self:Dispose()
                return
            end
            self.snapshot = self:Read(true)
            self:StopListening()
            if self.status == "pending" then
                self.status = "idle"
            end
        end
    )
    NotifyInspect(self.unit)
    return true
end
function SpecSource.prototype.StopListening(self)
    local ____opt_4 = self.listener
    if ____opt_4 ~= nil then
        ____opt_4:UnregisterAllEvents()
    end
    local ____opt_6 = self.listener
    if ____opt_6 ~= nil then
        ____opt_6:SetScript("OnEvent", nil)
    end
    local ____opt_8 = self.listener
    if ____opt_8 ~= nil then
        ____opt_8:Hide()
    end
    self.listener = nil
end
function SpecSource.prototype.Dispose(self)
    self:StopListening()
    self.status = "idle"
    self.snapshot = nil
    self.snapshotGUID = nil
end
__TS__SetDescriptor(
    SpecSource.prototype,
    "unit",
    {get = function(self)
        return self.target.Token
    end},
    true
)
__TS__SetDescriptor(
    SpecSource.prototype,
    "Status",
    {get = function(self)
        local guid = UnitGUID(self.unit)
        if not issecretvalue(guid) and self.snapshotGUID ~= nil and guid ~= self.snapshotGUID then
            return "idle"
        end
        return self.status
    end},
    true
)
____exports.Specializations = ____exports.SpecSource
return ____exports

/** Local client output only; never sends chat messages to other players. */
export declare class Console {
    private constructor();
    static Echo(message: string): void;
}

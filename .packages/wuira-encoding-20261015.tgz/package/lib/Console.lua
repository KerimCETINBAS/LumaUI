--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end
-- End of Lua Library inline imports
local ____exports = {}
--- Local client output only; never sends chat messages to other players.
____exports.Console = __TS__Class()
local Console = ____exports.Console
Console.name = "Console"
function Console.prototype.____constructor(self)
end
function Console.Echo(self, message)
    print("|cff60d9c5[wuira]|r " .. message)
end
return ____exports

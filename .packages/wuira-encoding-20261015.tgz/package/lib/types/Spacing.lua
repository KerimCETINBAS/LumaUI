--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
-- Lua Library inline imports
local function __TS__NumberIsFinite(value)
    return type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge
end
-- End of Lua Library inline imports
local ____exports = {}
function ____exports.resolveSpacing(self, value)
    if value == nil then
        value = 0
    end
    local result = type(value) == "number" and ({top = value, right = value, bottom = value, left = value}) or ({top = value.top or 0, right = value.right or 0, bottom = value.bottom or 0, left = value.left or 0})
    for ____, edge in ipairs({result.top, result.right, result.bottom, result.left}) do
        if not __TS__NumberIsFinite(edge) or edge < 0 then
            error("Spacing must be finite and non-negative")
        end
    end
    return result
end
return ____exports

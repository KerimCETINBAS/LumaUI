/** A uniform spacing value or individually specified edges, in UI units. */
export type Spacing = number | {
    top?: number;
    right?: number;
    bottom?: number;
    left?: number;
};
export interface Insets {
    top: number;
    right: number;
    bottom: number;
    left: number;
}
export declare function resolveSpacing(value?: Spacing): Insets;

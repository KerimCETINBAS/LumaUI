--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
____exports.Anchor = ____exports.Anchor or ({})
____exports.Anchor.Center = "Center"
____exports.Anchor.Bottom = "Bottom"
____exports.Anchor.BottomLeft = "BottomLeft"
____exports.Anchor.BottomRight = "BottomRight"
return ____exports
